# حالة المشروع — Smart Mobile Codes 2.2

## المنفذ في السورس
- [x] واجهة عربية Material 3 وثيم فاتح/داكن/النظام.
- [x] بحث عربي مرن مع تطبيع الهمزات والتشكيل والتاء المربوطة والأرقام العربية.
- [x] أقسام مرئية مستقلة للشركات الأربع مع عدّاد خدمات وهوية لونية وتصفية الشركة المختارة.
- [x] هوية بصرية جديدة وشعار محدث وشاشة بداية متحركة.
- [x] نسخ الكود ونسخ تفاصيله للمشاركة.
- [x] تحذير قبل فتح الاتصال؛ لا يوجد اتصال تلقائي.
- [x] ويدجت Android لعرض الكود المختار.
- [x] كتالوج بعيد مع تحقق بنيوي وذاكرة مؤقتة وبديل دون إنترنت.
- [x] نسخ احتياطي واستعادة للمفضلة والسجل.
- [x] إعدادات موسعة لحفظ تفضيلات المظهر والتأكيد قبل الاتصال والاهتزاز وكثافة البطاقات.
- [x] مساعد بحث محلي باللغة الطبيعية عبر كلمات مفتاحية عربية شائعة.
- [x] حاسبة استهلاك البيانات ومقارنة تكلفة GB لباقتين يدخل المستخدم بياناتهما.
- [x] النسخ الاحتياطي يشمل المفضلة والسجل وتفضيلات التطبيق، مع دعم استيراد النسخ السابقة.
- [x] إمكانية مسح المفضلة والسجل من الإعدادات.
- [x] Workflow ثابت على Ubuntu 24.04، مع actions/checkout@v6 ورفع Artifact عبر actions/upload-artifact@v6 لتجنب تحذير Node.js 20 في الإجراءات المحددة.
- [x] اختبارات وحدة لتطبيع البحث وصحة بيانات الكتالوج وتحويل بيانات الكود ذهابًا وإيابًا.

## تحسينات سهولة الاستخدام في الحزمة الحالية
- حالات فارغة مفهومة للمفضلة والسجل بدل رسالة نتائج عامة.
- زر موحد لمسح البحث والفلاتر والعودة إلى الدليل.
- توضيح صحيح أن إرسال الملاحظات يفتح GitHub وليس البريد الإلكتروني.
- معالجة أخطاء حفظ المظهر وتحديث الدليل برسائل واضحة.

## قيود ومهام ما زالت تتطلب موارد/تحققًا
- [ ] مراجعة كل كود من مصدر رسمي مباشر يثبت الكود نفسه. وجود مرجع رسمي مرتبط بالسجل لا يعني اختبار الكود فعليًا على الشبكة أو ضمان عمله على كل الخطوط.
- [ ] توقيع تشفيري لملف الكتالوج.
- [ ] Backend ولوحة إدارة وحسابات ومزامنة سحابية.
- [ ] كتالوج باقات حي بأسعار موثقة ومقارنة تلقائية بين عروض الشركات.
- [ ] مساعد ذكاء اصطناعي متصل وخاصية البحث الصوتي.
- [ ] Push notifications.
- [ ] تكامل أصلي لاختيار SIM واختبار أجهزة متعددة.
- [ ] اختبار فعلي على أجهزة Android متعددة.
- [ ] توقيع APK بمفتاح Keystore الخاص بالمالك ونشر Play Store.

## ملاحظة البناء
تم تحديث Workflow إلى Ubuntu 24.04 و`actions/upload-artifact@v6` لمعالجة التحذيرين اللذين ظهرا في GitHub Actions. لم يتوفر Flutter SDK في بيئة إعداد الحزمة؛ لذلك لم يتم تشغيل `flutter analyze` أو `flutter test` أو بناء APK هنا. يجب اعتماد نتيجة GitHub Actions قبل تثبيت الإصدار.


## تحديث 2.2.0 – 9 نوفمبر 2026
- توسيع دليل الأكواد بالاعتماد على صفحات الشركات الرسمية المتاحة، مع ربط كل سجل بمصدره.
- مزامنة دليل البداية دون اتصال مع الكتالوج المنشور.
- إعادة بناء الهوية البصرية والشعار وشاشة البداية.
- إضافة بطاقات منفصلة لكل شركة وتحسين واجهة الاستكشاف والبحث.
- تظل الأكواد التي لا يثبت مصدرها الرسمي الكود نفسه غير موثقة، ولا تُرفع حالتها تلقائيًا.

## 2.2.1 hotfix
- Fixed invalid `TextInputType.number` constructor syntax in the package comparison form.
- Removed an unused import from `main.dart`.
- Applied analyzer suggestions for string interpolation and const construction.
- Version bumped to 2.2.1+10.


## إصلاح 2.2.2+11 – 9 نوفمبر 2026
- جعل الأكواد غير موثقة افتراضياً إلى أن يتوفر دليل رسمي مباشر يثبت كل كود على حدة؛ رابط صفحة عامة للشركة لا يكفي وحده لإظهار شارة «موثق».
- إصلاح اختبار شاشة البداية: تجنب pumpAndSettle مع مؤثر الإضاءة المتكرر، والانتظار بشكل محدد حتى انتهاء انتقال الشاشة.


## الإصدار 2.4.0 — مركز التحكم المحلي
- إضافة شاشة مركز تحكم مستقلة للعروض والباقات وأكواد الخدمات.
- إنشاء وتعديل وحذف العناصر، وتصنيفها حسب النوع والشركة (Vodafone / Orange / e& / WE).
- بحث وتصفية، حالة نشط/متوقف، حقول السعر والسعة والصلاحية ورابط المصدر.
- تصدير واستيراد كتالوج المركز بصيغة JSON.
- بيانات المركز محفوظة محليًا على الجهاز؛ لا يتم نشرها للمستخدمين الآخرين دون خادم وصلاحيات نشر.
- Flutter Analyze والاختبارات وبناء APK لم تُشغّل محليًا لعدم توفر Flutter SDK.


## 2.4.0 Brand refresh
Includes SVG logo master, launcher foreground PNG, adaptive Android icon generation, Android app label patch, updated Material 3 theme and splash/logo test.

## 2.5.1 — Smart Help Center
- Added a dedicated assistant destination in the main bottom navigation.
- Added chat-style local assistance, quick prompts, provider filtering, Arabic intent matching, result cards, copy-code actions, verification labels, and navigation to directory results.
- Assistant searches the bundled/cached catalog on-device; it does not provide live AI, live carrier account data, or unverified live offers.
- Version: 2.5.1+15.


## Version 2.5.2+17 — analyzer and test compatibility fixes
- Replaced deprecated DropdownButtonFormField `value` with `initialValue`.
- Updated widget tests to use the binding's `setSurfaceSize` API.
- Added Material import to the app widget test for `ValueKey`.
- Marked immutable TextInputType construction as const.
- Cleaned const usage in the empty-state card.
- Flutter SDK execution remains pending GitHub Actions verification.


## Version 2.5.3+18 — responsive assistant fix
- Reworked assistant result metadata rows to wrap on narrow screens instead of forcing horizontal Row layouts.
- Made the quick-prompt heading/count responsive.
- Expanded assistant widget coverage to 398px and 320px widths and added a render-exception assertion.
- Flutter SDK is not installed in the preparation environment; GitHub Actions must confirm analyze/tests/build.


## Version 2.5.4+19 — scrollable home feed
- Fixed the home screen's top hero/banner card remaining stationary while only the code list scrolled.
- The banner, provider selector, search, filters, and code cards now move together as one vertical feed.
- Kept horizontal provider/category chips independently scrollable.
- Flutter SDK execution remains pending GitHub Actions verification.
