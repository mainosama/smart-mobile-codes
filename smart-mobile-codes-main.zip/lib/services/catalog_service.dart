import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../data/seed_codes.dart';
import '../models/mobile_code.dart';

class CatalogResult {
  const CatalogResult({
    required this.codes,
    required this.updatedAt,
    required this.fromNetwork,
    this.message,
  });

  final List<MobileCode> codes;
  final DateTime? updatedAt;
  final bool fromNetwork;
  final String? message;
}

/// Downloads the public catalog, validates it, and keeps a local offline copy.
/// A cache-busting query plus no-cache headers avoids stale GitHub Raw responses.
class CatalogService {
  static const catalogUrl =
      'https://raw.githubusercontent.com/mainosama/smart-mobile-codes/main/codes.json';
  static const _cacheKey = 'catalog_json_v2';
  static const _updatedKey = 'catalog_updated_at_v2';

  Future<CatalogResult> load({bool forceRefresh = false}) async {
    SharedPreferences? prefs;
    try {
      prefs = await SharedPreferences.getInstance();
    } catch (_) {
      return const CatalogResult(
        codes: seedCodes,
        updatedAt: null,
        fromNetwork: false,
        message: 'تعذر الوصول للتخزين؛ يتم عرض الدليل المضمن بالتطبيق.',
      );
    }

    final cached = prefs.getString(_cacheKey) ?? prefs.getString('catalog_json_v1');
    final cachedAt = DateTime.tryParse(
      prefs.getString(_updatedKey) ?? prefs.getString('catalog_updated_at_v1') ?? '',
    );

    try {
      final uri = Uri.parse(catalogUrl).replace(
        queryParameters: {'v': DateTime.now().millisecondsSinceEpoch.toString()},
      );
      final response = await http.get(uri, headers: const {
        'Accept': 'application/json',
        'Cache-Control': 'no-cache, no-store, max-age=0',
        'Pragma': 'no-cache',
      }).timeout(Duration(seconds: forceRefresh ? 25 : 15));

      if (response.statusCode != 200) {
        throw HttpException('HTTP ${response.statusCode}');
      }

      // GitHub serves UTF-8 JSON. Decode explicitly to avoid charset surprises.
      final body = utf8.decode(response.bodyBytes);
      final parsed = _parse(body);
      final root = jsonDecode(body) as Map<String, dynamic>;
      final updatedAt = DateTime.tryParse(root['updatedAt']?.toString() ?? '')
          ?? DateTime.now().toUtc();

      await prefs.setString(_cacheKey, body);
      await prefs.setString(_updatedKey, updatedAt.toIso8601String());
      return CatalogResult(
        codes: parsed,
        updatedAt: updatedAt,
        fromNetwork: true,
        message: 'تم تحميل أحدث نسخة من الدليل.',
      );
    } catch (_) {
      if (cached != null) {
        try {
          return CatalogResult(
            codes: _parse(cached),
            updatedAt: cachedAt,
            fromNetwork: false,
            message: forceRefresh
                ? 'لم ينجح التحديث الآن؛ يعرض التطبيق آخر نسخة محفوظة.'
                : 'تعذر الاتصال؛ يعرض التطبيق آخر نسخة محفوظة.',
          );
        } catch (_) {
          // Fall through to the bundled catalog when the cache is damaged.
        }
      }
      return CatalogResult(
        codes: seedCodes,
        updatedAt: null,
        fromNetwork: false,
        message: forceRefresh
            ? 'فشل تحديث الدليل. يعرض التطبيق الأكواد المضمنة ويمكنك المحاولة لاحقًا.'
            : 'تعذر الاتصال؛ يعرض التطبيق الدليل المضمن المتاح دون إنترنت.',
      );
    }
  }

  List<MobileCode> _parse(String body) {
    if (body.length > 1024 * 1024) {
      throw const FormatException('Catalog too large');
    }
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic> || decoded['schemaVersion'] != 1) {
      throw const FormatException('Unsupported catalog schema');
    }
    final raw = decoded['codes'];
    if (raw is! List || raw.isEmpty || raw.length > 1000) {
      throw const FormatException('Invalid catalog entries');
    }

    final codes = raw.map((entry) {
      if (entry is! Map<String, dynamic>) {
        throw const FormatException('Invalid code entry');
      }
      final code = MobileCode.fromJson(entry);
      if (code.id.trim().isEmpty ||
          code.title.trim().isEmpty ||
          code.providerName.trim().isEmpty ||
          !const {'vodafone', 'orange', 'etisalat', 'we'}.contains(code.providerId) ||
          !RegExp(r'^[0-9*#]+$').hasMatch(code.code) ||
          code.code.length > 40) {
        throw const FormatException('Invalid code fields');
      }
      if (code.verified) {
        final source = Uri.tryParse(code.sourceUrl);
        if (source == null || source.scheme != 'https' || source.host.isEmpty) {
          throw const FormatException('Verified code must have HTTPS source');
        }
      }
      return code;
    }).toList(growable: false);

    if (codes.map((code) => code.id).toSet().length != codes.length) {
      throw const FormatException('Duplicate code ids');
    }
    return codes;
  }
}

class HttpException implements Exception {
  const HttpException(this.message);
  final String message;
  @override
  String toString() => message;
}
