import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../data/seed_codes.dart';
import '../models/mobile_code.dart';

enum CatalogOrigin { bundled, cached, network }

class CatalogSnapshot {
  const CatalogSnapshot({required this.codes, required this.updatedAt, required this.origin});
  final List<MobileCode> codes;
  final DateTime? updatedAt;
  final CatalogOrigin origin;
}

class CatalogFormatException implements Exception {
  const CatalogFormatException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Loads the public catalog: bundled copy -> last good download -> fresh download.
/// Every download is validated before it replaces anything.
class CatalogService {
  static const catalogUrl =
      'https://raw.githubusercontent.com/mainosama/smart-mobile-codes/main/codes.json';
  static const _cacheKey = 'catalog_json_v3';
  static const _updatedKey = 'catalog_updated_at_v3';
  static const _fetchedKey = 'catalog_fetched_at_v3';
  static const _maxBytes = 1024 * 1024;

  /// Instant, offline: the newest of (cached download, bundled seed).
  Future<CatalogSnapshot> loadLocal() async {
    final seed = CatalogSnapshot(
      codes: seedCodes,
      updatedAt: DateTime.tryParse(seedCatalogUpdatedAt),
      origin: CatalogOrigin.bundled,
    );
    try {
      final prefs = await SharedPreferences.getInstance();
      final body = prefs.getString(_cacheKey);
      if (body == null) return seed;
      final parsed = parseCatalog(body);
      final seedDate = seed.updatedAt;
      if (parsed.updatedAt != null && seedDate != null && parsed.updatedAt!.isBefore(seedDate)) {
        return seed;
      }
      return CatalogSnapshot(codes: parsed.codes, updatedAt: parsed.updatedAt, origin: CatalogOrigin.cached);
    } catch (_) {
      return seed;
    }
  }

  Future<DateTime?> lastFetchAt() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final millis = prefs.getInt(_fetchedKey);
      return millis == null ? null : DateTime.fromMillisecondsSinceEpoch(millis);
    } catch (_) {
      return null;
    }
  }

  /// Downloads and validates the remote catalog. Throws on any failure so the
  /// caller keeps showing what it already has.
  Future<CatalogSnapshot> fetchRemote({Duration timeout = const Duration(seconds: 15)}) async {
    final uri = Uri.parse(catalogUrl).replace(
      queryParameters: {'v': DateTime.now().millisecondsSinceEpoch.toString()},
    );
    final response = await http.get(uri, headers: const {
      'Accept': 'application/json',
      'Cache-Control': 'no-cache',
    }).timeout(timeout);
    if (response.statusCode != 200) {
      throw CatalogFormatException('HTTP ${response.statusCode}');
    }
    final body = utf8.decode(response.bodyBytes);
    final parsed = parseCatalog(body);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_cacheKey, body);
      await prefs.setString(_updatedKey, parsed.updatedAt?.toIso8601String() ?? '');
      await prefs.setInt(_fetchedKey, DateTime.now().millisecondsSinceEpoch);
    } catch (_) {
      // Caching is best-effort; the data in memory is still valid.
    }
    return CatalogSnapshot(
      codes: parsed.codes,
      updatedAt: parsed.updatedAt ?? DateTime.now(),
      origin: CatalogOrigin.network,
    );
  }

  static MobileCode _decode(Map<String, dynamic> entry) {
    try {
      return MobileCode.fromJson(entry);
    } catch (_) {
      throw const CatalogFormatException('Invalid code fields');
    }
  }

  static const _providers = {'vodafone', 'orange', 'etisalat', 'we'};
  static final _codePattern = RegExp(r'^[0-9*#\u0621-\u064A\s\[\]{}<>]+$');

  /// Pure validation + parsing (also used by tests and by the CI check).
  static ({List<MobileCode> codes, DateTime? updatedAt}) parseCatalog(String body) {
    if (body.length > _maxBytes) throw const CatalogFormatException('Catalog too large');
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic> || decoded['schemaVersion'] != 1) {
      throw const CatalogFormatException('Unsupported catalog schema');
    }
    final raw = decoded['codes'];
    if (raw is! List || raw.isEmpty || raw.length > 1000) {
      throw const CatalogFormatException('Invalid catalog entries');
    }
    final codes = <MobileCode>[];
    for (final entry in raw) {
      if (entry is! Map<String, dynamic>) throw const CatalogFormatException('Invalid code entry');
      final code = _decode(entry);
      if (code.id.trim().isEmpty ||
          code.title.trim().isEmpty ||
          code.providerName.trim().isEmpty ||
          !_providers.contains(code.providerId) ||
          code.code.length > 40 ||
          !_codePattern.hasMatch(code.code)) {
        throw const CatalogFormatException('Invalid code fields');
      }
      if (code.verified) {
        final source = Uri.tryParse(code.sourceUrl);
        if (source == null || source.scheme != 'https' || source.host.isEmpty) {
          throw const CatalogFormatException('Verified code must have an HTTPS source');
        }
      }
      codes.add(code);
    }
    if (codes.map((c) => c.id).toSet().length != codes.length) {
      throw const CatalogFormatException('Duplicate code ids');
    }
    return (codes: codes, updatedAt: DateTime.tryParse(decoded['updatedAt']?.toString() ?? ''));
  }
}
