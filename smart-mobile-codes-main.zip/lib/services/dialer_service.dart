import 'package:url_launcher/url_launcher.dart';

class DialerService {
  /// Opens the phone's dialer with the code pre-filled. It never places the call.
  Future<bool> dial(String rawCode) async {
    // Keep only dialable characters; Uri encodes `#` as %23 for the tel: scheme.
    final code = rawCode.replaceAll(RegExp(r'[^0-9*#]'), '');
    if (code.isEmpty) return false;
    try {
      return await launchUrl(Uri(scheme: 'tel', path: code), mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }
}
