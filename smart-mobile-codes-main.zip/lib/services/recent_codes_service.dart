import 'package:shared_preferences/shared_preferences.dart';

/// Stores a small, private on-device history. No phone number or call data is read.
class RecentCodesService {
  static const _key = 'recent_code_ids_v1';
  static const limit = 30;

  Future<List<String>> load() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_key) ?? <String>[];
  }

  Future<void> save(List<String> ids) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_key, ids.take(limit).toList());
  }
}
