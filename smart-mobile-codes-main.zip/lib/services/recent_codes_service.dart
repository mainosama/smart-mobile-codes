import 'package:shared_preferences/shared_preferences.dart';

/// Stores a small, private on-device history. No phone number or call data is read.
class RecentCodesService {
  static const _key = 'recent_code_ids_v1';
  static const _limit = 30;

  Future<List<String>> load() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_key) ?? <String>[];
  }

  Future<void> record(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList(_key) ?? <String>[];
    ids.remove(id);
    ids.insert(0, id);
    await prefs.setStringList(_key, ids.take(_limit).toList());
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
