import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/seed_codes.dart';
import '../models/mobile_code.dart';
import '../services/catalog_service.dart';
import '../services/favorites_service.dart';
import '../services/recent_codes_service.dart';

enum RefreshResult { updated, offline, skipped }

/// Single source of truth for catalog, saved codes and preferences.
class AppController extends ChangeNotifier {
  AppController({
    CatalogService? catalog,
    FavoritesService? favoritesService,
    RecentCodesService? recentService,
  })  : _catalog = catalog ?? CatalogService(),
        _favoritesService = favoritesService ?? FavoritesService(),
        _recentService = recentService ?? RecentCodesService();

  static const _themeKey = 'app_theme_mode_v1';
  static const _confirmKey = 'confirm_before_dial_v1';
  static const _hapticsKey = 'haptics_enabled_v1';
  static const _compactKey = 'compact_cards_v1';
  static const _widgetKey = 'widget_code_id_v1';
  static const _autoRefreshAfter = Duration(hours: 6);

  final CatalogService _catalog;
  final FavoritesService _favoritesService;
  final RecentCodesService _recentService;
  bool _disposed = false;

  List<MobileCode> codes = seedCodes;
  DateTime? catalogUpdatedAt = DateTime.tryParse(seedCatalogUpdatedAt);
  CatalogOrigin origin = CatalogOrigin.bundled;
  bool catalogBusy = false;

  Set<String> favorites = <String>{};
  List<String> recents = <String>[];

  ThemeMode themeMode = ThemeMode.system;
  bool confirmBeforeDial = true;
  bool haptics = true;
  bool compactCards = false;
  String? widgetCodeId;

  MobileCode? byId(String id) {
    for (final code in codes) {
      if (code.id == id) return code;
    }
    return null;
  }

  List<MobileCode> get favoriteCodes =>
      codes.where((c) => favorites.contains(c.id)).toList(growable: false);

  List<MobileCode> get recentCodes =>
      recents.map(byId).whereType<MobileCode>().toList(growable: false);

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  Future<void> init({bool autoRefresh = true}) async {
    await _loadPreferences();
    final local = await _catalog.loadLocal();
    _apply(local);
    await _loadSaved();
    await _migrateLegacyIds();
    _notify();
    if (autoRefresh) unawaited(refreshCatalog());
  }

  void _apply(CatalogSnapshot snapshot) {
    codes = snapshot.codes;
    catalogUpdatedAt = snapshot.updatedAt;
    origin = snapshot.origin;
    if (widgetCodeId == null || byId(widgetCodeId!) == null) {
      widgetCodeId = codes.isEmpty ? null : codes.first.id;
    }
  }

  Future<RefreshResult> refreshCatalog({bool force = false}) async {
    if (catalogBusy) return RefreshResult.skipped;
    if (!force) {
      final last = await _catalog.lastFetchAt();
      if (last != null && DateTime.now().difference(last) < _autoRefreshAfter) {
        return RefreshResult.skipped;
      }
    }
    catalogBusy = true;
    _notify();
    try {
      final snapshot = await _catalog.fetchRemote(timeout: Duration(seconds: force ? 25 : 15));
      _apply(snapshot);
      await _migrateLegacyIds();
      return RefreshResult.updated;
    } catch (_) {
      return RefreshResult.offline;
    } finally {
      catalogBusy = false;
      _notify();
    }
  }

  Future<void> _loadPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      themeMode = switch (prefs.getString(_themeKey)) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      };
      confirmBeforeDial = prefs.getBool(_confirmKey) ?? true;
      haptics = prefs.getBool(_hapticsKey) ?? true;
      compactCards = prefs.getBool(_compactKey) ?? false;
      widgetCodeId = prefs.getString(_widgetKey);
    } catch (_) {
      // Defaults stay in place when storage is unavailable.
    }
  }

  Future<void> _loadSaved() async {
    try {
      favorites = await _favoritesService.load();
      recents = await _recentService.load();
    } catch (_) {}
  }

  /// Records replaced by a merge keep working: their old ids map to the new one.
  Future<void> _migrateLegacyIds() async {
    final legacy = <String, String>{};
    for (final code in codes) {
      for (final old in code.legacyIds) {
        legacy[old] = code.id;
      }
    }
    if (legacy.isEmpty) return;
    final valid = codes.map((c) => c.id).toSet();
    String remap(String id) => valid.contains(id) ? id : (legacy[id] ?? id);

    final nextFavorites = favorites.map(remap).toSet();
    final nextRecents = <String>[];
    for (final id in recents.map(remap)) {
      if (!nextRecents.contains(id)) nextRecents.add(id);
    }
    final favoritesChanged = nextFavorites.length != favorites.length || !nextFavorites.containsAll(favorites);
    final recentsChanged = !_sameList(nextRecents, recents);
    favorites = nextFavorites;
    recents = nextRecents;
    try {
      if (favoritesChanged) await _favoritesService.save(favorites);
      if (recentsChanged) await _recentService.save(recents);
    } catch (_) {}
    if (widgetCodeId != null) widgetCodeId = remap(widgetCodeId!);
  }

  bool _sameList(List<String> a, List<String> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  // ---- saved codes -------------------------------------------------------

  Future<void> toggleFavorite(String id) async {
    final next = {...favorites};
    if (!next.add(id)) next.remove(id);
    favorites = next;
    _notify();
    try {
      await _favoritesService.save(next);
    } catch (_) {}
  }

  Future<void> recordRecent(String id) async {
    final next = [id, ...recents.where((e) => e != id)].take(RecentCodesService.limit).toList();
    recents = next;
    _notify();
    try {
      await _recentService.save(next);
    } catch (_) {}
  }

  Future<void> clearRecents() async {
    recents = <String>[];
    _notify();
    try {
      await _recentService.save(recents);
    } catch (_) {}
  }

  Future<void> clearFavorites() async {
    favorites = <String>{};
    _notify();
    try {
      await _favoritesService.save(favorites);
    } catch (_) {}
  }

  // ---- preferences -------------------------------------------------------

  Future<void> _saveString(String key, String value) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(key, value);
    } catch (_) {}
  }

  Future<void> _saveBool(String key, bool value) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(key, value);
    } catch (_) {}
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    _notify();
    await _saveString(_themeKey, switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    });
  }

  Future<void> setConfirmBeforeDial(bool value) async {
    confirmBeforeDial = value;
    _notify();
    await _saveBool(_confirmKey, value);
  }

  Future<void> setHaptics(bool value) async {
    haptics = value;
    _notify();
    await _saveBool(_hapticsKey, value);
  }

  Future<void> setCompactCards(bool value) async {
    compactCards = value;
    _notify();
    await _saveBool(_compactKey, value);
  }

  Future<void> setWidgetCode(String id) async {
    widgetCodeId = id;
    _notify();
    await _saveString(_widgetKey, id);
  }

  // ---- backup ------------------------------------------------------------

  String exportBackup() {
    final backup = {
      'format': 'smart_mobile_codes_backup',
      'version': 1,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'favorites': favorites.toList(),
      'recent': recents,
      'settings': {
        'theme': switch (themeMode) {
          ThemeMode.light => 'light',
          ThemeMode.dark => 'dark',
          ThemeMode.system => 'system',
        },
        'confirmBeforeDial': confirmBeforeDial,
        'hapticsEnabled': haptics,
        'compactCards': compactCards,
      },
    };
    return const JsonEncoder.withIndent('  ').convert(backup);
  }

  /// Throws [FormatException] when the text is not a backup of this app.
  Future<void> importBackup(String raw) async {
    final data = jsonDecode(raw);
    if (data is! Map ||
        data['format'] != 'smart_mobile_codes_backup' ||
        data['version'] != 1 ||
        data['favorites'] is! List ||
        data['recent'] is! List) {
      throw const FormatException('Invalid backup');
    }
    final restoredFavorites = (data['favorites'] as List).whereType<String>().toSet();
    final restoredRecents = <String>[];
    for (final id in (data['recent'] as List).whereType<String>()) {
      if (!restoredRecents.contains(id)) restoredRecents.add(id);
    }
    favorites = restoredFavorites;
    recents = restoredRecents.take(RecentCodesService.limit).toList();
    final settings = data['settings'];
    if (settings is Map) {
      final theme = settings['theme'];
      if (theme == 'light') themeMode = ThemeMode.light;
      if (theme == 'dark') themeMode = ThemeMode.dark;
      if (theme == 'system') themeMode = ThemeMode.system;
      if (settings['confirmBeforeDial'] is bool) confirmBeforeDial = settings['confirmBeforeDial'] as bool;
      if (settings['hapticsEnabled'] is bool) haptics = settings['hapticsEnabled'] as bool;
      if (settings['compactCards'] is bool) compactCards = settings['compactCards'] as bool;
    }
    await _migrateLegacyIds();
    _notify();
    try {
      await _favoritesService.save(favorites);
      await _recentService.save(recents);
      await _saveString(_themeKey, switch (themeMode) {
        ThemeMode.light => 'light',
        ThemeMode.dark => 'dark',
        ThemeMode.system => 'system',
      });
      await _saveBool(_confirmKey, confirmBeforeDial);
      await _saveBool(_hapticsKey, haptics);
      await _saveBool(_compactKey, compactCards);
    } catch (_) {}
  }
}

/// Makes the controller available to the whole widget tree.
class AppScope extends InheritedNotifier<AppController> {
  const AppScope({super.key, required AppController controller, required super.child})
      : super(notifier: controller);

  /// Rebuilds the caller whenever the controller changes.
  static AppController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope is missing above this widget');
    return scope!.notifier!;
  }

  /// For event handlers: reads the controller without subscribing.
  static AppController read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope is missing above this widget');
    return scope!.notifier!;
  }
}
