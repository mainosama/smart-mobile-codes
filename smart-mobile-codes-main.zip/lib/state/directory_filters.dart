import 'package:flutter/foundation.dart';

import '../models/mobile_code.dart';
import '../utils/code_search.dart';

enum DirectorySort { recommended, title }

/// UI state of the directory screen. Lives in the shell so the assistant can
/// push a search into it.
class DirectoryFilters extends ChangeNotifier {
  static const allCategories = 'الكل';
  static const allSystems = 'كل الأنظمة';

  String query = '';
  String provider = 'all';
  String category = allCategories;
  String system = allSystems;
  bool verifiedOnly = false;
  DirectorySort sort = DirectorySort.recommended;

  bool get hasFilters =>
      query.trim().isNotEmpty ||
      provider != 'all' ||
      category != allCategories ||
      system != allSystems ||
      verifiedOnly;

  void update({
    String? query,
    String? provider,
    String? category,
    String? system,
    bool? verifiedOnly,
    DirectorySort? sort,
  }) {
    if (query != null) this.query = query;
    if (provider != null && provider != this.provider) {
      this.provider = provider;
      this.system = allSystems; // system chips belong to one carrier
    }
    if (category != null) this.category = category;
    if (system != null) this.system = system;
    if (verifiedOnly != null) this.verifiedOnly = verifiedOnly;
    if (sort != null) this.sort = sort;
    notifyListeners();
  }

  void reset() {
    query = '';
    provider = 'all';
    category = allCategories;
    system = allSystems;
    verifiedOnly = false;
    sort = DirectorySort.recommended;
    notifyListeners();
  }

  List<MobileCode>? _cache;
  List<MobileCode>? _cacheSource;
  String _cacheKey = '';

  /// Memoized: rebuilds caused by unrelated changes (favourites, theme) reuse the result.
  List<MobileCode> apply(List<MobileCode> all) {
    final key = '$provider|$category|$system|$verifiedOnly|${sort.index}|${query.trim()}';
    final cached = _cache;
    if (cached != null && identical(_cacheSource, all) && _cacheKey == key) return cached;
    final result = _compute(all);
    _cache = result;
    _cacheSource = all;
    _cacheKey = key;
    return result;
  }

  List<MobileCode> _compute(List<MobileCode> all) {
    Iterable<MobileCode> items = all;
    if (provider != 'all') items = items.where((c) => c.providerId == provider);
    if (category != allCategories) items = items.where((c) => c.category == category);
    if (system != allSystems) {
      items = items.where((c) => c.systems == system || c.systems == allSystems);
    }
    if (verifiedOnly) items = items.where((c) => c.verified);
    if (query.trim().isNotEmpty) return searchCodes(items, query);
    final list = items.toList();
    if (sort == DirectorySort.title) list.sort((a, b) => a.title.compareTo(b.title));
    return list;
  }
}
