/// Keep in sync with `version:` in pubspec.yaml (a unit test enforces it).
const kAppVersionName = '2.8.0';
const kAppBuildNumber = 23;
const feedbackUrl = 'https://github.com/mainosama/smart-mobile-codes/issues/new';
