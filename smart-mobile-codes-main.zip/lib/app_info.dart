/// Keep in sync with `version:` in pubspec.yaml (a unit test enforces it).
const appVersion = '2.7.0';
const appBuildNumber = 22;
const feedbackUrl = 'https://github.com/mainosama/smart-mobile-codes/issues/new';
