/// Forgiving Arabic/Latin search normalization.
String normalizeSearchText(String value) {
  var text = value.toLowerCase().trim();
  const replacements = {
    'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ى': 'ي', 'ة': 'ه',
    'ؤ': 'و', 'ئ': 'ي', 'ـ': '',
    '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
    '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  };
  replacements.forEach((from, to) => text = text.replaceAll(from, to));
  text = text.replaceAll(RegExp(r'[ًٌٍَُِّْٰ]'), '');
  return text.replaceAll(RegExp(r'\s+'), ' ');
}

/// Variants of a typed word that also match common Arabic prefixes/suffixes:
/// `الباقات` -> `باقات`, `باق`; `الرصيد` -> `رصيد`.
Set<String> searchForms(String token) {
  final forms = <String>{token};
  if (token.length > 3 && token.startsWith('ال')) forms.add(token.substring(2));
  for (final form in forms.toList()) {
    if (form.length > 4 && form.endsWith('ات')) {
      forms.add(form.substring(0, form.length - 2));
    } else if (form.length > 3 && form.endsWith('ه')) {
      forms.add(form.substring(0, form.length - 1));
    }
  }
  return forms;
}
