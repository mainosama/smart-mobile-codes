/// Forgiving Arabic/Latin search normalization.
String normalizeSearchText(String value) {
  var text = value.toLowerCase().trim();
  const replacements = {
    'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ى': 'ي', 'ة': 'ه',
    'ؤ': 'و', 'ئ': 'ي', 'ـ': '',
    '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
    '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  };
  replacements.forEach((from, to) => text = text.replaceAll(from, to));
  text = text.replaceAll(RegExp(r'[ًٌٍَُِّْٰ]'), '');
  return text.replaceAll(RegExp(r'\s+'), ' ');
}
