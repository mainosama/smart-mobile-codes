import '../data/carriers.dart';
import 'digits.dart';

const _prefixes = <String, String>{
  '010': 'vodafone',
  '011': 'etisalat',
  '012': 'orange',
  '015': 'we',
};

/// Normalizes `+20 101 234 5678`, `0020...`, `1012345678` to `01012345678`.
/// Returns null when the text is not an Egyptian mobile number.
String? normalizeEgyptianMobile(String input) {
  var digits = toLatinDigits(input).replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.startsWith('00')) digits = digits.substring(2);
  if (digits.startsWith('20') && digits.length == 12) digits = '0${digits.substring(2)}';
  if (digits.length == 10 && digits.startsWith('1')) digits = '0$digits';
  return RegExp(r'^01[0-9]{9}$').hasMatch(digits) ? digits : null;
}

/// The carrier that originally owns the number prefix. Numbers moved between
/// carriers (if any) can differ, so the UI states this limitation.
Carrier? carrierForNumber(String input) {
  final number = normalizeEgyptianMobile(input);
  if (number == null) return null;
  final id = _prefixes[number.substring(0, 3)];
  return id == null ? null : carrierById(id);
}
