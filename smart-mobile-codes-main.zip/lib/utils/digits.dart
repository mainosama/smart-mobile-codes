/// Converts Arabic-Indic and Persian digits to Latin digits.
String toLatinDigits(String input) {
  final buffer = StringBuffer();
  for (final unit in input.runes) {
    if (unit >= 0x0660 && unit <= 0x0669) {
      buffer.writeCharCode(0x30 + unit - 0x0660);
    } else if (unit >= 0x06F0 && unit <= 0x06F9) {
      buffer.writeCharCode(0x30 + unit - 0x06F0);
    } else {
      buffer.writeCharCode(unit);
    }
  }
  return buffer.toString();
}

/// Parses user-typed decimals such as `1.5`, `1,5`, `١٫٥` or `١٢`.
double? parseDecimal(String input) {
  final cleaned = toLatinDigits(input)
      .trim()
      .replaceAll('٫', '.')
      .replaceAll('،', '.')
      .replaceAll(',', '.');
  if (cleaned.isEmpty) return null;
  return double.tryParse(cleaned);
}
