const _months = <String>[
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];

/// `2026-11-10` -> `10 نوفمبر 2026`.
String formatArabicDate(DateTime date) =>
    '${date.day} ${_months[date.month - 1]} ${date.year}';
