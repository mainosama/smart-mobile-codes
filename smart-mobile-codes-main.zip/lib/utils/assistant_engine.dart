import '../data/carriers.dart';
import '../models/mobile_code.dart';
import 'code_search.dart';
import 'search_normalizer.dart';

class AssistantAnswer {
  const AssistantAnswer({
    required this.message,
    required this.results,
    required this.searchQuery,
    this.providerId,
  });

  final String message;
  final List<MobileCode> results;

  /// What to type in the directory search to see the same results.
  final String searchQuery;
  final String? providerId;
}

class _Intent {
  const _Intent(this.name, this.triggers, this.targets);
  final String name;
  final List<String> triggers;
  final List<String> targets;
}

const _intents = <_Intent>[
  _Intent('remaining', ['متبقي', 'المتبقي', 'باقي', 'فاضل', 'فضل'], ['متبقي']),
  _Intent('balance', ['رصيد', 'رصيدي', 'فلوسي', 'balance'], ['رصيد']),
  _Intent('transfer', ['تحويل', 'حول', 'احول', 'تحول', 'ابعت', 'transfer'], ['تحويل']),
  _Intent('loan', ['سلف', 'سلفني', 'استلف', 'اسلف', 'سلفه', 'عالنوته'], ['سلفني']),
  _Intent('recharge', ['شحن', 'اشحن', 'كارت', 'كروت', 'recharge'], ['شحن']),
  _Intent('internet', ['انترنت', 'نت', 'جيجا', 'ميجا', 'data'], ['انترنت']),
  _Intent('bundles', ['باقه', 'باقات', 'عرض', 'عروض', 'تجديد', 'جدد', 'اشتراك', 'اشترك'], ['باق', 'تجديد', 'عروض']),
  _Intent('support', ['دعم', 'شكوي', 'عملاء', 'مساعده'], ['عملاء']),
  _Intent('wallet', ['محفظه', 'كاش', 'cash', 'money'], ['محفظ', 'كاش', 'cash', 'money']),
  _Intent('number', ['رقمي', 'رقمك'], ['معرفه رقم']),
  _Intent('cancel', ['الغاء', 'الغي', 'ايقاف', 'وقف'], ['الغاء', 'ايقاف']),
  _Intent('roaming', ['تجوال', 'سفر', 'roaming'], ['تجوال']),
  _Intent('calls', ['مكالمه', 'مكالمات', 'كلمني'], ['مكالم', 'كلمني']),
];

const _stopWords = <String>{
  'كود', 'اكواد', 'ازاي', 'عايز', 'عاوز', 'عايزه', 'عاوزه', 'اعرف', 'معرفه', 'عن', 'من', 'في',
  'علي', 'الي', 'ايه', 'هو', 'هي', 'لو', 'سمحت', 'لي', 'انا', 'ياريت', 'اعمل', 'كيف', 'ما',
  'طريقه', 'خدمه', 'خدمات', 'عند', 'ب', 'و',
};

Set<String> _forms(String token) {
  final out = <String>{token};
  for (final prefix in const ['و', 'ب', 'ل', 'ف']) {
    if (token.length > 3 && token.startsWith(prefix)) out.add(token.substring(1));
  }
  for (final form in out.toList()) {
    if (form.length > 3 && form.startsWith('ال')) out.add(form.substring(2));
  }
  return out;
}

bool _hasTrigger(String query, List<String> tokens, String trigger) {
  final normalized = normalizeSearchText(trigger);
  if (normalized.contains(' ')) return query.contains(normalized);
  for (final token in tokens) {
    if (_forms(token).contains(normalized)) return true;
  }
  return false;
}

String? _detectProvider(String query, List<String> tokens) {
  for (final carrier in carriers) {
    for (final alias in carrier.aliases) {
      if (_hasTrigger(query, tokens, alias)) return carrier.id;
    }
  }
  return null;
}

/// Local, deterministic "ask the directory" engine. No network, no model:
/// it recognises common intents (balance, transfer, recharge...) and a carrier
/// name in a sentence, then ranks catalog entries.
AssistantAnswer answerQuestion(
  List<MobileCode> codes,
  String raw, {
  String? providerFilter,
  int limit = 6,
}) {
  final query = normalizeSearchText(raw);
  final tokens = query.split(' ').where((t) => t.isNotEmpty).toList();
  final detected = _detectProvider(query, tokens);
  final provider = detected ?? ((providerFilter == null || providerFilter == 'all') ? null : providerFilter);
  final pool = provider == null ? codes : codes.where((c) => c.providerId == provider).toList();

  final hits = _intents
      .where((i) => i.triggers.any((t) => _hasTrigger(query, tokens, t)))
      .toList();

  var results = <MobileCode>[];
  var searchQuery = '';

  if (hits.isNotEmpty) {
    final scored = <MapEntry<int, MobileCode>>[];
    final order = <String, int>{for (var i = 0; i < pool.length; i++) pool[i].id: i};
    for (final code in pool) {
      final head = normalizeSearchText('${code.title} ${code.category}');
      final body = normalizeSearchText(code.description);
      var score = 0;
      var satisfied = 0;
      for (final intent in hits) {
        var best = 0;
        for (final target in intent.targets) {
          final t = normalizeSearchText(target);
          if (head.contains(t)) {
            best = 3;
          } else if (best < 1 && body.contains(t)) {
            best = 1;
          }
        }
        if (best > 0) {
          score += best;
          satisfied++;
        }
      }
      if (satisfied == hits.length) score += 5;
      if (score > 0) scored.add(MapEntry(score, code));
    }
    scored.sort((a, b) {
      final byScore = b.key.compareTo(a.key);
      return byScore != 0 ? byScore : order[a.value.id]!.compareTo(order[b.value.id]!);
    });
    results = scored.take(limit).map((e) => e.value).toList();
    searchQuery = hits.first.targets.first;
  } else {
    final cleaned = tokens
        .where((t) => !_stopWords.contains(t))
        .where((t) => !carriers.any((c) => c.aliases.any((a) => normalizeSearchText(a) == t)))
        .join(' ');
    if (cleaned.isNotEmpty) {
      results = searchCodes(pool, cleaned).take(limit).toList();
      searchQuery = cleaned;
    }
  }

  final carrierName = provider == null ? null : carrierById(provider)?.name;
  late final String message;
  if (results.isNotEmpty) {
    final where = carrierName == null ? '' : ' عند $carrierName';
    message = 'لقيت ${results.length} نتيجة$where. راجع الرسوم والأهلية قبل الاستخدام، والأكواد اللي لم تُراجع رسميًا عليها علامة.';
  } else if (hits.any((i) => i.name == 'internet' || i.name == 'bundles')) {
    message = 'مفيش في الدليل أسعار أو عروض حالية للباقات، هو بيعرض الأكواد بس. جرّب تكتب اسم الباقة أو الشركة، أو افتح تطبيق الشركة للأسعار.';
  } else {
    message = 'ملقيتش تطابق واضح. جرّب كلمات أبسط زي «رصيد» أو «تحويل» أو اسم الشركة، أو افتح الدليل وابحث بالكود نفسه.';
  }

  return AssistantAnswer(
    message: message,
    results: results,
    searchQuery: searchQuery,
    providerId: detected,
  );
}
