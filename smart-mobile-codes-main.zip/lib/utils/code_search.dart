import '../data/carriers.dart';
import '../models/mobile_code.dart';
import 'search_normalizer.dart';

class _Index {
  _Index(MobileCode code)
      : title = normalizeSearchText(code.title),
        dial = code.code.toLowerCase().replaceAll(' ', ''),
        category = normalizeSearchText(code.category),
        provider = normalizeSearchText(
          '${code.providerName} ${(carrierById(code.providerId)?.aliases ?? const <String>[]).join(' ')}',
        ),
        description = normalizeSearchText('${code.description} ${code.eligibility}');

  final String title;
  final String dial;
  final String category;
  final String provider;
  final String description;

  int scoreToken(String token) {
    var best = 0;
    for (final form in searchForms(token)) {
      var s = 0;
      if (title.contains(form)) s += 8;
      if (dial.contains(form)) s += 6;
      if (category.contains(form)) s += 4;
      if (provider.contains(form)) s += 4;
      if (description.contains(form)) s += 1;
      if (s > best) best = s;
    }
    return best;
  }
}

class _Scored {
  const _Scored(this.code, this.score, this.order);
  final MobileCode code;
  final int score;
  final int order;
}

/// Ranked search. Every word must match (title > code > category/carrier >
/// description). When nothing matches all words, falls back to matching any
/// word so a long sentence still finds something useful.
List<MobileCode> searchCodes(Iterable<MobileCode> codes, String query, {bool lenient = true}) {
  final normalized = normalizeSearchText(query);
  final list = codes.toList(growable: false);
  if (normalized.isEmpty) return list;
  final tokens = normalized.split(' ').where((t) => t.isNotEmpty).toList();

  List<MobileCode> run({required bool requireAll}) {
    final scored = <_Scored>[];
    for (var i = 0; i < list.length; i++) {
      final index = _Index(list[i]);
      var total = 0;
      var matched = 0;
      for (final token in tokens) {
        final s = index.scoreToken(token);
        if (s > 0) {
          total += s;
          matched++;
        }
      }
      final ok = requireAll ? matched == tokens.length : matched > 0;
      if (ok) scored.add(_Scored(list[i], total, i));
    }
    scored.sort((a, b) {
      final byScore = b.score.compareTo(a.score);
      return byScore != 0 ? byScore : a.order.compareTo(b.order);
    });
    return scored.map((s) => s.code).toList(growable: false);
  }

  final strict = run(requireAll: true);
  if (strict.isNotEmpty || !lenient || tokens.length < 2) return strict;
  return run(requireAll: false);
}
