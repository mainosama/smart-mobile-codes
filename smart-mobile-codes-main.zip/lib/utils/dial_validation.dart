/// A string the phone dialler can accept as a USSD/short code.
bool isValidDialString(String input) {
  final value = input.trim();
  return RegExp(r'^[0-9*#]{2,40}$').hasMatch(value) && RegExp(r'[0-9]').hasMatch(value);
}
