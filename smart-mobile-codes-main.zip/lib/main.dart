import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/splash_screen.dart';
import 'state/app_controller.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SmartMobileCodesApp());
}

class SmartMobileCodesApp extends StatefulWidget {
  const SmartMobileCodesApp({super.key, this.controller, this.splashDuration});

  /// Injected by tests; the app creates its own otherwise.
  final AppController? controller;
  final Duration? splashDuration;

  @override
  State<SmartMobileCodesApp> createState() => _SmartMobileCodesAppState();
}

class _SmartMobileCodesAppState extends State<SmartMobileCodesApp> {
  late final AppController _controller = widget.controller ?? AppController();

  @override
  void initState() {
    super.initState();
    _controller.init();
  }

  @override
  void dispose() {
    if (widget.controller == null) _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      controller: _controller,
      child: ListenableBuilder(
        listenable: _controller,
        builder: (context, _) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'كود موبايل',
          locale: const Locale('ar', 'EG'),
          supportedLocales: const [Locale('ar', 'EG'), Locale('ar')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          theme: buildAppTheme(Brightness.light),
          darkTheme: buildAppTheme(Brightness.dark),
          themeMode: _controller.themeMode,
          home: widget.splashDuration == null
              ? const SplashScreen()
              : SplashScreen(duration: widget.splashDuration!),
        ),
      ),
    );
  }
}
