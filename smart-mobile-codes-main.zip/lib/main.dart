import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/splash_screen.dart';

final ValueNotifier<ThemeMode> appThemeMode = ValueNotifier(ThemeMode.system);

Future<void> loadAppPreferences() async {
  final prefs = await SharedPreferences.getInstance();
  final value = prefs.getString('app_theme_mode_v1') ?? 'system';
  appThemeMode.value = switch (value) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  loadAppPreferences().catchError((_) {}).whenComplete(
    () => runApp(const SmartMobileCodesApp()),
  );
}

class SmartMobileCodesApp extends StatelessWidget {
  const SmartMobileCodesApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF173D72);
    const navy = Color(0xFF071A35);
    const gold = Color(0xFFE6B95C);
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: appThemeMode,
      builder: (context, mode, _) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Mobile Codes',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF3F5F9),
        dividerColor: const Color(0xFFE5EAF2),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE1E7F0))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE1E7F0))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFF2467B2), width: 1.6)),
        ),
        navigationBarTheme: NavigationBarThemeData(indicatorColor: gold.withValues(alpha: .22), labelTextStyle: WidgetStateProperty.all(const TextStyle(fontWeight: FontWeight.w700, fontSize: 11))),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF4F6FA), foregroundColor: Color(0xFF0B1E3D), centerTitle: false, elevation: 0),
        fontFamily: 'sans-serif',
        cardTheme: CardThemeData(
          elevation: 0, color: Colors.white,
          margin: const EdgeInsets.symmetric(vertical: 6),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFFE8EDF5))),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF081426),
        dividerColor: const Color(0xFF24364F),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF12243B), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
        cardTheme: CardThemeData(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
        appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white, centerTitle: false, elevation: 0),
      ),
      themeMode: mode,
      home: const SplashScreen(),
      ),
    );
  }
}
