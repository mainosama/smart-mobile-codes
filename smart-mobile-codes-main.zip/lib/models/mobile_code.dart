import '../utils/digits.dart';

enum TemplateFieldKind { phone, amount, digits }

/// One blank inside a dial template such as `*868*2*رقم الموبايل*المبلغ#`.
class TemplateField {
  const TemplateField(this.label, this.kind);
  final String label;
  final TemplateFieldKind kind;

  String? validate(String raw) {
    final value = toLatinDigits(raw).trim();
    if (value.isEmpty) return 'مطلوب';
    if (!RegExp(r'^[0-9]+$').hasMatch(value)) return 'أرقام فقط';
    switch (kind) {
      case TemplateFieldKind.phone:
        if (!RegExp(r'^01[0-9]{9}$').hasMatch(value)) {
          return 'رقم موبايل من 11 رقمًا يبدأ بـ 01';
        }
      case TemplateFieldKind.amount:
        if (int.parse(value) <= 0) return 'المبلغ لازم يكون أكبر من صفر';
      case TemplateFieldKind.digits:
        if (value.length < 4) return 'الرقم قصير';
    }
    return null;
  }
}

final RegExp _arabicRun = RegExp(r'[\u0621-\u064A]+(?:\s+[\u0621-\u064A]+)*');
final RegExp _brackets = RegExp(r'[\[\]{}<>]');

class MobileCode {
  const MobileCode({
    required this.id,
    required this.providerId,
    required this.providerName,
    required this.title,
    required this.code,
    required this.category,
    this.description = '',
    this.verified = false,
    this.sourceUrl = '',
    this.systems = 'كل الأنظمة',
    this.eligibility = '',
    this.legacyIds = const [],
  });

  final String id;
  final String providerId;
  final String providerName;
  final String title;
  final String code;
  final String category;
  final String description;
  final bool verified;
  final String sourceUrl;

  /// Short filter value (see the system chips in the directory).
  final String systems;

  /// Free-text eligibility note shown on the card.
  final String eligibility;

  /// Ids this record replaced; used to migrate favourites and history.
  final List<String> legacyIds;

  /// True when the dial string still contains blanks (Arabic words or brackets).
  bool get requiresInput => _arabicRun.hasMatch(code) || _brackets.hasMatch(code);

  /// Multi-step instructions (`... ثم ...`) can only be copied, never dialled.
  bool get isMultiStep => code.contains('ثم');

  bool get canFill => requiresInput && !isMultiStep && !_brackets.hasMatch(code) && fields.isNotEmpty;

  List<TemplateField> get fields => _arabicRun
      .allMatches(code)
      .map((m) => _fieldFor(m.group(0)!))
      .toList(growable: false);

  /// Replaces each blank with the matching value; empty values keep the blank.
  String fill(List<String> values) {
    var index = 0;
    return code.replaceAllMapped(_arabicRun, (match) {
      final value = index < values.length ? toLatinDigits(values[index]).trim() : '';
      index++;
      return value.isEmpty ? match.group(0)! : value;
    });
  }

  String get shareText {
    final buffer = StringBuffer()
      ..writeln(title)
      ..writeln('$providerName • $category')
      ..writeln('الكود: $code');
    if (description.isNotEmpty) buffer.writeln(description);
    buffer.write(verified
        ? 'تمت مراجعته من مصدر الشركة.'
        : 'لم تتم مراجعته رسميًا؛ تأكد من الشركة قبل الاستخدام.');
    return buffer.toString();
  }

  static TemplateField _fieldFor(String label) {
    if (label.contains('مبلغ')) return TemplateField(label, TemplateFieldKind.amount);
    const phoneHints = ['موبايل', 'تليفون', 'هاتف', 'مستلم', 'الخط'];
    if (phoneHints.any(label.contains)) return TemplateField(label, TemplateFieldKind.phone);
    return TemplateField(label, TemplateFieldKind.digits);
  }

  factory MobileCode.fromJson(Map<String, dynamic> json) => MobileCode(
        id: json['id'] as String,
        providerId: json['providerId'] as String,
        providerName: json['providerName'] as String,
        title: json['title'] as String,
        code: json['code'] as String,
        category: json['category'] as String,
        description: (json['description'] as String?) ?? '',
        verified: json['verified'] == true,
        sourceUrl: (json['sourceUrl'] as String?) ?? '',
        systems: (json['systems'] as String?) ?? 'كل الأنظمة',
        eligibility: (json['eligibility'] as String?) ?? '',
        legacyIds: (json['legacyIds'] as List?)?.whereType<String>().toList(growable: false) ?? const [],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'providerId': providerId,
        'providerName': providerName,
        'title': title,
        'code': code,
        'category': category,
        'description': description,
        'verified': verified,
        'sourceUrl': sourceUrl,
        'systems': systems,
        'eligibility': eligibility,
        if (legacyIds.isNotEmpty) 'legacyIds': legacyIds,
      };
}
