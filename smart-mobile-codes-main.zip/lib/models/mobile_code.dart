class MobileCode {
  const MobileCode({
    required this.id,
    required this.providerId,
    required this.providerName,
    required this.title,
    required this.code,
    required this.category,
    this.description = '',
    this.verified = false,
    this.sourceUrl = '',
    this.systems = 'كل الأنظمة',
  });

  final String id;
  final String providerId;
  final String providerName;
  final String title;
  final String code;
  final String category;
  final String description;
  final bool verified;
  final String sourceUrl;
  final String systems;
  bool get requiresInput => RegExp(r'[ء-ي\[\]{}<>]').hasMatch(code);

  factory MobileCode.fromJson(Map<String, dynamic> json) => MobileCode(
        id: json['id'] as String,
        providerId: json['providerId'] as String,
        providerName: json['providerName'] as String,
        title: json['title'] as String,
        code: json['code'] as String,
        category: json['category'] as String,
        description: (json['description'] as String?) ?? '',
        verified: json['verified'] == true,
        sourceUrl: (json['sourceUrl'] as String?) ?? '',
        systems: (json['systems'] as String?) ?? 'كل الأنظمة',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'providerId': providerId,
        'providerName': providerName,
        'title': title,
        'code': code,
        'category': category,
        'description': description,
        'verified': verified,
        'sourceUrl': sourceUrl,
        'systems': systems,
      };
}
