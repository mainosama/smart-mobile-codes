import 'package:flutter/material.dart';

/// Design tokens. One tinted neutral ramp, three text roles, one accent (gold,
/// taken from the logo). Carrier colours appear only as small markers.
class AppColors {
  const AppColors({
    required this.bg,
    required this.surface,
    required this.surfaceMuted,
    required this.line,
    required this.textPrimary,
    required this.textSecondary,
    required this.textTertiary,
    required this.primary,
    required this.onPrimary,
    required this.accent,
    required this.readoutBg,
    required this.readoutText,
    required this.positive,
  });

  final Color bg;
  final Color surface;
  final Color surfaceMuted;
  final Color line;
  final Color textPrimary;
  final Color textSecondary;
  final Color textTertiary;
  final Color primary;
  final Color onPrimary;
  final Color accent;
  final Color readoutBg;
  final Color readoutText;
  final Color positive;

  static const light = AppColors(
    bg: Color(0xFFF6F4EF),
    surface: Color(0xFFFFFFFF),
    surfaceMuted: Color(0xFFEFECE5),
    line: Color(0xFFDDD8CC),
    textPrimary: Color(0xFF14202E),
    textSecondary: Color(0xFF515C6B),
    textTertiary: Color(0xFF69727F),
    primary: Color(0xFF0B1F3A),
    onPrimary: Color(0xFFFFFFFF),
    accent: Color(0xFFA9761A),
    readoutBg: Color(0xFF0B1F3A),
    readoutText: Color(0xFFF4EBD3),
    positive: Color(0xFF1E7A4F),
  );

  static const dark = AppColors(
    bg: Color(0xFF0A1424),
    surface: Color(0xFF111E33),
    surfaceMuted: Color(0xFF172742),
    line: Color(0xFF263853),
    textPrimary: Color(0xFFE9EDF3),
    textSecondary: Color(0xFFA6B1C1),
    textTertiary: Color(0xFF8793A6),
    primary: Color(0xFFE6B95C),
    onPrimary: Color(0xFF0A1424),
    accent: Color(0xFFE6B95C),
    readoutBg: Color(0xFF0A1424),
    readoutText: Color(0xFFF4EBD3),
    positive: Color(0xFF5CC596),
  );

  static AppColors of(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark ? dark : light;
}

const appFontFamily = 'IBMPlexSansArabic';

/// Radii: controls 12, cards 16, sheets 20 (inner = outer minus padding).
const double kControlRadius = 12;
const double kCardRadius = 16;

ThemeData buildAppTheme(Brightness brightness) {
  final c = brightness == Brightness.dark ? AppColors.dark : AppColors.light;
  final scheme = ColorScheme.fromSeed(
    seedColor: const Color(0xFF0B1F3A),
    brightness: brightness,
  ).copyWith(
    primary: c.primary,
    onPrimary: c.onPrimary,
    secondary: c.accent,
    surface: c.surface,
    onSurface: c.textPrimary,
    onSurfaceVariant: c.textSecondary,
    outline: c.line,
    outlineVariant: c.line,
    surfaceContainerLowest: c.surface,
    surfaceContainerLow: c.surface,
    surfaceContainer: c.surface,
    surfaceContainerHigh: c.surface,
    surfaceContainerHighest: c.surfaceMuted,
  );
  final base = ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: scheme,
    fontFamily: appFontFamily,
  );
  final control = RoundedRectangleBorder(borderRadius: BorderRadius.circular(kControlRadius));
  OutlineInputBorder inputBorder(Color color, [double width = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(kControlRadius),
        borderSide: BorderSide(color: color, width: width),
      );

  return base.copyWith(
    scaffoldBackgroundColor: c.bg,
    textTheme: base.textTheme.apply(bodyColor: c.textPrimary, displayColor: c.textPrimary),
    dividerTheme: DividerThemeData(color: c.line, thickness: 1, space: 1),
    appBarTheme: AppBarTheme(
      backgroundColor: c.bg,
      foregroundColor: c.textPrimary,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
    ),
    cardTheme: CardThemeData(
      color: c.surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kCardRadius),
        side: BorderSide(color: c.line),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: c.surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: TextStyle(color: c.textTertiary),
      border: inputBorder(c.line),
      enabledBorder: inputBorder(c.line),
      focusedBorder: inputBorder(c.primary, 1.5),
      errorBorder: inputBorder(scheme.error),
      focusedErrorBorder: inputBorder(scheme.error, 1.5),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: c.primary,
        foregroundColor: c.onPrimary,
        minimumSize: const Size(0, 48),
        shape: control,
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: c.textPrimary,
        side: BorderSide(color: c.line),
        minimumSize: const Size(0, 48),
        shape: control,
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: c.primary,
        shape: control,
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(
        foregroundColor: c.textPrimary,
        shape: control,
      ),
    ),
    listTileTheme: ListTileThemeData(
      iconColor: c.textSecondary,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: c.surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: c.primary.withValues(alpha: .12),
      height: 68,
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return TextStyle(
          fontSize: 12,
          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
          color: selected ? c.textPrimary : c.textSecondary,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(size: 24, color: selected ? c.primary : c.textSecondary);
      }),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: c.readoutBg,
      contentTextStyle: TextStyle(color: c.readoutText, fontFamily: appFontFamily),
      shape: control,
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: c.surface,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    ),
    switchTheme: SwitchThemeData(
      trackColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? c.primary : c.surfaceMuted,
      ),
      thumbColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? c.onPrimary : c.textSecondary,
      ),
      trackOutlineColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? c.primary : c.line,
      ),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: c.primary,
      linearTrackColor: c.surfaceMuted,
    ),
  );
}
