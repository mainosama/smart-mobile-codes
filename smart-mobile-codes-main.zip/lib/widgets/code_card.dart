import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/mobile_code.dart';

class CodeCard extends StatelessWidget {
  const CodeCard({
    super.key,
    required this.item,
    required this.favorite,
    required this.onFavorite,
    required this.onDial,
    required this.onCopy,
    required this.onShare,
    this.compact = false,
  });

  final MobileCode item;
  final bool favorite;
  final VoidCallback onFavorite;
  final VoidCallback onDial;
  final VoidCallback onCopy;
  final VoidCallback onShare;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.only(bottom: compact ? 6 : 12),
      child: Padding(
        padding: EdgeInsets.all(compact ? 11 : 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text(item.title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
              IconButton(tooltip: favorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة', onPressed: onFavorite, icon: Icon(favorite ? Icons.star_rounded : Icons.star_border_rounded, color: favorite ? Colors.amber : null)),
            ]),
            Text('${item.providerName}  •  ${item.category}', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color.onSurfaceVariant)),
            SizedBox(height: compact ? 7 : 12),
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 14, vertical: compact ? 8 : 12),
              decoration: BoxDecoration(color: color.surfaceContainerHighest.withValues(alpha: .55), borderRadius: BorderRadius.circular(14)),
              child: SelectableText(item.code, textAlign: TextAlign.center, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            ),
            if (item.description.isNotEmpty) ...[const SizedBox(height: 8), Text(item.description, style: Theme.of(context).textTheme.bodySmall)],
            if (item.verified) ...[
              const SizedBox(height: 8),
              const Row(children: [Icon(Icons.verified, size: 15, color: Colors.green), SizedBox(width: 5), Text('تمت مراجعته من مصدر رسمي', style: TextStyle(fontSize: 11, color: Colors.green))]),
            ],
            if (!item.verified) ...[
              const SizedBox(height: 8),
              const Row(children: [Icon(Icons.info_outline, size: 15, color: Colors.orange), SizedBox(width: 5), Expanded(child: Text('كود غير متحقق منه رسمياً؛ راجع الشركة قبل استخدامه', style: TextStyle(fontSize: 11, color: Colors.orange))) ]),
            ],
            const SizedBox(height: 10),
            Row(children: [
              if (item.sourceUrl.isNotEmpty)
                IconButton(
                  tooltip: 'عرض المصدر الرسمي',
                  onPressed: () async {
                    final uri = Uri.tryParse(item.sourceUrl);
                    if (uri != null) {
                      await launchUrl(uri, mode: LaunchMode.externalApplication);
                    }
                  },
                  icon: const Icon(Icons.open_in_new),
                ),
              Expanded(child: FilledButton.icon(onPressed: onDial, icon: const Icon(Icons.call), label: const Text('فتح الاتصال'))),
              const SizedBox(width: 8),
              OutlinedButton.icon(onPressed: onCopy, icon: const Icon(Icons.copy), label: const Text('نسخ')),
              const SizedBox(width: 6),
              IconButton(
                tooltip: 'نسخ تفاصيل الكود للمشاركة',
                onPressed: onShare,
                icon: const Icon(Icons.share_outlined),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
