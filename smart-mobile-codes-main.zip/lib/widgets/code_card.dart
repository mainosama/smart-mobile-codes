import 'package:flutter/material.dart';

import '../data/carriers.dart';
import '../models/mobile_code.dart';
import '../state/app_controller.dart';
import '../theme/app_theme.dart';
import 'code_actions.dart';
import 'code_text.dart';

class CodeCard extends StatelessWidget {
  const CodeCard({super.key, required this.item});

  final MobileCode item;

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final c = AppColors.of(context);
    final text = Theme.of(context).textTheme;
    final compact = app.compactCards;
    final favorite = app.favorites.contains(item.id);
    final carrier = carrierById(item.providerId);
    final eligibility = item.eligibility.isNotEmpty ? item.eligibility : item.systems;

    final (label, icon) = item.canFill
        ? ('أكمل البيانات', Icons.edit_note_rounded)
        : item.requiresInput
            ? ('نسخ الخطوات', Icons.copy_rounded)
            : ('اتصل', Icons.call_rounded);

    return Card(
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, compact ? 8 : 12, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(color: carrier?.color ?? c.textTertiary, shape: BoxShape.circle),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${item.providerName} · ${item.category}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: text.labelMedium?.copyWith(color: c.textSecondary),
                  ),
                ),
                IconButton(
                  tooltip: favorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة',
                  visualDensity: VisualDensity.compact,
                  onPressed: () => CodeActions.toggleFavorite(context, item),
                  icon: Icon(
                    favorite ? Icons.star_rounded : Icons.star_outline_rounded,
                    color: favorite ? c.accent : c.textSecondary,
                  ),
                ),
              ],
            ),
            Text(item.title, style: text.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            CodeReadout(item.code, compact: compact),
            if (item.description.isNotEmpty && !compact) ...[
              const SizedBox(height: 12),
              Text(item.description, style: text.bodyMedium?.copyWith(color: c.textSecondary, height: 1.5)),
            ],
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  item.verified ? Icons.verified_outlined : Icons.info_outline_rounded,
                  size: 16,
                  color: item.verified ? c.positive : c.textSecondary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    item.verified
                        ? 'مراجَع من مصدر الشركة · $eligibility'
                        : 'لم تتم مراجعته رسميًا · $eligibility',
                    style: text.labelMedium?.copyWith(color: c.textSecondary, height: 1.4),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => CodeActions.primary(context, item),
                    icon: Icon(icon, size: 20),
                    label: Text(label),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.outlined(
                  tooltip: 'نسخ الكود',
                  onPressed: () => CodeActions.copy(context, item),
                  icon: const Icon(Icons.copy_rounded, size: 20),
                ),
                const SizedBox(width: 4),
                IconButton.outlined(
                  tooltip: 'مشاركة',
                  onPressed: () => CodeActions.share(context, item),
                  icon: const Icon(Icons.ios_share_rounded, size: 20),
                ),
                if (item.sourceUrl.isNotEmpty) ...[
                  const SizedBox(width: 4),
                  IconButton.outlined(
                    tooltip: 'فتح مصدر الشركة',
                    onPressed: () => CodeActions.openSource(context, item),
                    icon: const Icon(Icons.open_in_new_rounded, size: 20),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
