import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Dial strings must always read left-to-right. Inside an RTL layout the
/// neutral characters `*` and `#` would otherwise be reordered (`*555#` could
/// render as `#555*`).
class CodeText extends StatelessWidget {
  const CodeText(this.code, {super.key, this.style, this.textAlign = TextAlign.center});

  final String code;
  final TextStyle? style;
  final TextAlign textAlign;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Text(code, style: style, textAlign: textAlign),
    );
  }
}

/// The signature element: the code shown like a dialler display.
class CodeReadout extends StatelessWidget {
  const CodeReadout(this.code, {super.key, this.compact = false});

  final String code;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: compact ? 10 : 14),
      decoration: BoxDecoration(
        color: c.readoutBg,
        borderRadius: BorderRadius.circular(kControlRadius),
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: CodeText(
          code,
          style: TextStyle(
            fontSize: compact ? 20 : 24,
            fontWeight: FontWeight.w500,
            letterSpacing: .5,
            color: c.readoutText,
            fontFeatures: const [FontFeature.tabularFigures()],
          ),
        ),
      ),
    );
  }
}
