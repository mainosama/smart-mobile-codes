import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/mobile_code.dart';
import '../services/dialer_service.dart';
import '../state/app_controller.dart';
import '../theme/app_theme.dart';
import '../utils/digits.dart';
import 'code_text.dart';

/// All user actions on a code, in one place so every screen behaves the same.
class CodeActions {
  const CodeActions._();

  static void toast(BuildContext context, String message) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    messenger
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  static Future<void> toggleFavorite(BuildContext context, MobileCode item) {
    return AppScope.read(context).toggleFavorite(item.id);
  }

  /// Primary button: dial, fill-then-dial, or copy depending on the code.
  static Future<void> primary(BuildContext context, MobileCode item) async {
    if (item.canFill) {
      final filled = await showFillSheet(context, item);
      if (filled == null || !context.mounted) return;
      await dial(context, item, filled);
      return;
    }
    if (item.requiresInput) {
      await copy(context, item);
      return;
    }
    await dial(context, item, item.code);
  }

  static Future<void> dial(BuildContext context, MobileCode item, String code) async {
    final app = AppScope.read(context);
    if (app.haptics) HapticFeedback.selectionClick();
    if (app.confirmBeforeDial) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (_) => _ConfirmDial(item: item, code: code),
      );
      if (ok != true || !context.mounted) return;
    }
    final launched = await DialerService().dial(code);
    if (launched) {
      await app.recordRecent(item.id);
    } else if (context.mounted) {
      toast(context, 'تعذر فتح تطبيق الاتصال على هذا الجهاز');
    }
  }

  static Future<void> copy(BuildContext context, MobileCode item) async {
    await Clipboard.setData(ClipboardData(text: item.code));
    if (context.mounted) {
      toast(context, item.requiresInput ? 'تم نسخ القالب' : 'تم نسخ الكود');
    }
  }

  static Future<void> share(BuildContext context, MobileCode item) async {
    try {
      await Share.share(item.shareText, subject: item.title);
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: item.shareText));
      if (context.mounted) toast(context, 'تعذرت المشاركة، تم نسخ التفاصيل بدلًا منها');
    }
  }

  static Future<void> openSource(BuildContext context, MobileCode item) async {
    final uri = Uri.tryParse(item.sourceUrl);
    var opened = false;
    if (uri != null && uri.scheme == 'https') {
      try {
        opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      } catch (_) {
        opened = false;
      }
    }
    if (!opened && context.mounted) toast(context, 'تعذر فتح رابط المصدر');
  }
}

class _ConfirmDial extends StatelessWidget {
  const _ConfirmDial({required this.item, required this.code});
  final MobileCode item;
  final String code;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    final note = item.verified
        ? 'هيتم فتح تطبيق الاتصال بالكود، ولن يتم الاتصال تلقائيًا.'
        : 'الكود ده لم تتم مراجعته رسميًا. ممكن ما يشتغلش، وممكن تتطبق رسوم.';
    return AlertDialog(
      title: const Text('فتح تطبيق الاتصال؟'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CodeReadout(code, compact: true),
          const SizedBox(height: 16),
          Text(note, style: TextStyle(color: c.textSecondary, height: 1.5)),
          const SizedBox(height: 8),
          Text(
            'لو عندك شريحتين، اختر الشريحة من تطبيق الاتصال.',
            style: TextStyle(color: c.textTertiary, fontSize: 12, height: 1.5),
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('متابعة')),
      ],
    );
  }
}

/// Asks for the blanks of a template and returns the finished dial string.
Future<String?> showFillSheet(BuildContext context, MobileCode item) {
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => _FillSheet(item: item),
  );
}

class _FillSheet extends StatefulWidget {
  const _FillSheet({required this.item});
  final MobileCode item;

  @override
  State<_FillSheet> createState() => _FillSheetState();
}

class _FillSheetState extends State<_FillSheet> {
  final _form = GlobalKey<FormState>();
  late final List<TextEditingController> _controllers = List.generate(
    widget.item.fields.length,
    (_) => TextEditingController(),
  );

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  String get _preview => widget.item.fill(_controllers.map((c) => c.text).toList());

  void _submit() {
    if (_form.currentState?.validate() ?? false) Navigator.pop(context, _preview);
  }

  Future<void> _copy() async {
    if (!(_form.currentState?.validate() ?? false)) return;
    await Clipboard.setData(ClipboardData(text: _preview));
    if (!mounted) return;
    CodeActions.toast(context, 'تم نسخ الكود');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    final fields = widget.item.fields;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Form(
          key: _form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(widget.item.title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text('املأ البيانات وهيتجهز الكود تلقائيًا', style: TextStyle(color: c.textSecondary)),
              const SizedBox(height: 16),
              CodeReadout(_preview, compact: true),
              const SizedBox(height: 16),
              for (var i = 0; i < fields.length; i++) ...[
                TextFormField(
                  controller: _controllers[i],
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9\u0660-\u0669]'))],
                  decoration: InputDecoration(labelText: fields[i].label),
                  validator: (value) => fields[i].validate(toLatinDigits(value ?? '')),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 12),
              ],
              const SizedBox(height: 4),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _submit,
                      icon: const Icon(Icons.call_rounded, size: 20),
                      label: const Text('متابعة'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                    onPressed: _copy,
                    icon: const Icon(Icons.copy_rounded, size: 20),
                    label: const Text('نسخ'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
