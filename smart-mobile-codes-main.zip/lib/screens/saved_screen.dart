import 'package:flutter/material.dart';

import '../state/app_controller.dart';
import '../widgets/code_card.dart';
import '../widgets/empty_state.dart';
import '../widgets/pill.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key, required this.onOpenDirectory});

  final VoidCallback onOpenDirectory;

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  bool _showRecent = false;

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final items = _showRecent ? app.recentCodes : app.favoriteCodes;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const ScreenHeader(title: 'المحفوظات', subtitle: 'الأكواد اللي بتستخدمها كتير في مكان واحد'),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Row(
                  children: [
                    Pill(
                      label: 'المفضلة',
                      trailing: '${app.favoriteCodes.length}',
                      selected: !_showRecent,
                      onTap: () => setState(() => _showRecent = false),
                    ),
                    const SizedBox(width: 8),
                    Pill(
                      label: 'الأخيرة',
                      trailing: '${app.recentCodes.length}',
                      selected: _showRecent,
                      onTap: () => setState(() => _showRecent = true),
                    ),
                    const Spacer(),
                    if (_showRecent && items.isNotEmpty)
                      TextButton(onPressed: app.clearRecents, child: const Text('مسح السجل')),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (items.isEmpty)
          SliverToBoxAdapter(
            child: EmptyState(
              icon: _showRecent ? Icons.history_rounded : Icons.star_outline_rounded,
              title: _showRecent ? 'لسه ما استخدمتش أي كود' : 'مفيش أكواد في المفضلة',
              message: _showRecent
                  ? 'الأكواد اللي بتفتحها في تطبيق الاتصال من هنا بتظهر في السجل.'
                  : 'اضغط على النجمة في أي كود عشان يظهر هنا.',
              actionLabel: 'فتح الدليل',
              onAction: widget.onOpenDirectory,
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            sliver: SliverList.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, i) => CodeCard(key: ValueKey('saved-${items[i].id}'), item: items[i]),
            ),
          ),
      ],
    );
  }
}
