import 'package:flutter/material.dart';

import '../state/app_controller.dart';
import '../widgets/code_actions.dart';
import '../widgets/code_card.dart';
import '../widgets/empty_state.dart';
import '../widgets/pill.dart';

enum _SavedView { favorites, recent, top }

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key, required this.onOpenDirectory});

  final VoidCallback onOpenDirectory;

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  _SavedView _view = _SavedView.favorites;

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final items = switch (_view) {
      _SavedView.favorites => app.favoriteCodes,
      _SavedView.recent => app.recentCodes,
      _SavedView.top => app.mostUsedCodes,
    };
    final (icon, title, message) = switch (_view) {
      _SavedView.favorites => (
          Icons.star_outline_rounded,
          'مفيش أكواد في المفضلة',
          'اضغط على النجمة في أي كود عشان يظهر هنا.'
        ),
      _SavedView.recent => (
          Icons.history_rounded,
          'لسه ما استخدمتش أي كود',
          'الأكواد اللي بتفتحها في تطبيق الاتصال من هنا بتظهر في السجل.'
        ),
      _SavedView.top => (
          Icons.trending_up_rounded,
          'مفيش أكواد مستخدمة كفاية',
          'الأكواد اللي بتستخدمها أكتر بتترتب هنا تلقائيًا.'
        ),
    };

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ScreenHeader(
                title: 'المحفوظات',
                subtitle: 'الأكواد اللي بتستخدمها كتير في مكان واحد',
                trailing: _view == _SavedView.favorites && items.isNotEmpty
                    ? IconButton(
                        tooltip: 'مشاركة قائمة المفضلة',
                        onPressed: () => CodeActions.shareList(context, 'أكوادي المفضلة من كود موبايل', items),
                        icon: const Icon(Icons.ios_share_rounded),
                      )
                    : null,
              ),
              PillRow(children: [
                Pill(
                  label: 'المفضلة',
                  trailing: '${app.favoriteCodes.length}',
                  selected: _view == _SavedView.favorites,
                  onTap: () => setState(() => _view = _SavedView.favorites),
                ),
                Pill(
                  label: 'الأخيرة',
                  trailing: '${app.recentCodes.length}',
                  selected: _view == _SavedView.recent,
                  onTap: () => setState(() => _view = _SavedView.recent),
                ),
                Pill(
                  label: 'الأكثر استخدامًا',
                  selected: _view == _SavedView.top,
                  onTap: () => setState(() => _view = _SavedView.top),
                ),
              ]),
              if (_view == _SavedView.recent && items.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
                  child: TextButton(onPressed: app.clearRecents, child: const Text('مسح السجل')),
                ),
              const SizedBox(height: 8),
            ],
          ),
        ),
        if (items.isEmpty)
          SliverToBoxAdapter(
            child: EmptyState(
              icon: icon,
              title: title,
              message: message,
              actionLabel: 'فتح الدليل',
              onAction: widget.onOpenDirectory,
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            sliver: SliverList.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, i) => CodeCard(key: ValueKey('saved-${_view.name}-${items[i].id}'), item: items[i]),
            ),
          ),
      ],
    );
  }
}
