import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_info.dart';
import '../services/catalog_service.dart';
import '../state/app_controller.dart';
import '../theme/app_theme.dart';
import '../utils/arabic_date.dart';
import '../widgets/empty_state.dart';
import '../widgets/pill.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _toast(BuildContext context, String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<bool> _confirm(BuildContext context, String title, String body, String action) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(action)),
        ],
      ),
    );
    return result == true;
  }

  Future<void> _backup(BuildContext context, AppController app) async {
    await Clipboard.setData(ClipboardData(text: app.exportBackup()));
    if (context.mounted) _toast(context, 'تم نسخ النسخة الاحتياطية. احتفظ بها في مكان آمن');
  }

  Future<void> _restore(BuildContext context, AppController app) async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('استعادة نسخة احتياطية'),
        content: TextField(
          controller: controller,
          minLines: 5,
          maxLines: 9,
          decoration: const InputDecoration(hintText: 'الصق محتوى النسخة الاحتياطية هنا'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة')),
        ],
      ),
    );
    final raw = controller.text;
    controller.dispose();
    if (confirmed != true) return;
    try {
      await app.importBackup(raw);
      if (context.mounted) _toast(context, 'تمت استعادة المفضلة والسجل والإعدادات');
    } catch (_) {
      if (context.mounted) _toast(context, 'النسخة غير صالحة أو لا تخص هذا التطبيق');
    }
  }

  Future<void> _feedback(BuildContext context) async {
    var opened = false;
    try {
      opened = await launchUrl(Uri.parse(feedbackUrl), mode: LaunchMode.externalApplication);
    } catch (_) {
      opened = false;
    }
    if (!opened && context.mounted) _toast(context, 'تعذر فتح صفحة الملاحظات');
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final c = AppColors.of(context);

    Widget section(String title, List<Widget> children) {
      final separated = <Widget>[];
      for (var i = 0; i < children.length; i++) {
        if (i > 0) separated.add(const Divider());
        separated.add(children[i]);
      }
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(title, style: TextStyle(color: c.textSecondary, fontSize: 13, fontWeight: FontWeight.w600)),
            ),
            Card(clipBehavior: Clip.antiAlias, child: Column(children: separated)),
          ],
        ),
      );
    }

    final origin = switch (app.origin) {
      CatalogOrigin.network => 'محدّث من الإنترنت',
      CatalogOrigin.cached => 'نسخة محفوظة على الجهاز',
      CatalogOrigin.bundled => 'الدليل المدمج في التطبيق',
    };
    final date = app.catalogUpdatedAt == null ? '' : ' · ${formatArabicDate(app.catalogUpdatedAt!)}';

    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        const ScreenHeader(title: 'الإعدادات'),
        section('المظهر', [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(child: _ThemePill('النظام', ThemeMode.system, app)),
                const SizedBox(width: 8),
                Expanded(child: _ThemePill('فاتح', ThemeMode.light, app)),
                const SizedBox(width: 8),
                Expanded(child: _ThemePill('داكن', ThemeMode.dark, app)),
              ],
            ),
          ),
        ]),
        section('السلوك', [
          SwitchListTile(
            title: const Text('تأكيد قبل فتح الاتصال'),
            subtitle: const Text('يعرض تنبيهًا قبل فتح تطبيق الاتصال'),
            value: app.confirmBeforeDial,
            onChanged: app.setConfirmBeforeDial,
          ),
          SwitchListTile(
            title: const Text('اهتزاز خفيف'),
            subtitle: const Text('عند اختيار كود للاتصال'),
            value: app.haptics,
            onChanged: app.setHaptics,
          ),
          SwitchListTile(
            title: const Text('بطاقات مدمجة'),
            subtitle: const Text('تعرض كودات أكتر في الشاشة'),
            value: app.compactCards,
            onChanged: app.setCompactCards,
          ),
        ]),
        section('الدليل', [
          ListTile(
            title: const Text('تحديث الدليل'),
            subtitle: Text('${app.codes.length} خدمة · $origin$date'),
            trailing: app.catalogBusy
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh_rounded),
            onTap: app.catalogBusy
                ? null
                : () async {
                    final result = await app.refreshCatalog(force: true);
                    if (context.mounted) {
                      _toast(context, result == RefreshResult.updated ? 'تم تحديث الدليل' : 'تعذر التحديث الآن');
                    }
                  },
          ),
        ]),
        section('بياناتك على الجهاز', [
          ListTile(
            title: const Text('نسخ احتياطي'),
            subtitle: const Text('ينسخ المفضلة والسجل والإعدادات إلى الحافظة'),
            onTap: () => _backup(context, app),
          ),
          ListTile(
            title: const Text('استعادة نسخة'),
            subtitle: const Text('الصق نسخة احتياطية سابقة'),
            onTap: () => _restore(context, app),
          ),
          ListTile(
            title: const Text('مسح سجل الاستخدام'),
            onTap: () async {
              await app.clearRecents();
              if (context.mounted) _toast(context, 'تم مسح السجل');
            },
          ),
          ListTile(
            title: const Text('مسح كل المفضلة'),
            onTap: () async {
              final ok = await _confirm(
                context,
                'مسح المفضلة؟',
                'هيتم حذف كل الأكواد المحفوظة في المفضلة من هذا الجهاز.',
                'مسح',
              );
              if (!ok) return;
              await app.clearFavorites();
              if (context.mounted) _toast(context, 'تم مسح المفضلة');
            },
          ),
        ]),
        section('عن التطبيق', [
          ListTile(
            title: const Text('إرسال ملاحظة أو تصحيح كود'),
            subtitle: const Text('يفتح صفحة الملاحظات على GitHub'),
            onTap: () => _feedback(context),
          ),
          const ListTile(
            title: Text('الخصوصية'),
            subtitle: Text('المفضلة والسجل محفوظان على جهازك فقط. التطبيق لا يقرأ مكالماتك ولا جهات اتصالك.'),
          ),
          ListTile(
            title: const Text('كود موبايل'),
            subtitle: Text('الإصدار $appVersion ($appBuildNumber)\nراجع الشركة قبل استخدام أي كود قد تترتب عليه رسوم.'),
            isThreeLine: true,
          ),
        ]),
      ],
    );
  }
}

class _ThemePill extends StatelessWidget {
  const _ThemePill(this.label, this.mode, this.app);

  final String label;
  final ThemeMode mode;
  final AppController app;

  @override
  Widget build(BuildContext context) {
    return Pill(label: label, selected: app.themeMode == mode, onTap: () => app.setThemeMode(mode));
  }
}
