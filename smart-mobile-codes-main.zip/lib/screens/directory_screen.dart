import 'package:flutter/material.dart';

import '../data/carriers.dart';
import '../services/catalog_service.dart';
import '../state/app_controller.dart';
import '../state/directory_filters.dart';
import '../theme/app_theme.dart';
import '../utils/arabic_date.dart';
import '../widgets/code_card.dart';
import '../widgets/empty_state.dart';
import '../widgets/pill.dart';

class DirectoryScreen extends StatefulWidget {
  const DirectoryScreen({super.key, required this.filters});

  final DirectoryFilters filters;

  @override
  State<DirectoryScreen> createState() => _DirectoryScreenState();
}

class _DirectoryScreenState extends State<DirectoryScreen> {
  late final TextEditingController _search = TextEditingController(text: widget.filters.query);

  @override
  void initState() {
    super.initState();
    widget.filters.addListener(_syncField);
  }

  void _syncField() {
    if (_search.text != widget.filters.query) _search.text = widget.filters.query;
  }

  @override
  void dispose() {
    widget.filters.removeListener(_syncField);
    _search.dispose();
    super.dispose();
  }

  String _freshness(AppController app) {
    final date = app.catalogUpdatedAt == null ? '' : formatArabicDate(app.catalogUpdatedAt!);
    final source = switch (app.origin) {
      CatalogOrigin.network => 'محدّث',
      CatalogOrigin.cached => 'نسخة محفوظة',
      CatalogOrigin.bundled => 'الدليل المدمج',
    };
    return date.isEmpty ? source : '$source · $date';
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final c = AppColors.of(context);
    final filters = widget.filters;

    return ListenableBuilder(
      listenable: filters,
      builder: (context, _) {
        final results = filters.apply(app.codes);
        final categories = orderedCategories(app.codes.map((e) => e.category));
        final systems = filters.provider == 'all'
            ? <String>[]
            : (app.codes
                .where((e) => e.providerId == filters.provider)
                .map((e) => e.systems)
                .where((s) => s != DirectoryFilters.allSystems)
                .toSet()
                .toList()
              ..sort());

        return CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ScreenHeader(
                    title: 'كود موبايل',
                    subtitle: '${app.codes.length} خدمة · ${_freshness(app)}',
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.asset('assets/app_logo.png', width: 40, height: 40, fit: BoxFit.cover),
                    ),
                    trailing: app.catalogBusy
                        ? const Padding(
                            padding: EdgeInsets.all(12),
                            child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                          )
                        : IconButton(
                            tooltip: 'تحديث الدليل',
                            onPressed: () async {
                              final messenger = ScaffoldMessenger.of(context);
                              final result = await app.refreshCatalog(force: true);
                              messenger
                                ..hideCurrentSnackBar()
                                ..showSnackBar(SnackBar(
                                  content: Text(result == RefreshResult.updated
                                      ? 'تم تحديث الدليل'
                                      : 'تعذر التحديث الآن، الدليل المعروض هو آخر نسخة متاحة'),
                                ));
                            },
                            icon: const Icon(Icons.refresh_rounded),
                          ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                    child: TextField(
                      controller: _search,
                      onChanged: (value) => filters.update(query: value),
                      onSubmitted: app.rememberSearch,
                      textInputAction: TextInputAction.search,
                      decoration: InputDecoration(
                        hintText: 'ابحث: رصيد، تحويل، 555، فودافون',
                        prefixIcon: const Icon(Icons.search_rounded),
                        suffixIcon: _search.text.isEmpty
                            ? null
                            : IconButton(
                                tooltip: 'مسح البحث',
                                onPressed: () {
                                  _search.clear();
                                  filters.update(query: '');
                                },
                                icon: const Icon(Icons.close_rounded),
                              ),
                      ),
                    ),
                  ),
                  if (filters.query.trim().isEmpty && app.recentSearches.isNotEmpty) ...[
                    PillRow(children: [
                      for (final term in app.recentSearches)
                        Pill(label: term, selected: false, onTap: () => filters.update(query: term)),
                      Pill(label: 'مسح البحث السابق', selected: false, onTap: app.clearRecentSearches),
                    ]),
                    const SizedBox(height: 8),
                  ],
                  PillRow(children: [
                    Pill(
                      label: 'كل الشركات',
                      selected: filters.provider == 'all',
                      onTap: () => filters.update(provider: 'all'),
                    ),
                    for (final carrier in carriers)
                      Pill(
                        label: carrier.name,
                        dotColor: carrier.color,
                        trailing: '${app.codes.where((e) => e.providerId == carrier.id).length}',
                        selected: filters.provider == carrier.id,
                        onTap: () => filters.update(provider: carrier.id),
                      ),
                  ]),
                  const SizedBox(height: 8),
                  PillRow(children: [
                    Pill(
                      label: 'كل التصنيفات',
                      selected: filters.category == DirectoryFilters.allCategories,
                      onTap: () => filters.update(category: DirectoryFilters.allCategories),
                    ),
                    for (final category in categories)
                      Pill(
                        label: category,
                        selected: filters.category == category,
                        onTap: () => filters.update(category: category),
                      ),
                  ]),
                  if (systems.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    PillRow(children: [
                      Pill(
                        label: 'كل الأنظمة',
                        selected: filters.system == DirectoryFilters.allSystems,
                        onTap: () => filters.update(system: DirectoryFilters.allSystems),
                      ),
                      for (final system in systems)
                        Pill(
                          label: system,
                          selected: filters.system == system,
                          onTap: () => filters.update(system: system),
                        ),
                    ]),
                  ],
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 8, 8),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${results.length} نتيجة',
                            style: TextStyle(color: c.textSecondary, fontSize: 13),
                          ),
                        ),
                        FilterChipToggle(
                          label: 'المراجَعة فقط',
                          selected: filters.verifiedOnly,
                          onTap: () => filters.update(verifiedOnly: !filters.verifiedOnly),
                        ),
                        PopupMenuButton<DirectorySort>(
                          tooltip: 'الترتيب',
                          icon: const Icon(Icons.sort_rounded),
                          onSelected: (value) => filters.update(sort: value),
                          itemBuilder: (_) => [
                            CheckedPopupMenuItem(
                              value: DirectorySort.recommended,
                              checked: filters.sort == DirectorySort.recommended,
                              child: const Text('الترتيب الافتراضي'),
                            ),
                            CheckedPopupMenuItem(
                              value: DirectorySort.title,
                              checked: filters.sort == DirectorySort.title,
                              child: const Text('حسب الاسم'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (results.isEmpty)
              SliverToBoxAdapter(
                child: EmptyState(
                  icon: Icons.search_off_rounded,
                  title: 'مفيش نتائج مطابقة',
                  message: 'جرّب كلمات أبسط أو شيل بعض الفلاتر.',
                  actionLabel: filters.hasFilters ? 'مسح الفلاتر' : null,
                  onAction: filters.hasFilters
                      ? () {
                          filters.reset();
                          _search.clear();
                        }
                      : null,
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                sliver: SliverList.separated(
                  itemCount: results.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, index) => CodeCard(key: ValueKey(results[index].id), item: results[index]),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// Small on/off toggle that sits in the results header.
class FilterChipToggle extends StatelessWidget {
  const FilterChipToggle({super.key, required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    return TextButton.icon(
      onPressed: onTap,
      style: TextButton.styleFrom(foregroundColor: selected ? c.primary : c.textSecondary),
      icon: Icon(selected ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded, size: 20),
      label: Text(label),
    );
  }
}
