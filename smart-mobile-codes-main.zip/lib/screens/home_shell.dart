import 'package:flutter/material.dart';

import '../state/app_controller.dart';
import '../state/directory_filters.dart';
import 'assistant_screen.dart';
import 'directory_screen.dart';
import 'saved_screen.dart';
import 'settings_screen.dart';
import 'tools_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final _filters = DirectoryFilters();
  int _tab = 0;

  @override
  void dispose() {
    _filters.dispose();
    super.dispose();
  }

  void _openDirectory() => setState(() => _tab = 0);

  void _showInDirectory(String query, String? providerId) {
    _filters.reset();
    _filters.update(query: query, provider: providerId);
    setState(() => _tab = 0);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: _tab,
          children: [
            DirectoryScreen(filters: _filters),
            SavedScreen(onOpenDirectory: _openDirectory),
            AssistantScreen(codes: app.codes, onShowResults: _showInDirectory),
            ToolsScreen(onShowCarrier: (id) => _showInDirectory('', id)),
            const SettingsScreen(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dialpad_outlined), selectedIcon: Icon(Icons.dialpad_rounded), label: 'الدليل'),
          NavigationDestination(icon: Icon(Icons.star_outline_rounded), selectedIcon: Icon(Icons.star_rounded), label: 'المحفوظات'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline_rounded), selectedIcon: Icon(Icons.chat_bubble_rounded), label: 'اسأل'),
          NavigationDestination(icon: Icon(Icons.handyman_outlined), selectedIcon: Icon(Icons.handyman_rounded), label: 'الأدوات'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
