import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/carriers.dart';
import '../models/mobile_code.dart';
import '../theme/app_theme.dart';
import '../utils/assistant_engine.dart';
import '../widgets/code_text.dart';
import '../widgets/empty_state.dart';
import '../widgets/pill.dart';

/// "Ask the directory": understands short questions in Arabic and answers with
/// matching codes. Runs entirely on the device; it is not a generative model.
class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key, required this.codes, required this.onShowResults});

  final List<MobileCode> codes;

  /// Opens the directory with the same search (and carrier, when detected).
  final void Function(String query, String? providerId) onShowResults;

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _Message {
  const _Message.user(this.text)
      : fromAssistant = false,
        answer = null;
  const _Message.assistant(this.text, this.answer) : fromAssistant = true;

  final String text;
  final bool fromAssistant;
  final AssistantAnswer? answer;
}

class _AssistantScreenState extends State<AssistantScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<_Message> _messages = [];
  String _provider = 'all';

  static const _quickPrompts = <String>[
    'معرفة الرصيد',
    'تحويل رصيد',
    'سلفني',
    'شحن كارت',
    'باقات الإنترنت',
    'خدمة العملاء',
    'المحفظة الإلكترونية',
  ];

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _ask(String raw) {
    final question = raw.trim();
    if (question.isEmpty) return;
    _input.clear();
    final answer = answerQuestion(widget.codes, question, providerFilter: _provider);
    setState(() {
      _messages
        ..add(_Message.user(question))
        ..add(_Message.assistant(answer.message, answer));
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    return Column(
      children: [
        const ScreenHeader(
          title: 'اسأل الدليل',
          subtitle: 'اكتب اللي عايزه بكلامك. البحث بيتم على جهازك ومش محتاج إنترنت',
        ),
        PillRow(children: [
          Pill(label: 'كل الشركات', selected: _provider == 'all', onTap: () => setState(() => _provider = 'all')),
          for (final carrier in carriers)
            Pill(
              label: carrier.name,
              dotColor: carrier.color,
              selected: _provider == carrier.id,
              onTap: () => setState(() => _provider = carrier.id),
            ),
        ]),
        Expanded(
          child: _messages.isEmpty
              ? SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('جرّب سؤال سريع', style: TextStyle(color: c.textSecondary, fontSize: 13)),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final prompt in _quickPrompts)
                            Pill(label: prompt, selected: false, onTap: () => _ask(prompt)),
                        ],
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) => _Bubble(
                    message: _messages[index],
                    onShowResults: widget.onShowResults,
                  ),
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _input,
                    textInputAction: TextInputAction.send,
                    onSubmitted: _ask,
                    decoration: const InputDecoration(hintText: 'مثال: عايز أحول رصيد على فودافون'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  tooltip: 'إرسال',
                  onPressed: () => _ask(_input.text),
                  icon: const Icon(Icons.arrow_upward_rounded),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.message, required this.onShowResults});

  final _Message message;
  final void Function(String query, String? providerId) onShowResults;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    final answer = message.answer;
    final fromAssistant = message.fromAssistant;
    return Align(
      alignment: fromAssistant ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * .88),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: fromAssistant ? c.surface : c.surfaceMuted,
            borderRadius: BorderRadius.circular(kCardRadius),
            border: Border.all(color: c.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(message.text, style: const TextStyle(height: 1.5)),
              if (answer != null)
                for (final code in answer.results) ...[
                  const SizedBox(height: 12),
                  _ResultTile(code: code),
                ],
              if (answer != null && answer.results.isNotEmpty) ...[
                const SizedBox(height: 8),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton(
                    onPressed: () => onShowResults(answer.searchQuery, answer.providerId),
                    child: const Text('عرض الكل في الدليل'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  const _ResultTile({required this.code});
  final MobileCode code;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 12, 4, 12),
      decoration: BoxDecoration(
        color: c.bg,
        borderRadius: BorderRadius.circular(kControlRadius),
        border: Border.all(color: c.line),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(code.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                const SizedBox(height: 2),
                Text(
                  '${code.providerName}${code.verified ? '' : ' · لم تتم مراجعته رسميًا'}',
                  style: TextStyle(color: c.textSecondary, fontSize: 12),
                ),
                const SizedBox(height: 8),
                CodeText(
                  code.code,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    color: c.textPrimary,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'نسخ الكود',
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: code.code));
              if (context.mounted) {
                ScaffoldMessenger.of(context)
                  ..hideCurrentSnackBar()
                  ..showSnackBar(const SnackBar(content: Text('تم نسخ الكود')));
              }
            },
            icon: const Icon(Icons.copy_rounded, size: 20),
          ),
        ],
      ),
    );
  }
}
