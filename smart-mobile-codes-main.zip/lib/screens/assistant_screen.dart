import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/mobile_code.dart';
import '../utils/search_normalizer.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key, required this.codes, required this.onShowResults});
  final List<MobileCode> codes;
  final ValueChanged<String> onShowResults;

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<_ChatMessage> _messages = [
    const _ChatMessage(
      text: 'أهلًا بيك! أنا مساعد Smart Mobile Codes. أقدر أساعدك تلاقي أكواد الرصيد والإنترنت والتحويل والشحن وخدمة العملاء. أبحث محليًا داخل الدليل دون إرسال سؤالك إلى خادم خارجي؛ الأسعار والعروض الحية تحتاج مصدرًا محدثًا من الشركة. اختار سؤال سريع أو اكتب طلبك.',
      fromAssistant: true,
    ),
  ];
  String _provider = 'all';
  bool _busy = false;

  static const _providers = <(String, String, Color)>[
    ('all', 'كل الشركات', Color(0xFF315C9B)),
    ('vodafone', 'Vodafone', Color(0xFFE53935)),
    ('orange', 'Orange', Color(0xFFFF8A00)),
    ('we', 'WE', Color(0xFF6A35A5)),
    ('etisalat', 'e&', Color(0xFF15966A)),
  ];

  static const _quickPrompts = [
    ('معرفة الرصيد', Icons.account_balance_wallet_outlined),
    ('باقات الإنترنت', Icons.wifi_rounded),
    ('تحويل رصيد', Icons.swap_horiz_rounded),
    ('شحن الرصيد', Icons.add_card_rounded),
    ('خدمة العملاء', Icons.support_agent_rounded),
    ('المحفظة الإلكترونية', Icons.account_balance_rounded),
  ];

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _ask(String raw) {
    final query = raw.trim();
    if (query.isEmpty || _busy) return;
    _input.clear();
    setState(() {
      _busy = true;
      _messages.add(_ChatMessage(text: query, fromAssistant: false));
    });
    final normalized = normalizeSearchText(query);
    final terms = <String>{normalized};
    final groups = <String, List<String>>{
      'الرصيد': ['رصيد', 'رصيدي', 'فلوس', 'balance', 'استعلام'],
      'الإنترنت': ['انترنت', 'نت', 'جيجا', 'ميجابايت', 'ميجا', 'data'],
      'تحويل الرصيد': ['تحويل', 'حول', 'ابعت رصيد', 'transfer'],
      'الشحن': ['شحن', 'اشحن', 'كارت', ' recharge'],
      'خدمة العملاء': ['خدمه العملاء', 'كلم الشركه', 'الدعم', 'customer'],
      'المحفظة': ['محفظه', 'كاش', 'فلوس الموبايل', 'wallet'],
      'الباقات': ['باقه', 'باقة', 'عرض', 'عروض', 'اشتراك'],
    };
    String? detected;
    for (final entry in groups.entries) {
      if (entry.value.any((word) => normalized.contains(normalizeSearchText(word)))) {
        detected = entry.key;
        break;
      }
    }
    final tokens = detected == null ? terms : <String>{...terms, detected};
    final matches = widget.codes.where((code) {
      if (_provider != 'all' && code.providerId != _provider) return false;
      final haystack = normalizeSearchText('${code.title} ${code.code} ${code.category} ${code.providerName} ${code.description}');
      return tokens.any((term) => term.isNotEmpty && haystack.contains(term)) ||
          (detected != null && normalizeSearchText('${code.category} ${code.title} ${code.description}').contains(normalizeSearchText(detected)));
    }).take(8).toList();

    String response;
    if (matches.isNotEmpty) {
      response = 'لقيت ${matches.length} نتيجة ممكن تساعدك. راجع وصف الخدمة والشركة قبل استخدام الكود. الأكواد غير الموثقة موضحة بعلامة تنبيه.';
    } else if (detected == 'الباقات' || detected == 'الإنترنت') {
      response = 'لم أجد تفاصيل باقات حية مؤكدة في دليل الأكواد الحالي. تقدر تفتح صفحة الشركة من الرئيسية أو مركز التحكم لمراجعة البيانات التي أُضيفت يدويًا. لا أعرض أسعارًا أو عروضًا غير موثقة.';
    } else {
      response = 'لم أجد تطابقًا واضحًا. جرّب كتابة اسم الخدمة بكلمات أبسط، أو اختر الشركة من أعلى المحادثة، أو افتح الدليل الكامل للبحث يدويًا.';
    }

    if (!mounted) return;
    setState(() {
      _messages.add(_ChatMessage(text: response, fromAssistant: true, results: matches));
      _busy = false;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 260), curve: Curves.easeOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(children: [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF071A35), Color(0xFF123B78), Color(0xFF263D79)]),
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(26)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .12), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white24)), child: const Icon(Icons.auto_awesome_rounded, color: Color(0xFFFFC857), size: 27)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('مركز المساعدة الذكي', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('بحث محلي سريع في دليل الأكواد والخدمات', style: TextStyle(color: Colors.white70, fontSize: 11))])),
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF1D9A70).withValues(alpha: .22), borderRadius: BorderRadius.circular(20)), child: const Row(children: [Icon(Icons.circle, color: Color(0xFF65D6A7), size: 7), SizedBox(width: 5), Text('متاح', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))])),
          ]),
          const SizedBox(height: 14),
          const Text('ابحث داخل شركة محددة', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          SizedBox(height: 36, child: ListView(scrollDirection: Axis.horizontal, children: _providers.map((p) => Padding(padding: const EdgeInsetsDirectional.only(end: 7), child: ChoiceChip(label: Text(p.$2), selected: _provider == p.$1, onSelected: (_) => setState(() => _provider = p.$1), selectedColor: const Color(0xFFFFC857), backgroundColor: Colors.white.withValues(alpha: .10), labelStyle: TextStyle(color: _provider == p.$1 ? const Color(0xFF10244F) : Colors.white, fontWeight: FontWeight.w800, fontSize: 11), side: BorderSide(color: Colors.white.withValues(alpha: .15))))).toList())),
        ]),
      ),
      if (_messages.length == 1) ...[
        Padding(padding: const EdgeInsets.fromLTRB(16, 15, 16, 6), child: Wrap(alignment: WrapAlignment.spaceBetween, crossAxisAlignment: WrapCrossAlignment.center, spacing: 8, runSpacing: 4, children: [Text('ابدأ بسؤال سريع', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)), Text('${widget.codes.length} خدمة في الدليل', style: Theme.of(context).textTheme.bodySmall)])),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Wrap(spacing: 8, runSpacing: 8, children: _quickPrompts.map((p) => ActionChip(avatar: Icon(p.$2, size: 17, color: scheme.primary), label: Text(p.$1), onPressed: () => _ask(p.$1))).toList())),
      ],
      Expanded(child: ListView.builder(controller: _scroll, padding: const EdgeInsets.fromLTRB(14, 12, 14, 10), itemCount: _messages.length + (_busy ? 1 : 0), itemBuilder: (context, index) {
        if (_busy && index == _messages.length) return const Align(alignment: AlignmentDirectional.centerStart, child: Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))));
        final message = _messages[index];
        return Align(alignment: message.fromAssistant ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd, child: ConstrainedBox(constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * .88), child: Container(margin: const EdgeInsets.symmetric(vertical: 5), padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: message.fromAssistant ? Theme.of(context).cardColor : scheme.primaryContainer, borderRadius: BorderRadius.circular(18), border: Border.all(color: Theme.of(context).dividerColor)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (message.fromAssistant) Row(children: [Icon(Icons.auto_awesome, size: 14, color: scheme.primary), const SizedBox(width: 6), Text('المساعد', style: TextStyle(fontSize: 10, color: scheme.primary, fontWeight: FontWeight.w900))]),
          if (message.fromAssistant) const SizedBox(height: 5),
          Text(message.text, style: const TextStyle(fontSize: 13, height: 1.5)),
          if (message.results.isNotEmpty) ...message.results.map((code) => Container(margin: const EdgeInsets.only(top: 9), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: scheme.surfaceContainerHighest.withValues(alpha: .55), borderRadius: BorderRadius.circular(13)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(alignment: WrapAlignment.spaceBetween, crossAxisAlignment: WrapCrossAlignment.center, spacing: 8, runSpacing: 3, children: [ConstrainedBox(constraints: const BoxConstraints(maxWidth: 230), child: Text(code.title, softWrap: true, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12))), Text(code.providerName, softWrap: true, style: TextStyle(color: scheme.primary, fontSize: 10, fontWeight: FontWeight.bold))]),
            const SizedBox(height: 5),
            Row(children: [Expanded(child: SelectableText(code.code, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 1.1))), IconButton(visualDensity: VisualDensity.compact, tooltip: 'نسخ الكود', onPressed: () => Clipboard.setData(ClipboardData(text: code.code)), icon: const Icon(Icons.copy_rounded, size: 18))]),
            Text(code.description, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 5),
            Wrap(crossAxisAlignment: WrapCrossAlignment.center, spacing: 4, runSpacing: 2, children: [Icon(code.verified ? Icons.verified_rounded : Icons.info_outline, size: 13, color: code.verified ? Colors.green : Colors.orange), Text(code.verified ? 'مصدر مراجعة مسجل' : 'غير متحقق منه رسميًا', softWrap: true, style: TextStyle(fontSize: 10, color: code.verified ? Colors.green : Colors.orange, fontWeight: FontWeight.w700))]),
          ]))),
          if (message.fromAssistant && message.results.isNotEmpty) Align(alignment: AlignmentDirectional.centerEnd, child: TextButton.icon(onPressed: () => widget.onShowResults(message.results.first.title), icon: const Icon(Icons.list_alt, size: 16), label: const Text('عرض النتائج في الدليل'))),
        ]))));
      })),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(12, 7, 12, 10), child: Row(children: [Expanded(child: TextField(controller: _input, textInputAction: TextInputAction.send, onSubmitted: _ask, minLines: 1, maxLines: 3, decoration: InputDecoration(hintText: 'اكتب سؤالك هنا...', prefixIcon: const Icon(Icons.chat_bubble_outline), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none)))), const SizedBox(width: 8), IconButton.filled(onPressed: _busy ? null : () => _ask(_input.text), icon: const Icon(Icons.send_rounded), tooltip: 'إرسال')]))),
    ]);
  }
}

class _ChatMessage {
  const _ChatMessage({required this.text, required this.fromAssistant, this.results = const []});
  final String text;
  final bool fromAssistant;
  final List<MobileCode> results;
}
