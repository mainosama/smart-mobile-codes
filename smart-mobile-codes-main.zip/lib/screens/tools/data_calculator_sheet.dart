import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import '../../utils/digits.dart';

Future<void> showDataCalculator(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => const _DataCalculator(),
  );
}

class _DataCalculator extends StatefulWidget {
  const _DataCalculator();

  @override
  State<_DataCalculator> createState() => _DataCalculatorState();
}

class _DataCalculatorState extends State<_DataCalculator> {
  final _total = TextEditingController();
  final _used = TextEditingController();
  final _days = TextEditingController();

  @override
  void dispose() {
    _total.dispose();
    _used.dispose();
    _days.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    final total = parseDecimal(_total.text);
    final used = parseDecimal(_used.text);
    final days = parseDecimal(_days.text);

    String? error;
    if (_total.text.isNotEmpty && _used.text.isNotEmpty) {
      if (total == null || used == null || total <= 0 || used < 0) {
        error = 'راجع الأرقام اللي دخلتها';
      } else if (used > total) {
        error = 'المستهلك أكبر من سعة الباقة';
      }
    }
    double? remaining;
    double? percent;
    double? perDay;
    if (error == null && total != null && used != null && total > 0 && used >= 0 && used <= total) {
      remaining = total - used;
      percent = used / total;
      if (days != null && days > 0) perDay = remaining / days;
    }

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('حاسبة استهلاك الإنترنت',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            TextField(
              controller: _total,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'سعة الباقة', suffixText: 'GB'),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _used,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'المستهلك لحد دلوقتي', suffixText: 'GB'),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _days,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'الأيام المتبقية على التجديد (اختياري)', suffixText: 'يوم'),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 16),
            if (error != null) Text(error, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            if (remaining != null && percent != null) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: c.surfaceMuted,
                  borderRadius: BorderRadius.circular(kControlRadius),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _Row('المتبقي', '${remaining.toStringAsFixed(2)} GB'),
                    const SizedBox(height: 8),
                    _Row('نسبة الاستهلاك', '${(percent * 100).toStringAsFixed(1)}%'),
                    if (perDay != null) ...[
                      const SizedBox(height: 8),
                      _Row('المتاح يوميًا', '${perDay.toStringAsFixed(2)} GB'),
                    ],
                    const SizedBox(height: 12),
                    LinearProgressIndicator(value: percent, minHeight: 8, borderRadius: BorderRadius.circular(4)),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    return Row(
      children: [
        Expanded(child: Text(label, style: TextStyle(color: c.textSecondary))),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w600, fontFeatures: [FontFeature.tabularFigures()]),
          ),
        ),
      ],
    );
  }
}
