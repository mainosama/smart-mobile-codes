import 'package:flutter/material.dart';

import '../../utils/number_carrier.dart';
import '../../theme/app_theme.dart';
import '../../utils/digits.dart';

Future<void> showNumberCarrier(BuildContext context, void Function(String providerId) onShowCarrier) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => _NumberCarrier(onShowCarrier: onShowCarrier),
  );
}

class _NumberCarrier extends StatefulWidget {
  const _NumberCarrier({required this.onShowCarrier});
  final void Function(String providerId) onShowCarrier;

  @override
  State<_NumberCarrier> createState() => _NumberCarrierState();
}

class _NumberCarrierState extends State<_NumberCarrier> {
  final _input = TextEditingController();

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    final text = _input.text.trim();
    final carrier = carrierForNumber(text);
    final looksComplete = normalizeEgyptianMobile(text) != null || toLatinDigits(text).replaceAll(RegExp(r'[^0-9]'), '').length >= 11;

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('اعرف شبكة الرقم',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('اكتب رقم موبايل مصري ونعرفك الشبكة حسب بادئة الرقم.',
                style: TextStyle(color: c.textSecondary, fontSize: 13)),
            const SizedBox(height: 16),
            TextField(
              controller: _input,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'رقم الموبايل', hintText: '01012345678'),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 16),
            if (carrier != null) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: c.surfaceMuted, borderRadius: BorderRadius.circular(kControlRadius)),
                child: Row(
                  children: [
                    Container(width: 10, height: 10, decoration: BoxDecoration(color: carrier.color, shape: BoxShape.circle)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text('الشبكة الأصلية للرقم: ${carrier.name}', style: const TextStyle(fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text('النتيجة حسب بادئة الرقم، وقد تختلف لو الرقم اتنقل لشبكة تانية.',
                  style: TextStyle(color: c.textTertiary, fontSize: 12, height: 1.5)),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  widget.onShowCarrier(carrier.id);
                },
                icon: const Icon(Icons.dialpad_rounded, size: 20),
                label: Text('عرض أكواد ${carrier.name}'),
              ),
            ] else if (text.isNotEmpty && looksComplete)
              Text('مش رقم موبايل مصري صحيح. الأرقام بتبدأ بـ 010 أو 011 أو 012 أو 015.',
                  style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
        ),
      ),
    );
  }
}
