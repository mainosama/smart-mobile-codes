import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import '../../utils/digits.dart';

Future<void> showPlanComparison(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => const _PlanComparison(),
  );
}

class _PlanComparison extends StatefulWidget {
  const _PlanComparison();

  @override
  State<_PlanComparison> createState() => _PlanComparisonState();
}

class _PlanComparisonState extends State<_PlanComparison> {
  final _priceA = TextEditingController();
  final _dataA = TextEditingController();
  final _priceB = TextEditingController();
  final _dataB = TextEditingController();

  @override
  void dispose() {
    for (final c in [_priceA, _dataA, _priceB, _dataB]) {
      c.dispose();
    }
    super.dispose();
  }

  Widget _plan(String title, TextEditingController price, TextEditingController data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: price,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'السعر', suffixText: 'جنيه'),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: data,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'السعة', suffixText: 'GB'),
                onChanged: (_) => setState(() {}),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    final pa = parseDecimal(_priceA.text);
    final da = parseDecimal(_dataA.text);
    final pb = parseDecimal(_priceB.text);
    final db = parseDecimal(_dataB.text);
    String? verdict;
    double? perA;
    double? perB;
    if (pa != null && da != null && pb != null && db != null && pa > 0 && da > 0 && pb > 0 && db > 0) {
      final a = pa / da;
      final b = pb / db;
      perA = a;
      perB = b;
      if ((a - b).abs() < 0.005) {
        verdict = 'تكلفة الجيجا متساوية تقريبًا';
      } else {
        final cheaperFirst = a < b;
        final cheap = cheaperFirst ? a : b;
        final dear = cheaperFirst ? b : a;
        final saving = ((dear - cheap) / dear * 100).toStringAsFixed(0);
        verdict = '${cheaperFirst ? 'الباقة الأولى' : 'الباقة الثانية'} أوفر بنسبة $saving% للجيجا';
      }
    }

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('مقارنة سعر الجيجا',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('اكتب السعر والسعة زي ما هما في عرض الشركة. المقارنة حسابية فقط.',
                style: TextStyle(color: c.textSecondary, fontSize: 13)),
            const SizedBox(height: 16),
            _plan('الباقة الأولى', _priceA, _dataA),
            const SizedBox(height: 16),
            _plan('الباقة الثانية', _priceB, _dataB),
            if (perA != null && perB != null && verdict != null) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: c.surfaceMuted, borderRadius: BorderRadius.circular(kControlRadius)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('الأولى: ${perA.toStringAsFixed(2)} جنيه لكل GB'),
                    const SizedBox(height: 4),
                    Text('الثانية: ${perB.toStringAsFixed(2)} جنيه لكل GB'),
                    const SizedBox(height: 8),
                    Text(verdict, style: const TextStyle(fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
