import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/mobile_code.dart';
import '../../theme/app_theme.dart';
import '../../utils/dial_validation.dart';
import '../../widgets/code_actions.dart';
import '../../widgets/code_text.dart';

Future<void> showManualDial(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => const _ManualDial(),
  );
}

class _ManualDial extends StatefulWidget {
  const _ManualDial();

  @override
  State<_ManualDial> createState() => _ManualDialState();
}

class _ManualDialState extends State<_ManualDial> {
  final _input = TextEditingController();

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _dial() async {
    final code = _input.text.trim();
    if (!isValidDialString(code)) return;
    final item = MobileCode(
      id: 'manual',
      providerId: 'manual',
      providerName: 'يدوي',
      title: 'كود يدوي',
      code: code,
      category: 'يدوي',
    );
    await CodeActions.dial(context, item, code);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    final text = _input.text.trim();
    final valid = isValidDialString(text);

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('اتصال بكود يدوي',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('اكتب أي كود تعرفه، وهيتفتح في تطبيق الاتصال من غير ما يتم الاتصال تلقائيًا.',
                style: TextStyle(color: c.textSecondary, fontSize: 13, height: 1.5)),
            const SizedBox(height: 16),
            if (valid) ...[
              CodeReadout(text, compact: true),
              const SizedBox(height: 16),
            ],
            TextField(
              controller: _input,
              keyboardType: TextInputType.phone,
              textDirection: TextDirection.ltr,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9*#]'))],
              decoration: InputDecoration(
                labelText: 'الكود',
                hintText: '*555#',
                errorText: text.isNotEmpty && !valid ? 'اكتب أرقام و * و # فقط' : null,
              ),
              onChanged: (_) => setState(() {}),
              onSubmitted: (_) => _dial(),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: valid ? _dial : null,
              icon: const Icon(Icons.call_rounded, size: 20),
              label: const Text('فتح الاتصال'),
            ),
          ],
        ),
      ),
    );
  }
}
