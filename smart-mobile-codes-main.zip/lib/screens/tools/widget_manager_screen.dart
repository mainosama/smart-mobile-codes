import 'package:flutter/material.dart';

import '../../services/widget_service.dart';
import '../../state/app_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/code_text.dart';

class WidgetManagerScreen extends StatefulWidget {
  const WidgetManagerScreen({super.key});

  @override
  State<WidgetManagerScreen> createState() => _WidgetManagerScreenState();
}

class _WidgetManagerScreenState extends State<WidgetManagerScreen> {
  final _service = WidgetService();
  bool _busy = false;

  Future<void> _update() async {
    final app = AppScope.read(context);
    final code = app.widgetCodeId == null ? null : app.byId(app.widgetCodeId!);
    if (code == null || _busy) return;
    setState(() => _busy = true);
    final ok = await _service.update(code);
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(ok
            ? 'تم تحديث الويدجت. أضِف ويدجت «كود موبايل» من شاشة الهاتف الرئيسية'
            : 'تعذر تحديث الويدجت على هذا الجهاز'),
      ));
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final c = AppColors.of(context);
    final selected = app.widgetCodeId == null ? null : app.byId(app.widgetCodeId!);

    return Scaffold(
      appBar: AppBar(title: const Text('ويدجت الشاشة الرئيسية')),
      body: app.codes.isEmpty || selected == null
          ? const Center(child: Text('مفيش أكواد متاحة للويدجت دلوقتي'))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  'اختر الكود اللي عايزه على شاشة الهاتف، واضغط تحديث، وبعدها أضِف الويدجت من قائمة الويدجت في الهاتف.',
                  style: TextStyle(color: c.textSecondary, height: 1.5),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  initialValue: selected.id,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'الكود المعروض'),
                  items: [
                    for (final code in app.codes)
                      DropdownMenuItem(
                        value: code.id,
                        child: Text('${code.providerName} — ${code.title}', overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (value) {
                    if (value != null) app.setWidgetCode(value);
                  },
                ),
                const SizedBox(height: 16),
                Text(selected.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                CodeReadout(selected.code),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _busy ? null : _update,
                  icon: _busy
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.widgets_outlined, size: 20),
                  label: const Text('تحديث الويدجت'),
                ),
                const SizedBox(height: 16),
                Text(
                  'الويدجت بيعرض الكود فقط. فتح الاتصال بيتم من داخل التطبيق، ولا يتم أي اتصال تلقائيًا.',
                  style: TextStyle(color: c.textTertiary, fontSize: 12, height: 1.5),
                ),
              ],
            ),
    );
  }
}
