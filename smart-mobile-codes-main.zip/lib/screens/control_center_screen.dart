import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Local workspace for organizing offers, plans and USSD codes on this device.
/// Publishing a shared catalog still requires an authorized remote backend.
class ControlCenterScreen extends StatefulWidget {
  const ControlCenterScreen({super.key});

  @override
  State<ControlCenterScreen> createState() => _ControlCenterScreenState();
}

class _ControlCenterScreenState extends State<ControlCenterScreen> {
  static const _storageKey = 'managed_catalog_entries_v1';
  static const _providers = <String, String>{
    'vodafone': 'Vodafone',
    'orange': 'Orange',
    'etisalat': 'e&',
    'we': 'WE',
  };
  final _search = TextEditingController();
  List<Map<String, dynamic>> _entries = [];
  String _kind = 'all';
  String _provider = 'all';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    var entries = <Map<String, dynamic>>[];
    if (raw != null) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          entries = decoded.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
        }
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() { _entries = entries; _loading = false; });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(_entries));
  }

  List<Map<String, dynamic>> get _visible {
    return _entries.where((e) {
      final kindOk = _kind == 'all' || e['kind'] == _kind;
      final providerOk = _provider == 'all' || e['provider'] == _provider;
      final q = _search.text.trim().toLowerCase();
      final text = '${e['title']} ${e['details']} ${e['code']} ${e['provider']}'.toLowerCase();
      return kindOk && providerOk && (q.isEmpty || text.contains(q));
    }).toList()
      ..sort((a, b) => (b['updatedAt'] as String? ?? '').compareTo(a['updatedAt'] as String? ?? ''));
  }

  Future<void> _editEntry([Map<String, dynamic>? existing]) async {
    final title = TextEditingController(text: existing?['title'] as String? ?? '');
    final details = TextEditingController(text: existing?['details'] as String? ?? '');
    final code = TextEditingController(text: existing?['code'] as String? ?? '');
    final price = TextEditingController(text: existing?['price']?.toString() ?? '');
    final quota = TextEditingController(text: existing?['quota']?.toString() ?? '');
    final validity = TextEditingController(text: existing?['validity'] as String? ?? '');
    final source = TextEditingController(text: existing?['source'] as String? ?? '');
    var kind = existing?['kind'] as String? ?? 'offer';
    var provider = existing?['provider'] as String? ?? 'vodafone';
    var active = existing?['active'] as bool? ?? true;
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, refresh) => AlertDialog(
        title: Text(existing == null ? 'إضافة عنصر جديد' : 'تعديل العنصر'),
        content: SizedBox(width: 440, child: SingleChildScrollView(child: Form(
          key: formKey,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<String>(
              value: kind,
              decoration: const InputDecoration(labelText: 'نوع العنصر'),
              items: const [DropdownMenuItem(value: 'offer', child: Text('عرض')), DropdownMenuItem(value: 'plan', child: Text('باقة')), DropdownMenuItem(value: 'code', child: Text('كود خدمة'))],
              onChanged: (v) => refresh(() => kind = v ?? 'offer'),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: provider,
              decoration: const InputDecoration(labelText: 'الشركة'),
              items: _providers.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
              onChanged: (v) => refresh(() => provider = v ?? 'vodafone'),
            ),
            TextFormField(controller: title, decoration: const InputDecoration(labelText: 'الاسم'), validator: (v) => (v == null || v.trim().isEmpty) ? 'اكتب الاسم' : null),
            TextFormField(controller: details, decoration: const InputDecoration(labelText: 'الوصف والتفاصيل'), minLines: 2, maxLines: 4),
            if (kind == 'code') TextFormField(controller: code, decoration: const InputDecoration(labelText: 'كود الخدمة', hintText: '*123#'), validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل الكود' : null),
            if (kind != 'code') ...[
              Row(children: [Expanded(child: TextFormField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر (جنيه)'))), const SizedBox(width: 10), Expanded(child: TextFormField(controller: quota, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعة (GB/وحدة)')))]),
              TextFormField(controller: validity, decoration: const InputDecoration(labelText: 'الصلاحية / تاريخ الانتهاء')),
            ],
            TextFormField(controller: source, decoration: const InputDecoration(labelText: 'رابط المصدر الرسمي (اختياري)'), keyboardType: TextInputType.url),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('العنصر نشط'), value: active, onChanged: (v) => refresh(() => active = v)),
            const Text('البيانات هنا تُحفظ على هذا الهاتف فقط، ولا تُنشر تلقائيًا للمستخدمين الآخرين.', style: TextStyle(fontSize: 11, color: Colors.grey)),
          ]),
        ))),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(ctx, true); }, child: const Text('حفظ'))],
      ),
    ));

    if (result == true) {
      final now = DateTime.now().toUtc().toIso8601String();
      final entry = <String, dynamic>{
        'id': existing?['id'] ?? DateTime.now().microsecondsSinceEpoch.toString(),
        'kind': kind, 'provider': provider, 'title': title.text.trim(),
        'details': details.text.trim(), 'code': code.text.trim(),
        'price': double.tryParse(price.text.replaceAll(',', '.')),
        'quota': double.tryParse(quota.text.replaceAll(',', '.')),
        'validity': validity.text.trim(), 'source': source.text.trim(),
        'active': active, 'updatedAt': now,
      };
      setState(() {
        final index = _entries.indexWhere((e) => e['id'] == entry['id']);
        if (index < 0) { _entries.add(entry); } else { _entries[index] = entry; }
      });
      await _save();
    }
    for (final c in [title, details, code, price, quota, validity, source]) { c.dispose(); }
  }

  Future<void> _delete(Map<String, dynamic> entry) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('حذف العنصر؟'), content: Text('سيتم حذف «${entry['title']}» من القائمة المحلية.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف'))],
    ));
    if (ok == true) { setState(() => _entries.removeWhere((e) => e['id'] == entry['id'])); await _save(); }
  }

  Future<void> _export() async {
    final data = {'format': 'smc_managed_catalog', 'version': 1, 'exportedAt': DateTime.now().toUtc().toIso8601String(), 'entries': _entries};
    await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(data)));
    if (mounted) _message('تم نسخ بيانات العروض والباقات والأكواد بصيغة JSON.');
  }

  Future<void> _import() async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('استيراد بيانات المركز'),
      content: TextField(controller: controller, minLines: 5, maxLines: 10, decoration: const InputDecoration(hintText: 'الصق ملف JSON هنا', border: OutlineInputBorder())),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استيراد'))],
    ));
    if (ok == true) {
      try {
        final root = jsonDecode(controller.text);
        if (root is! Map || root['format'] != 'smc_managed_catalog' || root['version'] != 1 || root['entries'] is! List) throw const FormatException();
        final imported = (root['entries'] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).where((e) => e['id'] is String && e['title'] is String && _providers.containsKey(e['provider']) && const {'offer','plan','code'}.contains(e['kind'])).toList();
        setState(() => _entries = imported);
        await _save();
        if (mounted) _message('تم استيراد ${imported.length} عنصر.');
      } catch (_) { if (mounted) _message('ملف JSON غير صالح أو لا يخص مركز الإدارة.'); }
    }
    controller.dispose();
  }

  void _message(String value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));

  @override
  Widget build(BuildContext context) {
    final items = _visible;
    final offers = _entries.where((e) => e['kind'] == 'offer').length;
    final plans = _entries.where((e) => e['kind'] == 'plan').length;
    final codes = _entries.where((e) => e['kind'] == 'code').length;
    return Scaffold(
      appBar: AppBar(title: const Text('مركز التحكم'), actions: [IconButton(tooltip: 'تصدير', onPressed: _export, icon: const Icon(Icons.ios_share)), IconButton(tooltip: 'استيراد', onPressed: _import, icon: const Icon(Icons.file_download_outlined))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: _editEntry, icon: const Icon(Icons.add), label: const Text('إضافة')),
      body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), children: [
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF071A46), Color(0xFF24569B)]), borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('إدارة عروضك وباقاتك وأكوادك', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
          const SizedBox(height: 6), const Text('نظّم بيانات الشركات، راجع صلاحية العروض، واحتفظ بكتالوجك في مكان واحد.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 16), Row(children: [_metric('العروض', offers), _metric('الباقات', plans), _metric('الأكواد', codes)]),
        ])),
        const SizedBox(height: 14),
        TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: InputDecoration(hintText: 'ابحث بالاسم أو التفاصيل أو الكود', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.close)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
        const SizedBox(height: 10),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
          _filter('الكل', 'all', _kind, (v) => setState(() => _kind = v)), _filter('العروض', 'offer', _kind, (v) => setState(() => _kind = v)), _filter('الباقات', 'plan', _kind, (v) => setState(() => _kind = v)), _filter('الأكواد', 'code', _kind, (v) => setState(() => _kind = v)),
        ])),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(value: _provider, decoration: const InputDecoration(labelText: 'تصفية حسب الشركة', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'all', child: Text('كل الشركات')), DropdownMenuItem(value: 'vodafone', child: Text('Vodafone')), DropdownMenuItem(value: 'orange', child: Text('Orange')), DropdownMenuItem(value: 'etisalat', child: Text('e&')), DropdownMenuItem(value: 'we', child: Text('WE'))], onChanged: (v) => setState(() => _provider = v ?? 'all')),
        const SizedBox(height: 12),
        if (items.isEmpty) Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [const Icon(Icons.inventory_2_outlined, size: 42), const SizedBox(height: 8), const Text('لا توجد عناصر هنا بعد', style: TextStyle(fontWeight: FontWeight.bold)), const Text('أضف عرضًا أو باقة أو كودًا لتنظيمه داخل المركز.')]))),
        ...items.map(_entryCard),
        const SizedBox(height: 12),
        const Text('مهم: هذا المركز يحفظ بيانات الإدارة محليًا على جهازك. نشر التغييرات داخل نسخة التطبيق لجميع المستخدمين يتطلب ربطه بخادم أو مستودع موثّق وصلاحيات نشر.', style: TextStyle(fontSize: 12, color: Colors.grey)),
      ]),
    );
  }

  Widget _metric(String label, int count) => Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$count', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12))]));

  Widget _filter(String label, String value, String selected, ValueChanged<String> onTap) => Padding(padding: const EdgeInsetsDirectional.only(end: 6), child: ChoiceChip(label: Text(label), selected: selected == value, onSelected: (_) => onTap(value)));

  Widget _entryCard(Map<String, dynamic> e) {
    final kind = switch (e['kind']) { 'offer' => 'عرض', 'plan' => 'باقة', _ => 'كود خدمة' };
    final provider = _providers[e['provider']] ?? 'شركة غير معروفة';
    final code = (e['code'] as String? ?? '').trim();
    final price = e['price'];
    final quota = e['quota'];
    return Card(margin: const EdgeInsets.only(bottom: 9), child: ListTile(
      leading: CircleAvatar(child: Icon(switch (e['kind']) { 'offer' => Icons.local_offer_outlined, 'plan' => Icons.data_usage, _ => Icons.dialpad})),
      title: Text(e['title'] as String? ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('$provider • $kind${e['active'] == true ? '' : ' • متوقف'}'),
        if ((e['details'] as String? ?? '').isNotEmpty) Text(e['details'] as String),
        if (code.isNotEmpty) Text('الكود: $code', style: const TextStyle(fontWeight: FontWeight.bold)),
        if (price != null || quota != null) Text('${price == null ? '' : '$price جنيه'}${price != null && quota != null ? ' • ' : ''}${quota == null ? '' : '$quota GB/وحدة'}'),
        if ((e['validity'] as String? ?? '').isNotEmpty) Text('الصلاحية: ${e['validity']}'),
      ]),
      isThreeLine: true,
      trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') _editEntry(e); if (v == 'delete') _delete(e); if (v == 'copy' && code.isNotEmpty) { Clipboard.setData(ClipboardData(text: code)); _message('تم نسخ الكود.'); } }, itemBuilder: (_) => [if (code.isNotEmpty) const PopupMenuItem(value: 'copy', child: Text('نسخ الكود')), const PopupMenuItem(value: 'edit', child: Text('تعديل')), const PopupMenuItem(value: 'delete', child: Text('حذف'))]),
    ));
  }
}
