import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/empty_state.dart';
import 'control_center_screen.dart';
import 'tools/data_calculator_sheet.dart';
import 'tools/manual_dial_sheet.dart';
import 'tools/number_carrier_sheet.dart';
import 'tools/plan_comparison_sheet.dart';
import 'tools/widget_manager_screen.dart';

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key, required this.onShowCarrier});

  /// Opens the directory filtered to one carrier.
  final void Function(String providerId) onShowCarrier;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    Widget tool(IconData icon, String title, String subtitle, VoidCallback onTap) {
      return ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: TextStyle(color: c.textSecondary)),
        trailing: Icon(Icons.chevron_left_rounded, color: c.textTertiary),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        onTap: onTap,
      );
    }

    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        const ScreenHeader(title: 'الأدوات', subtitle: 'حاجات صغيرة بتساعدك مع باقتك'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Card(
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                tool(Icons.dialpad_rounded, 'اتصال بكود يدوي', 'افتح أي كود في تطبيق الاتصال',
                    () => showManualDial(context)),
                const Divider(),
                tool(Icons.sim_card_outlined, 'اعرف شبكة الرقم', 'من بادئة الرقم: فودافون أو أورنج أو WE أو e&',
                    () => showNumberCarrier(context, onShowCarrier)),
                const Divider(),
                tool(Icons.data_usage_rounded, 'حاسبة استهلاك الإنترنت', 'المتبقي والنسبة والمتاح يوميًا',
                    () => showDataCalculator(context)),
                const Divider(),
                tool(Icons.balance_rounded, 'مقارنة سعر الجيجا', 'قارن باقتين حسب السعر والسعة',
                    () => showPlanComparison(context)),
                const Divider(),
                tool(Icons.widgets_outlined, 'ويدجت الشاشة الرئيسية', 'اعرض كودك المفضل على شاشة الهاتف',
                    () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const WidgetManagerScreen()))),
                const Divider(),
                tool(Icons.tune_rounded, 'مركز التحكم المحلي', 'سجّل عروضك وباقاتك وأكوادك على جهازك',
                    () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const ControlCenterScreen()))),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
