import 'dart:async';

import 'package:flutter/material.dart';

import 'home_shell.dart';

/// Short branded entry: one fade, no looping animation.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key, this.duration = const Duration(milliseconds: 1400)});

  final Duration duration;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _intro = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 450),
  )..forward();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(widget.duration, () {
      if (mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute<void>(builder: (_) => const HomeShell()));
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _intro.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const ink = Color(0xFF0B1F3A);
    const paper = Color(0xFFF4EBD3);
    return Scaffold(
      backgroundColor: ink,
      body: SizedBox.expand(
        child: FadeTransition(
          opacity: CurvedAnimation(parent: _intro, curve: Curves.easeOut),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: Image.asset(
                  'assets/app_logo.png',
                  key: const ValueKey('brand-app-logo'),
                  width: 112,
                  height: 112,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(Icons.dialpad_rounded, color: paper, size: 72),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'كود موبايل',
                style: TextStyle(color: paper, fontSize: 28, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                'دليل أكواد شبكات المحمول في مصر',
                style: TextStyle(color: paper.withValues(alpha: .72), fontSize: 14),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
