import 'package:flutter/material.dart';

class Carrier {
  const Carrier(this.id, this.name, this.color, this.aliases);
  final String id;
  final String name;
  final Color color;

  /// Words people type or say for this carrier (normalized at search time).
  final List<String> aliases;
}

const carriers = <Carrier>[
  Carrier('vodafone', 'Vodafone', Color(0xFFD7262E), ['فودافون', 'vodafone', 'ڤودافون']),
  Carrier('orange', 'Orange', Color(0xFFE8700A), ['اورنج', 'اورانج', 'أورنج', 'orange', 'موبينيل']),
  Carrier('we', 'WE', Color(0xFF6B3FA0), ['وي', 'we', 'المصرية للاتصالات', 'تي اي']),
  Carrier('etisalat', 'e&', Color(0xFF0A8F8F), ['اتصالات', 'etisalat', 'e&', 'اي اند', 'اي آند']),
];

Carrier? carrierById(String id) {
  for (final carrier in carriers) {
    if (carrier.id == id) return carrier;
  }
  return null;
}

const _categoryOrder = <String>[
  'الرصيد', 'الشحن', 'الباقات', 'الإنترنت', 'المكالمات',
  'المحفظة', 'الدعم', 'إدارة الخط', 'خدمات إضافية',
];

/// Known categories first (in a stable, task-oriented order), unknown ones after.
List<String> orderedCategories(Iterable<String> categories) {
  final unique = categories.toSet().toList();
  unique.sort((a, b) {
    final ia = _categoryOrder.indexOf(a);
    final ib = _categoryOrder.indexOf(b);
    if (ia != -1 && ib != -1) return ia.compareTo(ib);
    if (ia != -1) return -1;
    if (ib != -1) return 1;
    return a.compareTo(b);
  });
  return unique;
}
