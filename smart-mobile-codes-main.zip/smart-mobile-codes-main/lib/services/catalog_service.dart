import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../data/seed_codes.dart';
import '../models/mobile_code.dart';

class CatalogResult {
  const CatalogResult({
    required this.codes,
    required this.updatedAt,
    required this.fromNetwork,
    this.message,
  });

  final List<MobileCode> codes;
  final DateTime? updatedAt;
  final bool fromNetwork;
  final String? message;
}

/// Loads a validated public catalog, keeps an offline cache, and falls back
/// to the bundled seed catalog if the network is unavailable.
class CatalogService {
  static const catalogUrl =
      'https://raw.githubusercontent.com/mainosama/smart-mobile-codes/main/codes.json';
  static const _cacheKey = 'catalog_json_v1';
  static const _updatedKey = 'catalog_updated_at_v1';

  Future<CatalogResult> load({bool forceRefresh = false}) async {
    SharedPreferences? prefs;
    try {
      prefs = await SharedPreferences.getInstance();
    } catch (_) {
      // Widget tests or restricted environments may not expose the plugin.
      return const CatalogResult(
        codes: seedCodes,
        updatedAt: null,
        fromNetwork: false,
        message: 'يتم عرض البيانات المضمنة بالتطبيق.',
      );
    }
    final cached = prefs.getString(_cacheKey);
    final cachedAt = DateTime.tryParse(prefs.getString(_updatedKey) ?? '');

    if (!forceRefresh) {
      try {
        final response = await http
            .get(Uri.parse(catalogUrl), headers: {'Accept': 'application/json'})
            .timeout(const Duration(seconds: 12));
        if (response.statusCode == 200) {
          final parsed = _parse(response.body);
          await prefs.setString(_cacheKey, response.body);
          final updatedAt = DateTime.tryParse(
                (jsonDecode(response.body) as Map<String, dynamic>)['updatedAt']
                    as String? ?? '',
              ) ?? DateTime.now().toUtc();
          await prefs.setString(_updatedKey, updatedAt.toIso8601String());
          return CatalogResult(
            codes: parsed,
            updatedAt: updatedAt,
            fromNetwork: true,
          );
        }
        throw Exception('HTTP ${response.statusCode}');
      } catch (_) {
        // Offline fallback is intentional.
      }
    } else {
      try {
        final response = await http
            .get(Uri.parse(catalogUrl), headers: {'Accept': 'application/json'})
            .timeout(const Duration(seconds: 15));
        if (response.statusCode != 200) {
          throw Exception('HTTP ${response.statusCode}');
        }
        final parsed = _parse(response.body);
        await prefs.setString(_cacheKey, response.body);
        final updatedAt = DateTime.tryParse(
              (jsonDecode(response.body) as Map<String, dynamic>)['updatedAt']
                  as String? ?? '',
            ) ?? DateTime.now().toUtc();
        await prefs.setString(_updatedKey, updatedAt.toIso8601String());
        return CatalogResult(codes: parsed, updatedAt: updatedAt, fromNetwork: true);
      } catch (_) {
        // Continue with cached or bundled catalog.
      }
    }

    if (cached != null) {
      try {
        return CatalogResult(
          codes: _parse(cached),
          updatedAt: cachedAt,
          fromNetwork: false,
          message: 'تعذر الاتصال؛ يتم عرض آخر نسخة محفوظة.',
        );
      } catch (_) {
        // Ignore invalid/corrupt cache and use bundled data.
      }
    }
    return CatalogResult(
      codes: seedCodes,
      updatedAt: cachedAt,
      fromNetwork: false,
      message: 'تعذر تحديث الدليل؛ يتم عرض البيانات المضمنة بالتطبيق.',
    );
  }

  List<MobileCode> _parse(String body) {
    if (body.length > 1024 * 1024) throw const FormatException('Catalog too large');
    final root = jsonDecode(body);
    if (root is! Map<String, dynamic> || root['schemaVersion'] != 1) {
      throw const FormatException('Unsupported catalog schema');
    }
    final raw = root['codes'];
    if (raw is! List || raw.isEmpty || raw.length > 1000) {
      throw const FormatException('Invalid catalog entries');
    }
    final codes = raw.map((entry) {
      if (entry is! Map<String, dynamic>) throw const FormatException('Invalid code');
      final code = MobileCode.fromJson(entry);
      if (code.id.trim().isEmpty ||
          code.title.trim().isEmpty ||
          code.providerName.trim().isEmpty ||
          !const {'vodafone', 'orange', 'etisalat', 'we'}.contains(code.providerId) ||
          !RegExp(r'^[0-9*#]+$').hasMatch(code.code) ||
          code.code.length > 40) {
        throw const FormatException('Invalid code fields');
      }
      if (code.verified) {
        final uri = Uri.tryParse(code.sourceUrl);
        if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
          throw const FormatException('Verified code must have HTTPS source');
        }
      }
      return code;
    }).toList(growable: false);
    if (codes.map((e) => e.id).toSet().length != codes.length) {
      throw const FormatException('Duplicate code ids');
    }
    return codes;
  }
}
