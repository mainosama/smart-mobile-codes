import 'package:home_widget/home_widget.dart';

import '../models/mobile_code.dart';

/// Sends the selected code to the native Android home-screen widget.
class WidgetService {
  static const String androidWidgetName = 'MobileCodeWidgetProvider';

  Future<bool> update(MobileCode code) async {
    try {
      await HomeWidget.saveWidgetData<String>('widget_title', code.title);
      await HomeWidget.saveWidgetData<String>('widget_code', code.code);
      await HomeWidget.saveWidgetData<String>('widget_provider', code.providerName);
      await HomeWidget.saveWidgetData<String>('widget_status',
          code.verified ? 'تم التحقق من الكود' : 'كود غير متحقق منه رسمياً');
      await HomeWidget.updateWidget(name: androidWidgetName);
      return true;
    } catch (_) {
      return false;
    }
  }
}
