import 'package:url_launcher/url_launcher.dart';

class DialerService {
  Future<bool> dial(String rawCode) async {
    // Preserve only dialable characters; Uri safely encodes reserved characters.
    final code = rawCode.replaceAll(RegExp(r'[^0-9*#]'), '');
    if (code.isEmpty) return false;
    try {
      final uri = Uri(scheme: 'tel', path: code);
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }
}
