import '../models/mobile_code.dart';

// لا تضع verified=true إلا إذا كان للكود مصدر رسمي مباشر وحديث.
const seedCodes = <MobileCode>[
  MobileCode(
    id: 'vf_balance', providerId: 'vodafone', providerName: 'Vodafone',
    title: 'معرفة الرصيد', code: '868', category: 'الرصيد',
    description: 'رقم خدمة الاستعلام الصوتي عن الرصيد.', verified: true,
    sourceUrl: 'https://web.vodafone.com.eg/ar/short-numbers',
  ),
  MobileCode(
    id: 'vf_customer', providerId: 'vodafone', providerName: 'Vodafone',
    title: 'قائمة خدمات فودافون', code: '*888#', category: 'الدعم',
    description: 'قائمة الخدمات والأرقام المختصرة المنشورة على موقع فودافون.', verified: true,
    sourceUrl: 'https://web.vodafone.com.eg/ar/short-numbers',
  ),
  MobileCode(
    id: 'orange_customer', providerId: 'orange', providerName: 'Orange',
    title: 'خدمة العملاء', code: '110', category: 'الدعم',
    description: 'اتصل من خط أورنج.', verified: true,
    sourceUrl: 'https://www.orange.eg/ar/help/short-numbers',
  ),
  MobileCode(
    id: 'orange_balance', providerId: 'orange', providerName: 'Orange',
    title: 'إدارة الحساب والرصيد', code: '#100#', category: 'الرصيد',
    description: 'معرفة الرصيد والخدمات وإدارة الحساب.', verified: true,
    sourceUrl: 'https://www.orange.eg/ar/help/short-numbers',
  ),
  MobileCode(
    id: 'orange_balance_due', providerId: 'orange', providerName: 'Orange',
    title: 'معرفة الرصيد والمبالغ المستحقة', code: '#16#', category: 'الرصيد',
    description: 'كود منشور في دليل أورنج الرسمي.', verified: true,
    sourceUrl: 'https://www.orange.eg/ar/help/short-numbers',
  ),
  MobileCode(
    id: 'et_customer', providerId: 'etisalat', providerName: 'e&',
    title: 'خدمة العملاء', code: '333', category: 'الدعم',
    description: 'رقم متداول لخدمة العملاء؛ لم أعثر في المراجعة الحالية على صفحة رسمية تؤكده.', verified: false,
  ),
  MobileCode(
    id: 'et_wallet_balance', providerId: 'etisalat', providerName: 'e&',
    title: 'رصيد محفظة e& money', code: '*777*4#', category: 'الرصيد',
    description: 'للاستعلام عن رصيد المحفظة الإلكترونية فقط.', verified: true,
    sourceUrl: 'https://www.etisalat.eg/portal/pages/services/eand_money.html',
  ),
  MobileCode(
    id: 'we_customer', providerId: 'we', providerName: 'WE',
    title: 'خدمة العملاء', code: '111', category: 'الدعم',
    description: 'رقم خدمة عملاء WE؛ قد تُطبق تكلفة المكالمة وفق صفحة الشركة.', verified: true,
    sourceUrl: 'https://te.eg/about-te/faq',
  ),
  MobileCode(
    id: 'we_balance', providerId: 'we', providerName: 'WE',
    title: 'معرفة الرصيد', code: '*550#', category: 'الرصيد',
    description: 'استعلام عن الرصيد.', verified: true,
    sourceUrl: 'https://te.eg/about-te/faq',
  ),
  MobileCode(
    id: 'we_bundle', providerId: 'we', providerName: 'WE',
    title: 'معرفة المتبقي من الباقة', code: '*414#', category: 'الباقات',
    description: 'الاستعلام عن الوحدات المتبقية في الباقة.', verified: true,
    sourceUrl: 'https://te.eg/about-te/faq',
  ),
];

const providers = [
  ('all', 'الكل', 0xFF5B4BDB),
  ('vodafone', 'Vodafone', 0xFFE60000),
  ('orange', 'Orange', 0xFFFF7900),
  ('etisalat', 'e&', 0xFF00A86B),
  ('we', 'WE', 0xFF6C3CCB),
];
