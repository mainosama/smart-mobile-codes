import 'dart:async';
import 'package:flutter/material.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late final AnimationController _intro = AnimationController(vsync: this, duration: const Duration(milliseconds: 1050))..forward();
  late final AnimationController _glow = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))..repeat(reverse: true);
  late final Animation<double> _fade = CurvedAnimation(parent: _intro, curve: Curves.easeOutCubic);
  late final Animation<double> _scale = Tween<double>(begin: .72, end: 1).animate(CurvedAnimation(parent: _intro, curve: Curves.easeOutBack));

  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1900), () {
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    });
  }

  @override
  void dispose() { _intro.dispose(); _glow.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: AnimatedBuilder(animation: _glow, builder: (context, _) => Container(
      width: double.infinity,
      decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [const Color(0xFF061331), Color.lerp(const Color(0xFF123B78), const Color(0xFF1767B7), _glow.value)!, const Color(0xFF071A35)])),
      child: Stack(children: [
        Positioned(top: -100, right: -90, child: _orb(260, const Color(0xFF247CFF).withValues(alpha: .12))),
        Positioned(bottom: -120, left: -90, child: _orb(300, const Color(0xFFFFC857).withValues(alpha: .13))),
        SafeArea(child: Center(child: FadeTransition(opacity: _fade, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          ScaleTransition(scale: _scale, child: Container(width: 164, height: 164, padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .09), borderRadius: BorderRadius.circular(42), border: Border.all(color: Colors.white.withValues(alpha: .24)), boxShadow: [BoxShadow(color: const Color(0xFF35B8FF).withValues(alpha: .18 + .12 * _glow.value), blurRadius: 36, spreadRadius: 5)]), child: ClipRRect(borderRadius: BorderRadius.circular(34), child: Image.asset('assets/app_logo.png', fit: BoxFit.cover)))),
          const SizedBox(height: 30),
          const Text('Smart Mobile Codes', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: .2)),
          const SizedBox(height: 9),
          Text('دليلك الذكي لأكواد وخدمات شبكات المحمول', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withValues(alpha: .78), fontSize: 13)),
          const SizedBox(height: 34),
          SizedBox(width: 138, child: ClipRRect(borderRadius: BorderRadius.circular(10), child: const LinearProgressIndicator(minHeight: 4, backgroundColor: Colors.white24, color: Color(0xFFFFC857)))),
          const SizedBox(height: 14),
          Text('كل شبكاتك.. في مكان واحد', style: TextStyle(color: Colors.white.withValues(alpha: .7), fontSize: 11, letterSpacing: .5)),
        ])))),
        Positioned(bottom: 22, left: 0, right: 0, child: Text('VODAFONE  •  ORANGE  •  WE  •  e&', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withValues(alpha: .45), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.2))),
      ]),
    )),
  );

  Widget _orb(double size, Color color) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}
