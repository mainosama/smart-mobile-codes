import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../main.dart';

import '../data/seed_codes.dart';
import '../models/mobile_code.dart';
import '../services/catalog_service.dart';
import '../services/dialer_service.dart';
import '../services/favorites_service.dart';
import '../services/widget_service.dart';
import '../services/recent_codes_service.dart';
import '../widgets/code_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();
  final _favorites = FavoritesService();
  final _catalog = CatalogService();
  List<MobileCode> _codes = seedCodes;
  DateTime? _catalogUpdatedAt;
  bool _catalogBusy = false;
  String? _catalogMessage;
  final _dialer = DialerService();
  final _widgetService = WidgetService();
  final _recentService = RecentCodesService();
  List<String> _recentIds = [];
  bool _verifiedOnly = false;
  String _sort = 'default';
  Set<String> _favoriteIds = {};
  String _provider = 'all';
  String _category = 'الكل';
  int _tab = 0;
  String? _widgetCodeId;
  bool _widgetBusy = false;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _loadRecent();
    _widgetCodeId = seedCodes.isEmpty ? null : seedCodes.first.id;
    _loadCatalog();
  }

  Future<void> _loadCatalog({bool forceRefresh = false}) async {
    if (_catalogBusy) return;
    if (mounted) setState(() => _catalogBusy = true);
    final result = await _catalog.load(forceRefresh: forceRefresh);
    if (!mounted) return;
    setState(() {
      _codes = result.codes;
      _catalogUpdatedAt = result.updatedAt;
      _catalogMessage = result.message;
      _catalogBusy = false;
      if (_widgetCodeId == null || !_codes.any((e) => e.id == _widgetCodeId)) {
        _widgetCodeId = _codes.isEmpty ? null : _codes.first.id;
      }
    });
    if (forceRefresh) _showMessage(result.fromNetwork ? 'تم تحديث دليل الأكواد.' : (result.message ?? 'تعذر تحديث الدليل.'));
  }

  Future<void> _loadRecent() async {
    try {
      final values = await _recentService.load();
      if (mounted) setState(() => _recentIds = values);
    } catch (_) {
      if (mounted) _showMessage('تعذر تحميل سجل الاستخدام.');
    }
  }

  Future<void> _loadFavorites() async {
    try {
      final values = await _favorites.load();
      if (mounted) setState(() => _favoriteIds = values);
    } catch (_) {
      if (mounted) _showMessage('تعذر تحميل المفضلة. حاول مرة أخرى.');
    }
  }

  List<MobileCode> get _visibleCodes {
    Iterable<MobileCode> items = _codes;
    if (_provider != 'all') {
      items = items.where((e) => e.providerId == _provider);
    }
    if (_category != 'الكل') {
      items = items.where((e) => e.category == _category);
    }
    if (_tab == 1) {
      items = items.where((e) => _favoriteIds.contains(e.id));
    } else if (_tab == 2) {
      final byId = {for (final code in _codes) code.id: code};
      items = _recentIds.map((id) => byId[id]).whereType<MobileCode>();
    }
    if (_verifiedOnly) items = items.where((e) => e.verified);
    final query = _search.text.trim().toLowerCase();
    if (query.isNotEmpty) {
      items = items.where((e) =>
          '${e.title} ${e.code} ${e.category} ${e.providerName} ${e.description}'
              .toLowerCase()
              .contains(query));
    }
    final result = items.toList();
    if (_sort == 'title') {
      result.sort((a, b) => a.title.compareTo(b.title));
    } else if (_sort == 'provider') {
      result.sort((a, b) => a.providerName.compareTo(b.providerName));
    }
    return result;
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _toggleFavorite(MobileCode item) async {
    try {
      await _favorites.toggle(item.id, _favoriteIds);
      await _loadFavorites();
    } catch (_) {
      _showMessage('تعذر تحديث المفضلة.');
    }
  }

  Future<void> _dial(MobileCode item) async {
    // The current seed catalog is explicitly unverified. Never silently dial it.
    final proceed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تنبيه قبل الاتصال'),
        content: Text('${item.verified ? 'سيتم فتح تطبيق الاتصال للكود ${item.code}.' : 'هذا الكود لم يتم التحقق منه من مصدر الشركة الرسمي. قد لا يعمل أو قد تترتب عليه رسوم.'}\n\nإذا كان هاتفك يحتوي على شريحتين، اختر الشريحة من تطبيق الاتصال إذا عرض الهاتف هذا الاختيار. التطبيق لا يفرض اختيار SIM بعينها.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('متابعة'),
          ),
        ],
      ),
    );
    if (proceed != true || !mounted) return;
    final ok = await _dialer.dial(item.code);
    if (ok) {
      try {
        await _recentService.record(item.id);
        await _loadRecent();
      } catch (_) { /* History is optional; dialing must remain available. */ }
    }
    if (!ok) _showMessage('تعذر فتح تطبيق الاتصال على هذا الجهاز.');
  }

  Future<void> _copyCode(MobileCode item) async {
    await Clipboard.setData(ClipboardData(text: item.code));
    _showMessage('تم نسخ الكود');
  }

  Future<void> _updateWidget() async {
    if (_widgetBusy || _codes.isEmpty) return;
    final selected = _codes.firstWhere(
      (code) => code.id == _widgetCodeId,
      orElse: () => _codes.first,
    );
    setState(() => _widgetBusy = true);
    final success = await _widgetService.update(selected);
    if (mounted) setState(() => _widgetBusy = false);
    if (!mounted) return;
    _showMessage(success
        ? 'تم تحديث بيانات الويدجت. أضف ويدجت «كود موبايل» من شاشة هاتفك الرئيسية.'
        : 'تعذر تحديث الويدجت. تأكد من تثبيت التطبيق بصورة صحيحة.');
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('كود موبايل', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            tooltip: 'تحديث دليل الأكواد',
            onPressed: _catalogBusy ? null : () => _loadCatalog(forceRefresh: true),
            icon: _catalogBusy ? const Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))) : const Icon(Icons.sync),
          ),
          IconButton(
            tooltip: 'حول التطبيق',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'كود موبايل',
              applicationVersion: '1.4.0',
              children: const [Text('دليل أكواد وخدمات شركات المحمول في مصر.')],
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: _tab == 3 ? _buildWidgetPage(context) : (_tab == 4 ? _buildSettingsPage(context) : _buildCodesPage(context)),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.history), selectedIcon: Icon(Icons.history_rounded), label: 'الأخيرة'),
          NavigationDestination(icon: Icon(Icons.widgets_outlined), selectedIcon: Icon(Icons.widgets), label: 'الويدجت'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }

  Widget _buildCodesPage(BuildContext context) {
    final codes = _visibleCodes;
    return Column(
      children: [
        if (_catalogMessage != null || _catalogUpdatedAt != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Row(children: [
              Expanded(child: Text(_catalogMessage ?? 'آخر تحديث: ${_catalogUpdatedAt!.toLocal()}', style: Theme.of(context).textTheme.bodySmall)),
              TextButton.icon(onPressed: _catalogBusy ? null : () => _loadCatalog(forceRefresh: true), icon: const Icon(Icons.refresh, size: 16), label: const Text('تحديث')),
            ]),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF5143C7), Color(0xFF8879F2)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('كل خدمات خطك في مكان واحد', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 5),
                Text('ابحث عن الخدمة وافتح كود الاتصال بضغطة', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
              Icon(Icons.sim_card_rounded, color: Colors.white, size: 44),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SearchBar(
            controller: _search,
            onChanged: (_) => setState(() {}),
            hintText: 'ابحث عن خدمة أو كود...',
            leading: const Icon(Icons.search),
            trailing: [
              if (_search.text.isNotEmpty)
                IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.close)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: providers.map((provider) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: ChoiceChip(
                label: Text(provider.$2),
                selected: _provider == provider.$1,
                onSelected: (_) => setState(() => _provider = provider.$1),
              ),
            )).toList(),
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(child: Text(_tab == 1 ? 'الأكواد المفضلة' : (_tab == 2 ? 'آخر الأكواد المستخدمة' : 'الأكواد والخدمات'), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
            if (_tab == 2 && _recentIds.isNotEmpty) TextButton(onPressed: () async { await _recentService.clear(); await _loadRecent(); }, child: const Text('مسح السجل')),
            PopupMenuButton<String>(
              tooltip: 'خيارات العرض',
              onSelected: (value) {
                setState(() {
                  if (value.startsWith('category:')) { _category = value.substring(9); }
                  if (value.startsWith('sort:')) { _sort = value.substring(5); }
                  if (value == 'verified') { _verifiedOnly = !_verifiedOnly; }
                });
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'category:الكل', child: Text('كل التصنيفات')),
                ...(_codes.map((e) => e.category).toSet().toList()..sort()).map((value) => PopupMenuItem(value: 'category:$value', child: Text(value))),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'sort:default', child: Text('الترتيب الافتراضي')),
                const PopupMenuItem(value: 'sort:title', child: Text('الترتيب بالاسم')),
                const PopupMenuItem(value: 'sort:provider', child: Text('الترتيب بالشركة')),
                PopupMenuItem(value: 'verified', child: Text(_verifiedOnly ? 'عرض كل الأكواد' : 'الموثقة فقط')),
              ],
              child: Chip(avatar: const Icon(Icons.tune, size: 17), label: Text(_verifiedOnly ? 'موثقة' : _category)),
            ),
          ]),
        ),
        Expanded(
          child: codes.isEmpty
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.search_off, size: 44), const SizedBox(height: 12), const Text('مفيش نتائج مطابقة حالياً'), const SizedBox(height: 8), OutlinedButton.icon(onPressed: () => setState(() { _search.clear(); _provider = 'all'; _category = 'الكل'; _verifiedOnly = false; _sort = 'default'; }), icon: const Icon(Icons.filter_alt_off), label: const Text('مسح البحث والفلاتر'))])))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  itemCount: codes.length,
                  itemBuilder: (context, index) {
                    final item = codes[index];
                    return CodeCard(
                      item: item,
                      favorite: _favoriteIds.contains(item.id),
                      onFavorite: () => _toggleFavorite(item),
                      onDial: () => _dial(item),
                      onCopy: () => _copyCode(item),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Future<void> _exportBackup() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final backup = {
        'format': 'smart_mobile_codes_backup',
        'version': 1,
        'createdAt': DateTime.now().toUtc().toIso8601String(),
        'favorites': prefs.getStringList('favorite_code_ids') ?? <String>[],
        'recent': prefs.getStringList('recent_code_ids_v1') ?? <String>[],
      };
      await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(backup)));
      _showMessage('تم نسخ النسخة الاحتياطية. احتفظ بها في مكان آمن.');
    } catch (_) {
      _showMessage('تعذر إنشاء النسخة الاحتياطية.');
    }
  }

  Future<void> _importBackup() async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('استعادة نسخة احتياطية'),
        content: TextField(
          controller: controller,
          minLines: 5,
          maxLines: 9,
          decoration: const InputDecoration(
            hintText: 'الصق محتوى النسخة الاحتياطية هنا',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة')),
        ],
      ),
    );
    if (confirmed != true) { controller.dispose(); return; }
    try {
      final data = jsonDecode(controller.text);
      if (data is! Map || data['format'] != 'smart_mobile_codes_backup' || data['version'] != 1 || data['favorites'] is! List || data['recent'] is! List) {
        throw const FormatException('Invalid backup');
      }
      final favorites = (data['favorites'] as List).whereType<String>().toSet().toList();
      final recent = (data['recent'] as List).whereType<String>().toSet().toList();
      final validIds = _codes.map((e) => e.id).toSet();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('favorite_code_ids', favorites.where(validIds.contains).toList());
      await prefs.setStringList('recent_code_ids_v1', recent.where(validIds.contains).take(30).toList());
      await _loadFavorites();
      await _loadRecent();
      _showMessage('تمت استعادة المفضلة والسجل.');
    } catch (_) {
      _showMessage('النسخة غير صالحة أو لا تتوافق مع هذا التطبيق.');
    } finally {
      controller.dispose();
    }
  }

  Future<void> _setTheme(String value) async {
    appThemeMode.value = switch (value) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_theme_mode_v1', value);
  }

  Future<void> _sendFeedback() async {
    final uri = Uri.parse('https://github.com/mainosama/smart-mobile-codes/issues/new');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      _showMessage('تعذر فتح صفحة إرسال الملاحظات.');
    }
  }

  Widget _buildSettingsPage(BuildContext context) {
    final current = switch (appThemeMode.value) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      _ => 'system',
    };
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('الإعدادات', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('المظهر', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'system', label: Text('النظام'), icon: Icon(Icons.phone_android)),
              ButtonSegment(value: 'light', label: Text('فاتح'), icon: Icon(Icons.light_mode)),
              ButtonSegment(value: 'dark', label: Text('داكن'), icon: Icon(Icons.dark_mode)),
            ],
            selected: {current},
            onSelectionChanged: (values) => _setTheme(values.first),
          ),
        ]))),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.backup_outlined), title: const Text('نسخ احتياطي للمفضلة والسجل'), subtitle: const Text('ينسخ ملف JSON إلى الحافظة'), onTap: _exportBackup),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.restore), title: const Text('استعادة نسخة احتياطية'), subtitle: const Text('الصق ملف النسخة الاحتياطية لاستعادته'), onTap: _importBackup),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.delete_sweep_outlined), title: const Text('مسح سجل الاستخدام'), onTap: () async { await _recentService.clear(); await _loadRecent(); _showMessage('تم مسح السجل.'); }),
        ])),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.sync), title: const Text('تحديث دليل الأكواد'), subtitle: const Text('تحميل أحدث نسخة متاحة من الدليل'), onTap: _catalogBusy ? null : () => _loadCatalog(forceRefresh: true)),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.feedback_outlined), title: const Text('إرسال ملاحظات'), subtitle: const Text('يفتح تطبيق البريد الإلكتروني'), onTap: _sendFeedback),
          const Divider(height: 1),
          const ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('الخصوصية'), subtitle: Text('المفضلة وسجل الاستخدام محفوظان محلياً. لا يقرأ التطبيق سجل مكالماتك أو أرقام جهات اتصالك.')),
        ])),
        const Padding(padding: EdgeInsets.all(12), child: Text('كود موبايل • الإصدار 1.4.0\nتحقق من مصدر الشركة قبل استخدام أي كود قد يترتب عليه رسوم.', textAlign: TextAlign.center)),
      ],
    );
  }

  Widget _buildWidgetPage(BuildContext context) {
    if (_codes.isEmpty) {
      return const Center(child: Text('لا توجد أكواد متاحة للويدجت حاليًا. حدّث الدليل وحاول مرة أخرى.'));
    }
    final selected = _codes.firstWhere(
      (code) => code.id == _widgetCodeId,
      orElse: () => _codes.first,
    );
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Icon(Icons.widgets_rounded, size: 64),
        const SizedBox(height: 12),
        Text('ويدجت الشاشة الرئيسية', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('اختر كوداً ليظهر على شاشة هاتفك الرئيسية، ثم اضغط تحديث. بعد ذلك أضف ويدجت «كود موبايل» من قائمة الويدجت في الهاتف.', textAlign: TextAlign.center),
        const SizedBox(height: 24),
        DropdownButtonFormField<String>(
          initialValue: _widgetCodeId,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'الكود المعروض', border: OutlineInputBorder()),
          items: _codes.map((code) => DropdownMenuItem(value: code.id, child: Text('${code.providerName} — ${code.title}', overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (value) => setState(() => _widgetCodeId = value),
        ),
        const SizedBox(height: 16),
        Card(child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              Text(selected.title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(selected.code, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
              Text(selected.providerName),
              if (!selected.verified) const Text('غير متحقق منه رسمياً', style: TextStyle(color: Colors.deepOrange)),
            ]),
          )),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _widgetBusy ? null : _updateWidget,
          icon: _widgetBusy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh),
          label: const Text('تحديث الويدجت'),
        ),
        const SizedBox(height: 12),
        const Text('ملاحظة: الويدجت يعرض بيانات الكود فقط. فتح الاتصال يتم من داخل التطبيق، ولا يتم إجراء أي اتصال تلقائياً.', style: TextStyle(fontSize: 12)),
      ],
    );
  }
}
