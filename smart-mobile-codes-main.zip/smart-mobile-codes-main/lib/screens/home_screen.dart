import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../main.dart';

import '../data/seed_codes.dart';
import '../models/mobile_code.dart';
import '../services/catalog_service.dart';
import '../services/dialer_service.dart';
import '../services/favorites_service.dart';
import '../services/widget_service.dart';
import '../services/recent_codes_service.dart';
import '../widgets/code_card.dart';
import '../utils/search_normalizer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();
  final _favorites = FavoritesService();
  final _catalog = CatalogService();
  List<MobileCode> _codes = seedCodes;
  DateTime? _catalogUpdatedAt;
  bool _catalogBusy = false;
  String? _catalogMessage;
  final _dialer = DialerService();
  final _widgetService = WidgetService();
  final _recentService = RecentCodesService();
  List<String> _recentIds = [];
  String _verificationFilter = 'all';
  String _sort = 'default';
  Set<String> _favoriteIds = {};
  String _provider = 'all';
  String _category = 'الكل';
  int _tab = 0;
  String? _widgetCodeId;
  bool _widgetBusy = false;
  bool _confirmBeforeDial = true;
  bool _hapticsEnabled = true;
  bool _compactCards = false;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _loadRecent();
    _loadUiPreferences();
    _widgetCodeId = seedCodes.isEmpty ? null : seedCodes.first.id;
    _loadCatalog();
  }

  Future<void> _loadUiPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _confirmBeforeDial = prefs.getBool('confirm_before_dial_v1') ?? true;
        _hapticsEnabled = prefs.getBool('haptics_enabled_v1') ?? true;
        _compactCards = prefs.getBool('compact_cards_v1') ?? false;
      });
    } catch (_) { /* Defaults remain available if storage is unavailable. */ }
  }

  Future<void> _saveUiPreference(String key, bool value) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(key, value);
    } catch (_) {
      _showMessage('تعذر حفظ الإعداد على الجهاز.');
    }
  }

  Future<void> _setBooleanPreference(String key, bool value) async {
    setState(() {
      if (key == 'confirm') _confirmBeforeDial = value;
      if (key == 'haptics') _hapticsEnabled = value;
      if (key == 'compact') _compactCards = value;
    });
    final prefKey = switch (key) {
      'confirm' => 'confirm_before_dial_v1',
      'haptics' => 'haptics_enabled_v1',
      _ => 'compact_cards_v1',
    };
    await _saveUiPreference(prefKey, value);
  }

  Future<void> _smartAssistant() async {
    final controller = TextEditingController();
    final query = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('مساعد الخدمات الذكي'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(
            hintText: 'مثال: عايز أعرف رصيدي أو أحول رصيد',
            prefixIcon: Icon(Icons.auto_awesome),
            border: OutlineInputBorder(),
          ),
          onSubmitted: (_) => Navigator.pop(ctx, controller.text),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('ابحث')),
        ],
      ),
    );
    if (query == null) { controller.dispose(); return; }
    final normalized = normalizeSearchText(query);
    final aliases = <String, String>{
      'رصيد': 'رصيد', 'فلوس': 'رصيد', 'balance': 'رصيد',
      'انترنت': 'انترنت', 'نت': 'انترنت', 'ميجابايت': 'انترنت', 'جيجا': 'انترنت',
      'تحويل': 'تحويل', 'حول': 'تحويل', 'اشحن': 'شحن', 'شحن': 'شحن',
      'محفظه': 'محفظة', 'كاش': 'محفظة', 'خدمه العملاء': 'خدمة العملاء',
      'عملاء': 'خدمة العملاء', 'باقة': 'باقة', 'باقه': 'باقة',
    };
    var resolved = query;
    for (final entry in aliases.entries) {
      if (normalized.contains(normalizeSearchText(entry.key))) { resolved = entry.value; break; }
    }
    if (!mounted) return;
    setState(() { _search.text = resolved; _provider = 'all'; _category = 'الكل'; _tab = 0; });
    controller.dispose();
    _showMessage('عرضت أقرب الخدمات المطابقة لعبارتك. راجع وصف الكود ومصدره قبل الاستخدام.');
  }

  Future<void> _showDataCalculator() async {
    final total = TextEditingController();
    final used = TextEditingController();
    String result = 'أدخل سعة الباقة والاستهلاك الحالي.';
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, refresh) => AlertDialog(
        title: const Text('حاسبة استهلاك الإنترنت'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: total, keyboardType: TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'سعة الباقة (GB)', suffixText: 'GB')),
          const SizedBox(height: 10),
          TextField(controller: used, keyboardType: TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المستهلك حتى الآن (GB)', suffixText: 'GB')),
          const SizedBox(height: 14),
          FilledButton(onPressed: () {
            final t = double.tryParse(total.text.replaceAll(',', '.'));
            final u = double.tryParse(used.text.replaceAll(',', '.'));
            refresh(() {
              result = (t == null || u == null || t <= 0 || u < 0 || u > t)
                ? 'راجع الأرقام: الاستهلاك يجب أن يكون بين صفر وسعة الباقة.'
                : 'المتبقي ${(t-u).toStringAsFixed(2)} GB • استهلكت ${(u/t*100).toStringAsFixed(1)}%';
            });
          }, child: const Text('احسب')),
          const SizedBox(height: 10),
          Text(result, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق'))],
      )),
    );
    total.dispose(); used.dispose();
  }

  Future<void> _showPlanComparator() async {
    final aName = TextEditingController(text: 'الباقة الأولى');
    final aPrice = TextEditingController();
    final aData = TextEditingController();
    final bName = TextEditingController(text: 'الباقة الثانية');
    final bPrice = TextEditingController();
    final bData = TextEditingController();
    String result = 'أدخل بيانات الباقتين للمقارنة.';
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, refresh) => AlertDialog(
      title: const Text('مقارنة الباقات'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('أدخل الأسعار والسعات كما تظهر في عرض الشركة؛ لا توجد أسعار افتراضية غير موثقة.'),
        const SizedBox(height: 12),
        _planFields('الباقة الأولى', aName, aPrice, aData),
        const Divider(height: 24),
        _planFields('الباقة الثانية', bName, bPrice, bData),
        const SizedBox(height: 12),
        FilledButton(onPressed: () {
          final ap = double.tryParse(aPrice.text.replaceAll(',', '.'));
          final ad = double.tryParse(aData.text.replaceAll(',', '.'));
          final bp = double.tryParse(bPrice.text.replaceAll(',', '.'));
          final bd = double.tryParse(bData.text.replaceAll(',', '.'));
          refresh(() {
            if (ap == null || ad == null || bp == null || bd == null || ap <= 0 || bp <= 0 || ad <= 0 || bd <= 0) {
              result = 'أدخل أسعارًا وسعات صحيحة أكبر من صفر.';
            } else {
              final av = ap/ad, bv = bp/bd;
              result = '${aName.text}: ${av.toStringAsFixed(2)} جنيه لكل GB\n${bName.text}: ${bv.toStringAsFixed(2)} جنيه لكل GB\n${av < bv ? 'الأولى أوفر لكل GB حسابيًا.' : bv < av ? 'الثانية أوفر لكل GB حسابيًا.' : 'التكلفة لكل GB متساوية.'}';
            }
          });
        }, child: const Text('قارن')),
        const SizedBox(height: 10), Text(result, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق'))],
    )));
    for (final c in [aName,aPrice,aData,bName,bPrice,bData]) { c.dispose(); }
  }

  Widget _planFields(String label, TextEditingController name, TextEditingController price, TextEditingController data) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
    TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الباقة')),
    Row(children: [Expanded(child: TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر بالجنيه'))), const SizedBox(width: 8), Expanded(child: TextField(controller: data, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعة GB')))]),
  ]);

  Future<void> _loadCatalog({bool forceRefresh = false}) async {
    if (_catalogBusy) return;
    if (mounted) setState(() => _catalogBusy = true);
    CatalogResult result;
    try {
      result = await _catalog.load(forceRefresh: forceRefresh);
    } catch (_) {
      if (mounted) {
        setState(() => _catalogBusy = false);
        if (forceRefresh) _showMessage('تعذر تحديث الدليل. تحقق من اتصال الإنترنت وحاول مجددًا.');
      }
      return;
    }
    if (!mounted) return;
    setState(() {
      _codes = result.codes;
      _catalogUpdatedAt = result.updatedAt;
      _catalogMessage = result.message;
      _catalogBusy = false;
      if (_widgetCodeId == null || !_codes.any((e) => e.id == _widgetCodeId)) {
        _widgetCodeId = _codes.isEmpty ? null : _codes.first.id;
      }
    });
    if (forceRefresh) _showMessage(result.fromNetwork ? 'تم تحديث دليل الأكواد.' : (result.message ?? 'تعذر تحديث الدليل.'));
  }

  Future<void> _loadRecent() async {
    try {
      final values = await _recentService.load();
      if (mounted) setState(() => _recentIds = values);
    } catch (_) {
      if (mounted) _showMessage('تعذر تحميل سجل الاستخدام.');
    }
  }

  Future<void> _loadFavorites() async {
    try {
      final values = await _favorites.load();
      if (mounted) setState(() => _favoriteIds = values);
    } catch (_) {
      if (mounted) _showMessage('تعذر تحميل المفضلة. حاول مرة أخرى.');
    }
  }

  List<MobileCode> get _visibleCodes {
    Iterable<MobileCode> items = _codes;
    if (_provider != 'all') {
      items = items.where((e) => e.providerId == _provider);
    }
    if (_category != 'الكل') {
      items = items.where((e) => e.category == _category);
    }
    if (_tab == 1) {
      items = items.where((e) => _favoriteIds.contains(e.id));
    } else if (_tab == 2) {
      final byId = {for (final code in _codes) code.id: code};
      items = _recentIds.map((id) => byId[id]).whereType<MobileCode>();
    }
    if (_verificationFilter == 'verified') {
      items = items.where((e) => e.verified);
    } else if (_verificationFilter == 'unverified') {
      items = items.where((e) => !e.verified);
    }
    final query = normalizeSearchText(_search.text);
    if (query.isNotEmpty) {
      items = items.where((e) =>
          normalizeSearchText('${e.title} ${e.code} ${e.category} ${e.providerName} ${e.description}')
              .contains(query));
    }
    final result = items.toList();
    if (_sort == 'title') {
      result.sort((a, b) => a.title.compareTo(b.title));
    } else if (_sort == 'provider') {
      result.sort((a, b) => a.providerName.compareTo(b.providerName));
    }
    return result;
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _toggleFavorite(MobileCode item) async {
    try {
      await _favorites.toggle(item.id, _favoriteIds);
      await _loadFavorites();
    } catch (_) {
      _showMessage('تعذر تحديث المفضلة.');
    }
  }

  Future<void> _dial(MobileCode item) async {
    if (_hapticsEnabled) HapticFeedback.selectionClick();
    // Confirmations are enabled by default; the user can explicitly disable them in settings.
    final proceed = _confirmBeforeDial ? await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تنبيه قبل الاتصال'),
        content: Text('${item.verified ? 'سيتم فتح تطبيق الاتصال للكود ${item.code}.' : 'هذا الكود لم يتم التحقق منه من مصدر الشركة الرسمي. قد لا يعمل أو قد تترتب عليه رسوم.'}\n\nإذا كان هاتفك يحتوي على شريحتين، اختر الشريحة من تطبيق الاتصال إذا عرض الهاتف هذا الاختيار. التطبيق لا يفرض اختيار SIM بعينها.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('متابعة'),
          ),
        ],
      ),
    ) : true;
    if (proceed != true || !mounted) return;
    final ok = await _dialer.dial(item.code);
    if (ok) {
      try {
        await _recentService.record(item.id);
        await _loadRecent();
      } catch (_) { /* History is optional; dialing must remain available. */ }
    }
    if (!ok) _showMessage('تعذر فتح تطبيق الاتصال على هذا الجهاز.');
  }

  Future<void> _copyCode(MobileCode item) async {
    await Clipboard.setData(ClipboardData(text: item.code));
    _showMessage('تم نسخ الكود');
  }

  Future<void> _shareCode(MobileCode item) async {
    final text = '${item.title}\\nالشركة: ${item.providerName}\\nالكود: ${item.code}\\n'
        '${item.description}\\n'
        '${item.verified ? 'مصدر المراجعة: ${item.sourceUrl}' : 'تنبيه: الكود غير متحقق منه رسمياً.'}';
    await Clipboard.setData(ClipboardData(text: text));
    _showMessage('تم تجهيز تفاصيل الكود ونسخها؛ يمكنك لصقها في أي تطبيق ومشاركتها.');
  }

  Future<void> _updateWidget() async {
    if (_widgetBusy || _codes.isEmpty) return;
    final selected = _codes.firstWhere(
      (code) => code.id == _widgetCodeId,
      orElse: () => _codes.first,
    );
    setState(() => _widgetBusy = true);
    final success = await _widgetService.update(selected);
    if (mounted) setState(() => _widgetBusy = false);
    if (!mounted) return;
    _showMessage(success
        ? 'تم تحديث بيانات الويدجت. أضف ويدجت «كود موبايل» من شاشة هاتفك الرئيسية.'
        : 'تعذر تحديث الويدجت. تأكد من تثبيت التطبيق بصورة صحيحة.');
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.asset('assets/app_logo.png', width: 36, height: 36, fit: BoxFit.cover)), const SizedBox(width: 9), const Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [Text('Smart Mobile Codes', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)), Text('دليل خدمات شبكات المحمول', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w500))])]),
        actions: [
          IconButton(
            tooltip: 'تحديث دليل الأكواد',
            onPressed: _catalogBusy ? null : () => _loadCatalog(forceRefresh: true),
            icon: _catalogBusy ? const Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))) : const Icon(Icons.sync),
          ),
          IconButton(
            tooltip: 'حول التطبيق',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'كود موبايل',
              applicationVersion: '2.2.0',
              children: const [Text('دليل أكواد وخدمات شركات المحمول في مصر.')],
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: _tab == 3 ? _buildWidgetPage(context) : (_tab == 4 ? _buildSettingsPage(context) : _buildCodesPage(context)),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.history), selectedIcon: Icon(Icons.history_rounded), label: 'الأخيرة'),
          NavigationDestination(icon: Icon(Icons.widgets_outlined), selectedIcon: Icon(Icons.widgets), label: 'الويدجت'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }

  Widget _buildCodesPage(BuildContext context) {
    final codes = _visibleCodes;
    return Column(
      children: [
        if (_catalogMessage != null || _catalogUpdatedAt != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Row(children: [
              Expanded(child: Text(_catalogMessage ?? 'آخر تحديث: ${_catalogUpdatedAt!.toLocal()}', style: Theme.of(context).textTheme.bodySmall)),
              TextButton.icon(onPressed: _catalogBusy ? null : () => _loadCatalog(forceRefresh: true), icon: const Icon(Icons.refresh, size: 16), label: const Text('تحديث')),
            ]),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF071A46), Color(0xFF123D83), Color(0xFF392B83)]),
              borderRadius: BorderRadius.circular(26),
              boxShadow: const [BoxShadow(color: Color(0x33213B83), blurRadius: 18, offset: Offset(0, 8))],
            ),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('كل شبكاتك.. في تطبيق واحد', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                const SizedBox(height: 7),
                Text('أكواد وخدمات ورصيد وباقات — وصول أسرع وأسهل', style: TextStyle(color: Colors.white.withValues(alpha: .82), fontSize: 12)),
                const SizedBox(height: 13),
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: const Color(0xFFFFC857), borderRadius: BorderRadius.circular(20)), child: const Text('اكتشف خدمات شبكتك  ←', style: TextStyle(color: Color(0xFF10244F), fontSize: 11, fontWeight: FontWeight.w900))),
              ])),
              const SizedBox(width: 12),
              Container(width: 74, height: 74, padding: const EdgeInsets.all(5), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .12), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white24)), child: ClipRRect(borderRadius: BorderRadius.circular(17), child: Image.asset('assets/app_logo.png', fit: BoxFit.cover))),
            ]),
          ),
        ),
        Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: Row(children: [Expanded(child: Text('اختر شركتك', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900))), Text('${_codes.length} خدمة متاحة', style: Theme.of(context).textTheme.bodySmall)])),
        SizedBox(
          height: 100,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: providers.map((provider) {
              final selected = _provider == provider.$1;
              final color = Color(provider.$3);
              final count = provider.$1 == 'all' ? _codes.length : _codes.where((e) => e.providerId == provider.$1).length;
              final icon = switch (provider.$1) { 'vodafone' => Icons.circle, 'orange' => Icons.brightness_1, 'etisalat' => Icons.all_inclusive, 'we' => Icons.wifi_tethering, _ => Icons.apps_rounded };
              return Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => setState(() { _provider = provider.$1; _category = 'الكل'; _tab = 0; }),
                child: AnimatedContainer(duration: const Duration(milliseconds: 180), width: 104, padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: selected ? color : Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: selected ? color : Theme.of(context).colorScheme.outlineVariant), boxShadow: selected ? [BoxShadow(color: color.withValues(alpha: .22), blurRadius: 12, offset: const Offset(0, 4))] : null), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(icon, color: selected ? Colors.white : color, size: 25), const SizedBox(height: 5), Text(provider.$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: selected ? Colors.white : Theme.of(context).colorScheme.onSurface, fontSize: 12, fontWeight: FontWeight.w900)), Text('$count خدمة', style: TextStyle(color: selected ? Colors.white70 : Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 10)),
                ])),
              ));
            }).toList(),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 5, 16, 0),
          child: SearchBar(
            controller: _search,
            onChanged: (_) => setState(() {}),
            hintText: 'ابحث باسم الخدمة أو كود الاتصال...',
            leading: const Icon(Icons.search_rounded),
            trailing: [IconButton(tooltip: 'المساعد الذكي', onPressed: _smartAssistant, icon: const Icon(Icons.auto_awesome)), if (_search.text.isNotEmpty) IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.close))],
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 42,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: const Text('كل التصنيفات'),
                  selected: _category == 'الكل',
                  onSelected: (_) => setState(() => _category = 'الكل'),
                ),
              ),
              ...(_codes.map((e) => e.category).toSet().toList()..sort()).map((category) =>
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(category),
                    selected: _category == category,
                    onSelected: (_) => setState(() => _category = category),
                  ),
                )),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(child: Text(_tab == 1 ? 'الأكواد المفضلة' : (_tab == 2 ? 'آخر الأكواد المستخدمة' : (_provider == 'all' ? 'كل الأكواد والخدمات' : 'خدمات ${providers.firstWhere((p) => p.$1 == _provider).$2}')), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
            if (_tab == 2 && _recentIds.isNotEmpty) TextButton(onPressed: () async { await _recentService.clear(); await _loadRecent(); }, child: const Text('مسح السجل')),
            PopupMenuButton<String>(
              tooltip: 'خيارات العرض',
              onSelected: (value) {
                setState(() {
                  if (value.startsWith('category:')) { _category = value.substring(9); }
                  if (value.startsWith('sort:')) { _sort = value.substring(5); }
                  if (value.startsWith('status:')) { _verificationFilter = value.substring(7); }
                });
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'category:الكل', child: Text('كل التصنيفات')),
                ...(_codes.map((e) => e.category).toSet().toList()..sort()).map((value) => PopupMenuItem(value: 'category:$value', child: Text(value))),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'sort:default', child: Text('الترتيب الافتراضي')),
                const PopupMenuItem(value: 'sort:title', child: Text('الترتيب بالاسم')),
                const PopupMenuItem(value: 'sort:provider', child: Text('الترتيب بالشركة')),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'status:all', child: Text('كل حالات التوثيق')),
                const PopupMenuItem(value: 'status:verified', child: Text('الموثقة رسمياً فقط')),
                const PopupMenuItem(value: 'status:unverified', child: Text('غير المتحقق منها')),
              ],
              child: Chip(avatar: const Icon(Icons.tune, size: 17), label: Text(_verificationFilter == 'verified' ? 'موثقة' : (_verificationFilter == 'unverified' ? 'غير موثقة' : _category))),
            ),
          ]),
        ),
        Expanded(
          child: codes.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _tab == 1 ? Icons.star_border : (_tab == 2 ? Icons.history : Icons.search_off),
                          size: 48,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _tab == 1 && _favoriteIds.isEmpty
                              ? 'لم تضف أكوادًا للمفضلة بعد'
                              : (_tab == 2 && _recentIds.isEmpty
                                  ? 'لم تستخدم أي كود حتى الآن'
                                  : 'لا توجد نتائج مطابقة'),
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _tab == 1
                              ? 'اضغط على علامة النجمة في أي كود لحفظه هنا.'
                              : (_tab == 2
                                  ? 'سيظهر هنا الكود بعد فتح تطبيق الاتصال من داخل التطبيق.'
                                  : 'جرّب تغيير كلمات البحث أو إزالة بعض الفلاتر.'),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        OutlinedButton.icon(
                          onPressed: () => setState(() {
                            _search.clear();
                            _provider = 'all';
                            _category = 'الكل';
                            _verificationFilter = 'all';
                            _sort = 'default';
                            if (_tab == 1 || _tab == 2) _tab = 0;
                          }),
                          icon: const Icon(Icons.filter_alt_off),
                          label: const Text('عرض كل الأكواد'),
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  itemCount: codes.length,
                  itemBuilder: (context, index) {
                    final item = codes[index];
                    return CodeCard(
                      item: item,
                      favorite: _favoriteIds.contains(item.id),
                      onFavorite: () => _toggleFavorite(item),
                      onDial: () => _dial(item),
                      onCopy: () => _copyCode(item),
                      onShare: () => _shareCode(item),
                      compact: _compactCards,
                    );
                  },
                ),
        ),
      ],
    );
  }

  Future<void> _exportBackup() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final backup = {
        'format': 'smart_mobile_codes_backup',
        'version': 1,
        'createdAt': DateTime.now().toUtc().toIso8601String(),
        'favorites': prefs.getStringList('favorite_code_ids') ?? <String>[],
        'recent': prefs.getStringList('recent_code_ids_v1') ?? <String>[],
        'settings': {
          'theme': prefs.getString('app_theme_mode_v1') ?? 'system',
          'confirmBeforeDial': prefs.getBool('confirm_before_dial_v1') ?? true,
          'hapticsEnabled': prefs.getBool('haptics_enabled_v1') ?? true,
          'compactCards': prefs.getBool('compact_cards_v1') ?? false,
        },
      };
      await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(backup)));
      _showMessage('تم نسخ النسخة الاحتياطية. احتفظ بها في مكان آمن.');
    } catch (_) {
      _showMessage('تعذر إنشاء النسخة الاحتياطية.');
    }
  }

  Future<void> _importBackup() async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('استعادة نسخة احتياطية'),
        content: TextField(
          controller: controller,
          minLines: 5,
          maxLines: 9,
          decoration: const InputDecoration(
            hintText: 'الصق محتوى النسخة الاحتياطية هنا',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة')),
        ],
      ),
    );
    if (confirmed != true) { controller.dispose(); return; }
    try {
      final data = jsonDecode(controller.text);
      if (data is! Map || data['format'] != 'smart_mobile_codes_backup' || data['version'] != 1 || data['favorites'] is! List || data['recent'] is! List) {
        throw const FormatException('Invalid backup');
      }
      final favorites = (data['favorites'] as List).whereType<String>().toSet().toList();
      final recent = (data['recent'] as List).whereType<String>().toSet().toList();
      final validIds = _codes.map((e) => e.id).toSet();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('favorite_code_ids', favorites.where(validIds.contains).toList());
      await prefs.setStringList('recent_code_ids_v1', recent.where(validIds.contains).take(30).toList());
      final settings = data['settings'];
      if (settings is Map) {
        final theme = settings['theme'];
        if (theme is String && const {'system', 'light', 'dark'}.contains(theme)) {
          await prefs.setString('app_theme_mode_v1', theme);
          appThemeMode.value = switch (theme) { 'light' => ThemeMode.light, 'dark' => ThemeMode.dark, _ => ThemeMode.system };
        }
        if (settings['confirmBeforeDial'] is bool) await prefs.setBool('confirm_before_dial_v1', settings['confirmBeforeDial'] as bool);
        if (settings['hapticsEnabled'] is bool) await prefs.setBool('haptics_enabled_v1', settings['hapticsEnabled'] as bool);
        if (settings['compactCards'] is bool) await prefs.setBool('compact_cards_v1', settings['compactCards'] as bool);
      }
      await _loadUiPreferences();
      await _loadFavorites();
      await _loadRecent();
      _showMessage('تمت استعادة المفضلة والسجل.');
    } catch (_) {
      _showMessage('النسخة غير صالحة أو لا تتوافق مع هذا التطبيق.');
    } finally {
      controller.dispose();
    }
  }

  Future<void> _setTheme(String value) async {
    final nextMode = switch (value) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    appThemeMode.value = nextMode;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('app_theme_mode_v1', value);
    } catch (_) {
      _showMessage('تم تغيير المظهر مؤقتًا، لكن تعذر حفظه بعد إغلاق التطبيق.');
    }
  }

  Future<void> _sendFeedback() async {
    final uri = Uri.parse('https://github.com/mainosama/smart-mobile-codes/issues/new');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      _showMessage('تعذر فتح صفحة إرسال الملاحظات.');
    }
  }

  Widget _buildSettingsPage(BuildContext context) {
    final current = switch (appThemeMode.value) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      _ => 'system',
    };
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('الإعدادات', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('المظهر', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'system', label: Text('النظام'), icon: Icon(Icons.phone_android)),
              ButtonSegment(value: 'light', label: Text('فاتح'), icon: Icon(Icons.light_mode)),
              ButtonSegment(value: 'dark', label: Text('داكن'), icon: Icon(Icons.dark_mode)),
            ],
            selected: {current},
            onSelectionChanged: (values) => _setTheme(values.first),
          ),
        ]))),
        Card(child: Column(children: [
          SwitchListTile(secondary: const Icon(Icons.shield_outlined), title: const Text('التأكيد قبل فتح الاتصال'), subtitle: const Text('يعرض تحذيرًا قبل تنفيذ أي كود'), value: _confirmBeforeDial, onChanged: (v) => _setBooleanPreference('confirm', v)),
          const Divider(height: 1),
          SwitchListTile(secondary: const Icon(Icons.vibration), title: const Text('الاهتزاز اللمسي'), subtitle: const Text('اهتزاز خفيف عند اختيار كود'), value: _hapticsEnabled, onChanged: (v) => _setBooleanPreference('haptics', v)),
          const Divider(height: 1),
          SwitchListTile(secondary: const Icon(Icons.view_agenda_outlined), title: const Text('عرض البطاقات المدمج'), subtitle: const Text('يقلل المسافات داخل بطاقات الأكواد'), value: _compactCards, onChanged: (v) => _setBooleanPreference('compact', v)),
        ])),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.calculate_outlined), title: const Text('حاسبة استهلاك الإنترنت'), subtitle: const Text('احسب المتبقي ونسبة الاستهلاك'), onTap: _showDataCalculator),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.compare_arrows), title: const Text('مقارنة الباقات'), subtitle: const Text('قارن السعر مقابل سعة GB للباقات التي تدخلها'), onTap: _showPlanComparator),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.auto_awesome), title: const Text('المساعد الذكي للخدمات'), subtitle: const Text('اكتب ما تريد فعله ليبحث في دليل الأكواد'), onTap: _smartAssistant),
        ])),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.backup_outlined), title: const Text('نسخ احتياطي للمفضلة والسجل'), subtitle: const Text('ينسخ ملف JSON إلى الحافظة'), onTap: _exportBackup),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.restore), title: const Text('استعادة نسخة احتياطية'), subtitle: const Text('الصق ملف النسخة الاحتياطية لاستعادته'), onTap: _importBackup),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.delete_sweep_outlined), title: const Text('مسح سجل الاستخدام'), onTap: () async { await _recentService.clear(); await _loadRecent(); _showMessage('تم مسح السجل.'); }),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.star_outline), title: const Text('مسح كل المفضلة'), onTap: () async {
            final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
              title: const Text('مسح المفضلة؟'),
              content: const Text('سيتم حذف جميع الأكواد المحفوظة من المفضلة على هذا الجهاز.'),
              actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('مسح'))],
            ));
            if (ok == true) { final prefs = await SharedPreferences.getInstance(); await prefs.remove('favorite_code_ids'); await _loadFavorites(); _showMessage('تم مسح المفضلة.'); }
          }),
        ])),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.sync), title: const Text('تحديث دليل الأكواد'), subtitle: const Text('تحميل أحدث نسخة متاحة من الدليل'), onTap: _catalogBusy ? null : () => _loadCatalog(forceRefresh: true)),
          const Divider(height: 1),
          ListTile(leading: const Icon(Icons.feedback_outlined), title: const Text('إرسال ملاحظات'), subtitle: const Text('يفتح صفحة الملاحظات والبلاغات على GitHub'), onTap: _sendFeedback),
          const Divider(height: 1),
          const ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('الخصوصية'), subtitle: Text('المفضلة وسجل الاستخدام محفوظان محلياً. لا يقرأ التطبيق سجل مكالماتك أو أرقام جهات اتصالك.')),
        ])),
        const Padding(padding: EdgeInsets.all(12), child: Text('Smart Mobile Codes • الإصدار 2.2.0\nتحقق من مصدر الشركة قبل استخدام أي كود قد يترتب عليه رسوم.', textAlign: TextAlign.center)),
      ],
    );
  }

  Widget _buildWidgetPage(BuildContext context) {
    if (_codes.isEmpty) {
      return const Center(child: Text('لا توجد أكواد متاحة للويدجت حاليًا. حدّث الدليل وحاول مرة أخرى.'));
    }
    final selected = _codes.firstWhere(
      (code) => code.id == _widgetCodeId,
      orElse: () => _codes.first,
    );
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Icon(Icons.widgets_rounded, size: 64),
        const SizedBox(height: 12),
        Text('ويدجت الشاشة الرئيسية', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('اختر كوداً ليظهر على شاشة هاتفك الرئيسية، ثم اضغط تحديث. بعد ذلك أضف ويدجت «كود موبايل» من قائمة الويدجت في الهاتف.', textAlign: TextAlign.center),
        const SizedBox(height: 24),
        DropdownButtonFormField<String>(
          initialValue: _widgetCodeId,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'الكود المعروض', border: OutlineInputBorder()),
          items: _codes.map((code) => DropdownMenuItem(value: code.id, child: Text('${code.providerName} — ${code.title}', overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (value) => setState(() => _widgetCodeId = value),
        ),
        const SizedBox(height: 16),
        Card(child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              Text(selected.title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(selected.code, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
              Text(selected.providerName),
              if (!selected.verified) const Text('غير متحقق منه رسمياً', style: TextStyle(color: Colors.deepOrange)),
            ]),
          )),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _widgetBusy ? null : _updateWidget,
          icon: _widgetBusy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh),
          label: const Text('تحديث الويدجت'),
        ),
        const SizedBox(height: 12),
        const Text('ملاحظة: الويدجت يعرض بيانات الكود فقط. فتح الاتصال يتم من داخل التطبيق، ولا يتم إجراء أي اتصال تلقائياً.', style: TextStyle(fontSize: 12)),
      ],
    );
  }
}
