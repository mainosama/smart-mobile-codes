import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/seed_codes.dart';
import '../models/mobile_code.dart';
import '../services/dialer_service.dart';
import '../services/favorites_service.dart';
import '../services/widget_service.dart';
import '../widgets/code_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();
  final _favorites = FavoritesService();
  final _dialer = DialerService();
  final _widgetService = WidgetService();
  Set<String> _favoriteIds = {};
  String _provider = 'all';
  String _category = 'الكل';
  int _tab = 0;
  String? _widgetCodeId;
  bool _widgetBusy = false;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _widgetCodeId = seedCodes.isEmpty ? null : seedCodes.first.id;
  }

  Future<void> _loadFavorites() async {
    try {
      final values = await _favorites.load();
      if (mounted) setState(() => _favoriteIds = values);
    } catch (_) {
      if (mounted) _showMessage('تعذر تحميل المفضلة. حاول مرة أخرى.');
    }
  }

  List<MobileCode> get _visibleCodes {
    Iterable<MobileCode> items = seedCodes;
    if (_provider != 'all') {
      items = items.where((e) => e.providerId == _provider);
    }
    if (_category != 'الكل') {
      items = items.where((e) => e.category == _category);
    }
    if (_tab == 1) {
      items = items.where((e) => _favoriteIds.contains(e.id));
    }
    final query = _search.text.trim().toLowerCase();
    if (query.isNotEmpty) {
      items = items.where((e) =>
          '${e.title} ${e.code} ${e.category} ${e.providerName} ${e.description}'
              .toLowerCase()
              .contains(query));
    }
    return items.toList();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _toggleFavorite(MobileCode item) async {
    try {
      await _favorites.toggle(item.id, _favoriteIds);
      await _loadFavorites();
    } catch (_) {
      _showMessage('تعذر تحديث المفضلة.');
    }
  }

  Future<void> _dial(MobileCode item) async {
    // The current seed catalog is explicitly unverified. Never silently dial it.
    final proceed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تنبيه قبل الاتصال'),
        content: Text(item.verified
            ? 'سيتم فتح تطبيق الاتصال للكود ${item.code}. هل تريد المتابعة؟'
            : 'هذا الكود لم يتم التحقق منه من مصدر الشركة الرسمي. قد لا يعمل أو قد تترتب عليه رسوم. هل تريد فتح تطبيق الاتصال على أي حال؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('متابعة'),
          ),
        ],
      ),
    );
    if (proceed != true || !mounted) return;
    final ok = await _dialer.dial(item.code);
    if (!ok) _showMessage('تعذر فتح تطبيق الاتصال على هذا الجهاز.');
  }

  Future<void> _copyCode(MobileCode item) async {
    await Clipboard.setData(ClipboardData(text: item.code));
    _showMessage('تم نسخ الكود');
  }

  Future<void> _updateWidget() async {
    if (_widgetBusy || seedCodes.isEmpty) return;
    final selected = seedCodes.firstWhere(
      (code) => code.id == _widgetCodeId,
      orElse: () => seedCodes.first,
    );
    setState(() => _widgetBusy = true);
    final success = await _widgetService.update(selected);
    if (mounted) setState(() => _widgetBusy = false);
    if (!mounted) return;
    _showMessage(success
        ? 'تم تحديث بيانات الويدجت. أضف ويدجت «كود موبايل» من شاشة هاتفك الرئيسية.'
        : 'تعذر تحديث الويدجت. تأكد من تثبيت التطبيق بصورة صحيحة.');
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('كود موبايل', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            tooltip: 'حول التطبيق',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'كود موبايل',
              applicationVersion: '1.1.0',
              children: const [Text('دليل أكواد وخدمات شركات المحمول في مصر.')],
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: _tab == 2 ? _buildWidgetPage(context) : _buildCodesPage(context),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.widgets_outlined), selectedIcon: Icon(Icons.widgets), label: 'الويدجت'),
        ],
      ),
    );
  }

  Widget _buildCodesPage(BuildContext context) {
    final codes = _visibleCodes;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF5143C7), Color(0xFF8879F2)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('كل خدمات خطك في مكان واحد', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 5),
                Text('ابحث عن الخدمة وافتح كود الاتصال بضغطة', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
              Icon(Icons.sim_card_rounded, color: Colors.white, size: 44),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SearchBar(
            controller: _search,
            onChanged: (_) => setState(() {}),
            hintText: 'ابحث عن خدمة أو كود...',
            leading: const Icon(Icons.search),
            trailing: [
              if (_search.text.isNotEmpty)
                IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.close)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: providers.map((provider) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: ChoiceChip(
                label: Text(provider.$2),
                selected: _provider == provider.$1,
                onSelected: (_) => setState(() => _provider = provider.$1),
              ),
            )).toList(),
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(child: Text(_tab == 1 ? 'الأكواد المفضلة' : 'الأكواد والخدمات', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
            PopupMenuButton<String>(
              initialValue: _category,
              onSelected: (value) => setState(() => _category = value),
              itemBuilder: (_) => ['الكل', 'الرصيد', 'الدعم', 'الإنترنت', 'الشحن', 'الباقات'].map((value) => PopupMenuItem(value: value, child: Text(value))).toList(),
              child: Chip(avatar: const Icon(Icons.filter_list, size: 17), label: Text(_category)),
            ),
          ]),
        ),
        Expanded(
          child: codes.isEmpty
              ? const Center(child: Text('مفيش نتائج مطابقة حالياً'))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  itemCount: codes.length,
                  itemBuilder: (context, index) {
                    final item = codes[index];
                    return CodeCard(
                      item: item,
                      favorite: _favoriteIds.contains(item.id),
                      onFavorite: () => _toggleFavorite(item),
                      onDial: () => _dial(item),
                      onCopy: () => _copyCode(item),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildWidgetPage(BuildContext context) {
    final selected = seedCodes.firstWhere(
      (code) => code.id == _widgetCodeId,
      orElse: () => seedCodes.first,
    );
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Icon(Icons.widgets_rounded, size: 64),
        const SizedBox(height: 12),
        Text('ويدجت الشاشة الرئيسية', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('اختر كوداً ليظهر على شاشة هاتفك الرئيسية، ثم اضغط تحديث. بعد ذلك أضف ويدجت «كود موبايل» من قائمة الويدجت في الهاتف.', textAlign: TextAlign.center),
        const SizedBox(height: 24),
        DropdownButtonFormField<String>(
          value: _widgetCodeId,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'الكود المعروض', border: OutlineInputBorder()),
          items: seedCodes.map((code) => DropdownMenuItem(value: code.id, child: Text('${code.providerName} — ${code.title}', overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (value) => setState(() => _widgetCodeId = value),
        ),
        const SizedBox(height: 16),
        Card(child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              Text(selected.title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(selected.code, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
              Text(selected.providerName),
              if (!selected.verified) const Text('غير متحقق منه رسمياً', style: TextStyle(color: Colors.deepOrange)),
            ]),
          )),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _widgetBusy ? null : _updateWidget,
          icon: _widgetBusy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh),
          label: const Text('تحديث الويدجت'),
        ),
        const SizedBox(height: 12),
        const Text('ملاحظة: الويدجت يعرض بيانات الكود فقط. فتح الاتصال يتم من داخل التطبيق، ولا يتم إجراء أي اتصال تلقائياً.', style: TextStyle(fontSize: 12)),
      ],
    );
  }
}
