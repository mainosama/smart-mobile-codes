import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/home_screen.dart';
import 'screens/splash_screen.dart';

final ValueNotifier<ThemeMode> appThemeMode = ValueNotifier(ThemeMode.system);

Future<void> loadAppPreferences() async {
  final prefs = await SharedPreferences.getInstance();
  final value = prefs.getString('app_theme_mode_v1') ?? 'system';
  appThemeMode.value = switch (value) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  loadAppPreferences().catchError((_) {}).whenComplete(
    () => runApp(const SmartMobileCodesApp()),
  );
}

class SmartMobileCodesApp extends StatelessWidget {
  const SmartMobileCodesApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF123B78);
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: appThemeMode,
      builder: (context, mode, _) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'كود موبايل',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F7FB), foregroundColor: Color(0xFF0B1E3D)),
        fontFamily: 'sans-serif',
        cardTheme: CardThemeData(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
        cardTheme: CardThemeData(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF071A35), foregroundColor: Colors.white),
      ),
      themeMode: mode,
      home: const SplashScreen(),
      ),
    );
  }
}
