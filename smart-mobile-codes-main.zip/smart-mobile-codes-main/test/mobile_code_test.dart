import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';

void main() {
  test('seed catalog has unique ids and required fields', () {
    final ids = seedCodes.map((code) => code.id).toList();
    expect(ids.toSet().length, ids.length);
    for (final code in seedCodes) {
      expect(code.id.trim(), isNotEmpty);
      expect(code.providerId.trim(), isNotEmpty);
      expect(code.title.trim(), isNotEmpty);
      expect(code.code.trim(), isNotEmpty);
      expect(code.category.trim(), isNotEmpty);
    }
  });

  test('every code marked verified has an official source URL', () {
    final verified = seedCodes.where((code) => code.verified);
    expect(verified, isNotEmpty);
    for (final code in verified) {
      expect(code.sourceUrl, startsWith('https://'));
    }
    expect(seedCodes.any((code) => !code.verified), isTrue);
  });
}
