import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/main.dart';

void main() {
  testWidgets('branded splash opens the company directory', (tester) async {
    await tester.pumpWidget(const SmartMobileCodesApp());
    await tester.pump();

    expect(find.text('Smart Mobile Codes'), findsOneWidget);
    expect(find.text('كل شبكاتك.. في مكان واحد'), findsOneWidget);

    // Advance past the splash timer and route transition. Avoid pumpAndSettle
    // because the splash intentionally runs a repeating glow animation.
    await tester.pump(const Duration(milliseconds: 2100));
    await tester.pump(const Duration(milliseconds: 450));

    expect(find.text('اختر شركتك'), findsOneWidget);
    expect(find.text('Vodafone'), findsWidgets);
    expect(find.text('Orange'), findsWidgets);
  });
}
