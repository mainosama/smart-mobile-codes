import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/main.dart';

void main() {
  testWidgets('app starts and shows the home screen', (tester) async {
    await tester.pumpWidget(const SmartMobileCodesApp());
    await tester.pump();

    expect(find.text('كود موبايل'), findsWidgets);
    expect(find.text('كل خدمات خطك في مكان واحد'), findsOneWidget);
  });
}
