#!/usr/bin/env python3
"""Validate codes.json before it is shipped. Mirrors the rules in CatalogService.parse
and adds data-quality checks that the app can not afford to do at runtime."""
import json, re, sys
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parents[1]
data = json.loads((root / 'codes.json').read_text(encoding='utf-8'))
errors, warnings = [], []

if data.get('schemaVersion') != 1:
    errors.append('schemaVersion must be 1')
codes = data.get('codes', [])
if not codes:
    errors.append('codes is empty')

PROVIDERS = {'vodafone', 'orange', 'etisalat', 'we'}
CODE_RE = re.compile(r'^[0-9*#\u0621-\u064a\s\[\]{}<>]+$')
ids = Counter(c.get('id') for c in codes)
errors += [f'duplicate id: {k}' for k, v in ids.items() if v > 1]
pairs = Counter((c.get('providerId'), c.get('code')) for c in codes)
errors += [f'duplicate provider+code: {k}' for k, v in pairs.items() if v > 1]
titles = Counter((c.get('providerId'), c.get('title')) for c in codes)
errors += [f'duplicate provider+title: {k}' for k, v in titles.items() if v > 1]
known = set(ids)
for c in codes:
    i = c.get('id', '?')
    for field in ('id', 'providerId', 'providerName', 'title', 'code', 'category'):
        if not str(c.get(field, '')).strip():
            errors.append(f'{i}: missing {field}')
    if c.get('providerId') not in PROVIDERS:
        errors.append(f'{i}: unknown provider {c.get("providerId")}')
    code = c.get('code', '')
    if not CODE_RE.match(code) or len(code) > 40:
        errors.append(f'{i}: invalid code string {code!r}')
    if c.get('verified') and not str(c.get('sourceUrl', '')).startswith('https://'):
        errors.append(f'{i}: verified record needs an https sourceUrl')
    for legacy in c.get('legacyIds', []):
        if legacy in known:
            errors.append(f'{i}: legacy id {legacy} still exists as a record')
    if len(c.get('description', '')) > 220:
        warnings.append(f'{i}: description longer than 220 chars')
print(f'{len(codes)} records, {sum(1 for c in codes if c.get("verified"))} marked verified')
for w in warnings: print('warning:', w)
for e in errors: print('ERROR:', e)
sys.exit(1 if errors else 0)
