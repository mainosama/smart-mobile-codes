#!/usr/bin/env python3
"""Configure the native Android home-screen widget and release network permission."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
app = root / "android" / "app"
manifest = app / "src" / "main" / "AndroidManifest.xml"
if not manifest.exists():
    raise SystemExit("AndroidManifest.xml not found; run flutter create first")

gradle_files = [app / "build.gradle.kts", app / "build.gradle"]
namespace = None
for gradle in gradle_files:
    if gradle.exists():
        match = re.search(r"namespace\s*[= ]\s*['\"]([^'\"]+)", gradle.read_text(encoding="utf-8"))
        if match:
            namespace = match.group(1)
            break
if not namespace:
    raise SystemExit("Could not determine Android namespace from app Gradle file")

package_dir = app / "src" / "main" / "kotlin" / Path(*namespace.split("."))
package_dir.mkdir(parents=True, exist_ok=True)
kotlin = '''package NAMESPACE

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetPlugin

class MobileCodeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val data = HomeWidgetPlugin.getData(context)
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.mobile_code_widget)
            views.setTextViewText(R.id.widget_title, data.getString("widget_title", "كود موبايل") ?: "كود موبايل")
            views.setTextViewText(R.id.widget_code, data.getString("widget_code", "افتح التطبيق لاختيار كود") ?: "افتح التطبيق لاختيار كود")
            views.setTextViewText(R.id.widget_provider, data.getString("widget_provider", "دليل أكواد المحمول") ?: "دليل أكواد المحمول")
            views.setTextViewText(R.id.widget_status, data.getString("widget_status", "") ?: "")
            val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (launchIntent != null) {
                val pendingIntent = PendingIntent.getActivity(context, 0, launchIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.widget_container, pendingIntent)
            }
            manager.updateAppWidget(id, views)
        }
    }
}
'''.replace("NAMESPACE", namespace)
(package_dir / "MobileCodeWidgetProvider.kt").write_text(kotlin, encoding="utf-8")

layout_dir = app / "src" / "main" / "res" / "layout"
xml_dir = app / "src" / "main" / "res" / "xml"
layout_dir.mkdir(parents=True, exist_ok=True)
xml_dir.mkdir(parents=True, exist_ok=True)
(layout_dir / "mobile_code_widget.xml").write_text('''<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/widget_container" android:layout_width="match_parent"
    android:layout_height="match_parent" android:orientation="vertical"
    android:gravity="center_vertical" android:padding="14dp" android:background="#5143C7">
    <TextView android:id="@+id/widget_title" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="كود موبايل" android:textColor="#FFFFFF"
        android:textSize="14sp" android:textStyle="bold" />
    <TextView android:id="@+id/widget_code" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="افتح التطبيق لاختيار كود"
        android:textColor="#FFFFFF" android:textSize="22sp" android:textStyle="bold"
        android:paddingTop="5dp" />
    <TextView android:id="@+id/widget_provider" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="دليل أكواد المحمول"
        android:textColor="#E8E5FF" android:textSize="11sp" />
    <TextView android:id="@+id/widget_status" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:textColor="#FFE0B2" android:textSize="10sp" />
</LinearLayout>
''', encoding="utf-8")
(xml_dir / "mobile_code_widget_info.xml").write_text('''<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="180dp" android:minHeight="90dp" android:updatePeriodMillis="0"
    android:initialLayout="@layout/mobile_code_widget" android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen" />
''', encoding="utf-8")

text = manifest.read_text(encoding="utf-8")
# Release APKs need INTERNET permission for the GitHub-hosted remote catalog.
if "android.permission.INTERNET" not in text:
    root_end = text.find(">")
    if root_end < 0:
        raise SystemExit("Invalid AndroidManifest.xml root element")
    text = (text[:root_end + 1] +
            '\n    <uses-permission android:name="android.permission.INTERNET" />' +
            text[root_end + 1:])
receiver = '''
        <receiver android:name=".MobileCodeWidgetProvider" android:exported="true" android:label="كود موبايل">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/mobile_code_widget_info" />
        </receiver>
'''
if ".MobileCodeWidgetProvider" not in text:
    if "</application>" not in text:
        raise SystemExit("AndroidManifest.xml has no application closing tag")
    text = text.replace("</application>", receiver + "    </application>")
manifest.write_text(text, encoding="utf-8")
print(f"Android home-screen widget configured for namespace {namespace}; INTERNET permission ensured.")
