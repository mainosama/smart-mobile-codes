#!/usr/bin/env python3
"""Apply the Smart Mobile Codes brand to the generated Android project."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
manifest = root / 'android' / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
logo = root / 'assets' / 'app_logo.png'
foreground = root / 'assets' / 'app_logo_foreground.png'
if not manifest.is_file():
    raise SystemExit('AndroidManifest.xml not found; run flutter create first.')
for asset in (logo, foreground):
    if not asset.is_file() or asset.stat().st_size < 1000:
        raise SystemExit(f'Required launcher logo is missing or invalid: {asset}')
text = manifest.read_text(encoding='utf-8')
text, count = re.subn(r'android:label="[^"]*"', 'android:label="Smart Mobile Codes"', text, count=1)
if count == 0:
    raise SystemExit('Could not locate android:label in AndroidManifest.xml')
if 'android:icon=' not in text:
    text = text.replace('<application', '<application android:icon="@mipmap/ic_launcher"', 1)
manifest.write_text(text, encoding='utf-8')
print('Android app label set to Smart Mobile Codes; launcher icon assets verified.')
