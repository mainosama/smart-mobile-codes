#!/usr/bin/env python3
"""Download IBM Plex Sans Arabic (OFL) into assets/fonts.

If any file cannot be fetched the `fonts:` block is removed from pubspec.yaml, so the
build still succeeds and the app falls back to the system Arabic font."""
import re, sys, time, urllib.request
from pathlib import Path

root = Path(__file__).resolve().parents[1]
dest = root / 'assets' / 'fonts'
dest.mkdir(parents=True, exist_ok=True)
names = ['IBMPlexSansArabic-Regular.ttf', 'IBMPlexSansArabic-Medium.ttf', 'IBMPlexSansArabic-SemiBold.ttf']
bases = [
    'https://raw.githubusercontent.com/google/fonts/main/ofl/ibmplexsansarabic/',
    'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/ibmplexsansarabic/',
]

def fetch(name):
    for base in bases:
        for attempt in range(2):
            try:
                with urllib.request.urlopen(base + name, timeout=40) as r:
                    data = r.read()
                if len(data) > 50_000 and data[:4] in (b'\x00\x01\x00\x00', b'true', b'OTTO'):
                    (dest / name).write_bytes(data)
                    return True
            except Exception as e:
                print(f'  {base}{name}: {e}')
                time.sleep(1)
    return False

ok = all(fetch(n) for n in names)
if ok:
    print('Fonts downloaded.')
    sys.exit(0)
pubspec = root / 'pubspec.yaml'
text = pubspec.read_text(encoding='utf-8')
text = re.sub(r'  # FONTS-BEGIN.*?# FONTS-END\n', '', text, flags=re.S)
pubspec.write_text(text, encoding='utf-8')
print('WARNING: font download failed; building with the system font.')
