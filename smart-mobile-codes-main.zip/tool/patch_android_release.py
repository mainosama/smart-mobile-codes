#!/usr/bin/env python3
"""Apply safe Android release settings for WorkManager/Room reflective initialization."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
app = root / "android" / "app"
candidates = [app / "build.gradle.kts", app / "build.gradle"]
gradle = next((p for p in candidates if p.exists()), None)
if gradle is None:
    raise SystemExit("Android app Gradle file not found; run flutter create first")

text = gradle.read_text(encoding="utf-8")
if gradle.name.endswith(".kts"):
    settings = "            isMinifyEnabled = false\n            isShrinkResources = false\n"
else:
    settings = "            minifyEnabled false\n            shrinkResources false\n"

# Insert settings specifically inside the release build type.
pattern = re.compile(r"(buildTypes\s*\{\s*release\s*\{)")
match = pattern.search(text)
if not match:
    raise SystemExit("Could not find buildTypes { release { ... } block")
start = match.end()
# Find the closing brace for release block while respecting quoted strings/comments
depth = 1
i = start
in_string = None
escape = False
while i < len(text) and depth:
    ch = text[i]
    if in_string:
        if escape:
            escape = False
        elif ch == "\\":
            escape = True
        elif ch == in_string:
            in_string = None
    else:
        if ch in ("'", '"'):
            in_string = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
    i += 1
if depth:
    raise SystemExit("Unbalanced braces in app Gradle file")
block = text[start:i-1]
# Remove previous values, then prepend deterministic safe values.
block = re.sub(r"(?m)^\s*(?:isMinifyEnabled\s*=\s*|minifyEnabled\s+)(?:true|false)\s*;?\s*$\n?", "", block)
block = re.sub(r"(?m)^\s*(?:isShrinkResources\s*=\s*|shrinkResources\s+)(?:true|false)\s*;?\s*$\n?", "", block)
new_block = "\n" + settings + block.lstrip("\n")
text = text[:start] + new_block + text[i-1:]
gradle.write_text(text, encoding="utf-8")

# Keep a defensive rule file for projects that intentionally re-enable R8 later.
rules = app / "proguard-rules.pro"
rules.write_text(
    "# WorkManager creates Room database implementations reflectively.\n"
    "# Keep the no-argument constructor required by Room at application startup.\n"
    "-keep class * extends androidx.room.RoomDatabase { <init>(); }\n"
    "-keep class * extends androidx.work.InputMerger { <init>(); }\n",
    encoding="utf-8",
)
print(f"Disabled release minification/resource shrinking in {gradle.name}; added defensive Room/WorkManager keep rules.")

# Android lint "vital" checks run for every plugin during `assembleRelease`. On the CI image the
# bundled lint crashes inside third-party plugins (NoSuchMethodError in url_launcher_android),
# which fails the whole build although the code is fine. Disable only those vital-lint tasks.
root_candidates = [root / "android" / "build.gradle.kts", root / "android" / "build.gradle"]
root_gradle = next((p for p in root_candidates if p.exists()), None)
if root_gradle is None:
    raise SystemExit("Android root Gradle file not found; run flutter create first")
marker = "// smart-mobile-codes: disable lintVital"
root_text = root_gradle.read_text(encoding="utf-8")
if marker not in root_text:
    if root_gradle.name.endswith(".kts"):
        snippet = (
            f"\n{marker}\n"
            "subprojects {\n"
            "    tasks.configureEach {\n"
            "        if (name.startsWith(\"lintVital\")) {\n"
            "            enabled = false\n"
            "        }\n"
            "    }\n"
            "}\n"
        )
    else:
        snippet = (
            f"\n{marker}\n"
            "subprojects {\n"
            "    tasks.configureEach { task ->\n"
            "        if (task.name.startsWith('lintVital')) {\n"
            "            task.enabled = false\n"
            "        }\n"
            "    }\n"
            "}\n"
        )
    root_gradle.write_text(root_text + snippet, encoding="utf-8")
print(f"Disabled lintVital tasks for all Gradle subprojects in {root_gradle.name}.")
