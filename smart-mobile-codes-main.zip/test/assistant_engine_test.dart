import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/utils/assistant_engine.dart';

void main() {
  test('transfer question is not mistaken for a balance question', () {
    final answer = answerQuestion(seedCodes, 'عايز أحول رصيد على فودافون');
    expect(answer.providerId, 'vodafone');
    expect(answer.results, isNotEmpty);
    expect(answer.results.first.title, contains('تحويل'));
    expect(answer.results.every((c) => c.providerId == 'vodafone'), isTrue);
  });

  test('balance intent finds balance codes', () {
    final answer = answerQuestion(seedCodes, 'معرفة الرصيد');
    expect(answer.message, startsWith('لقيت'));
    expect('${answer.results.first.title} ${answer.results.first.category}', contains('رصيد'));
  });

  test('carrier filter from the UI is respected', () {
    final answer = answerQuestion(seedCodes, 'خدمة العملاء', providerFilter: 'orange');
    expect(answer.results, isNotEmpty);
    expect(answer.results.every((c) => c.providerId == 'orange'), isTrue);
  });

  test('unknown text answers honestly with no results', () {
    final answer = answerQuestion(seedCodes, 'zzzzqqqq');
    expect(answer.results, isEmpty);
    expect(answer.message, isNot(startsWith('لقيت')));
  });
}
