import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/utils/search_normalizer.dart';

void main() {
  test('normalizes Arabic hamza, taa marbuta, diacritics and Arabic digits', () {
    expect(normalizeSearchText('إدارة الباقة ١٢٣'), 'اداره الباقه 123');
  });

  test('normalizes whitespace and Latin case', () {
    expect(normalizeSearchText('  VODAFONE   Balance '), 'vodafone balance');
  });
}
