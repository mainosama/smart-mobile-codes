import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/utils/search_normalizer.dart';

void main() {
  test('normalizes Arabic variants, diacritics and Indic digits', () {
    expect(normalizeSearchText('  أُورَنج   إنترنت '), 'اورنج انترنت');
    expect(normalizeSearchText('الباقة'), 'الباقه');
    expect(normalizeSearchText('*٨٦٨#'), '*868#');
  });

  test('search forms cover prefixes and plurals', () {
    expect(searchForms('الباقات'), containsAll(['الباقات', 'باقات', 'باق']));
    expect(searchForms('الرصيد'), contains('رصيد'));
  });
}
