import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/utils/dial_validation.dart';
import 'package:smart_mobile_codes/utils/number_carrier.dart';

void main() {
  test('carrier is detected from the number prefix in every common format', () {
    expect(carrierForNumber('01012345678')?.id, 'vodafone');
    expect(carrierForNumber('01112345678')?.id, 'etisalat');
    expect(carrierForNumber('01212345678')?.id, 'orange');
    expect(carrierForNumber('01512345678')?.id, 'we');
    expect(carrierForNumber('+20 101 234 5678')?.id, 'vodafone');
    expect(carrierForNumber('00201212345678')?.id, 'orange');
    expect(carrierForNumber('١٠١٢٣٤٥٦٧٨')?.id, 'vodafone');
  });

  test('non-mobile or malformed numbers are rejected', () {
    expect(carrierForNumber('0212345678'), isNull);
    expect(carrierForNumber('01312345678'), isNull);
    expect(carrierForNumber('0101234'), isNull);
    expect(normalizeEgyptianMobile('abc'), isNull);
  });

  test('manual dial strings', () {
    expect(isValidDialString('*555#'), isTrue);
    expect(isValidDialString(' #100# '), isTrue);
    expect(isValidDialString('888'), isTrue);
    expect(isValidDialString('*#'), isFalse);
    expect(isValidDialString('5'), isFalse);
    expect(isValidDialString('*555 #'), isFalse);
    expect(isValidDialString('call'), isFalse);
  });
}
