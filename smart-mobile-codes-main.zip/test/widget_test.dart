import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/main.dart';

void main() {
  testWidgets('branded splash opens the company directory', (tester) async {
    await tester.pumpWidget(const SmartMobileCodesApp());
    await tester.pump();

    expect(find.text('Smart Mobile Codes'), findsOneWidget);
    expect(find.byKey(const ValueKey('brand-app-logo')), findsOneWidget, reason: 'The branded logo must be bundled and shown on the splash screen.');
    expect(find.text('كل شبكاتك.. في مكان واحد'), findsOneWidget);

    // Advance past the splash timer and route transition. Avoid pumpAndSettle
    // because the splash intentionally runs a repeating glow animation.
    await tester.pump(const Duration(milliseconds: 2100));
    await tester.pump(const Duration(milliseconds: 450));

    expect(find.text('اختر شركتك'), findsOneWidget);
    expect(find.text('Vodafone'), findsWidgets);
    expect(find.text('Orange'), findsWidgets);
    expect(find.text('المتبقي من باقة GO'), findsOneWidget, reason: 'The main directory should show code cards immediately.');

    // The hero card is an action: tapping it resets filters and returns to all codes.
    await tester.tap(find.text('كل شبكاتك.. في تطبيق واحد'));
    await tester.pump();
    expect(find.text('المتبقي من باقة GO'), findsOneWidget);
  });
}
