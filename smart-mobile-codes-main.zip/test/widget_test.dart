import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smart_mobile_codes/main.dart';
import 'package:smart_mobile_codes/services/catalog_service.dart';
import 'package:smart_mobile_codes/state/app_controller.dart';

/// Never touches the network: the app keeps the bundled catalog.
class _OfflineCatalog extends CatalogService {
  @override
  Future<CatalogSnapshot> fetchRemote({Duration timeout = const Duration(seconds: 15)}) {
    throw const CatalogFormatException('offline');
  }

  @override
  Future<DateTime?> lastFetchAt() async => null;
}

Future<void> openApp(WidgetTester tester, AppController controller) async {
  await tester.binding.setSurfaceSize(const Size(412, 915));
  addTearDown(() => tester.binding.setSurfaceSize(null));
  await tester.pumpWidget(SmartMobileCodesApp(controller: controller, splashDuration: const Duration(milliseconds: 100)));
  await tester.pump();
  await tester.pump(const Duration(milliseconds: 200));
  await tester.pump(const Duration(milliseconds: 500));
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('splash leads to the directory, UI is right-to-left', (tester) async {
    final controller = AppController(catalog: _OfflineCatalog());
    await openApp(tester, controller);

    expect(find.text('كود موبايل'), findsWidgets);
    expect(find.text('كل الشركات'), findsWidgets);
    expect(find.text('Vodafone'), findsWidgets);
    expect(Directionality.of(tester.element(find.text('كل الشركات'))), TextDirection.rtl);
    expect(tester.takeException(), isNull);
  });

  testWidgets('search narrows the list and favouriting persists in the controller', (tester) async {
    final controller = AppController(catalog: _OfflineCatalog());
    await openApp(tester, controller);

    await tester.enterText(find.byType(TextField).first, 'تحويل');
    await tester.pump();
    expect(find.textContaining('نتيجة'), findsWidgets);

    await tester.tap(find.byTooltip('إضافة إلى المفضلة').first);
    await tester.pump();
    expect(controller.favorites.length, 1);
    expect(tester.takeException(), isNull);
  });

  testWidgets('bottom navigation switches tabs', (tester) async {
    final controller = AppController(catalog: _OfflineCatalog());
    await openApp(tester, controller);

    await tester.tap(find.text('الإعدادات'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('تأكيد قبل فتح الاتصال'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
