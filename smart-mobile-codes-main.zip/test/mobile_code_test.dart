import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/models/mobile_code.dart';

void main() {
  test('seed catalog has unique ids and required fields', () {
    final ids = seedCodes.map((code) => code.id).toList();
    expect(ids.toSet().length, ids.length);
    for (final code in seedCodes) {
      expect(code.id.trim(), isNotEmpty);
      expect(code.providerId.trim(), isNotEmpty);
      expect(code.title.trim(), isNotEmpty);
      expect(code.code.trim(), isNotEmpty);
      expect(code.category.trim(), isNotEmpty);
    }
  });

  test('verified entries cite an HTTPS carrier source', () {
    final verified = seedCodes.where((code) => code.verified);
    expect(verified, isNotEmpty);
    for (final code in verified) {
      final uri = Uri.parse(code.sourceUrl);
      expect(uri.scheme, 'https');
      expect(uri.host, isNotEmpty);
    }
  });

  test('parameterized codes are marked as copy-only templates', () {
    final templates = seedCodes.where((code) => code.requiresInput);
    expect(templates, isNotEmpty);
    expect(templates.every((code) => code.code.contains('رقم') || code.code.contains('الكارت')), isTrue);
  });

  test('mobile code JSON round-trip preserves all fields', () {
    const original = MobileCode(
      id: 'sample',
      providerId: 'vodafone',
      providerName: 'Vodafone',
      title: 'معرفة الرصيد',
      code: '*868#',
      category: 'الرصيد',
      description: 'اختبار تحويل البيانات',
      verified: false,
      sourceUrl: 'https://example.com/code',
      systems: 'كل الأنظمة',
    );
    expect(MobileCode.fromJson(original.toJson()).toJson(), original.toJson());
  });
}
