import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/models/mobile_code.dart';
import 'package:smart_mobile_codes/utils/arabic_date.dart';
import 'package:smart_mobile_codes/utils/digits.dart';

MobileCode byId(String id) => seedCodes.firstWhere((c) => c.id == id);

void main() {
  test('plain codes are dialable, templates are not', () {
    expect(byId('vf_balance').requiresInput, isFalse);
    expect(byId('vf_credit_transfer').requiresInput, isTrue);
  });

  test('template fields are detected and filled in order', () {
    final code = byId('vf_credit_transfer');
    expect(code.canFill, isTrue);
    expect(code.fields.map((f) => f.label).toList(), ['رقم الموبايل', 'المبلغ']);
    expect(code.fill(['01012345678', '50']), '*868*2*01012345678*50#');
    expect(code.fill(['٠١٠١٢٣٤٥٦٧٨', '٥٠']), '*868*2*01012345678*50#');
    expect(code.fill(['01012345678', '']), '*868*2*01012345678*المبلغ#');
  });

  test('multi-step instructions can only be copied', () {
    final code = byId('et_transfer_postpaid');
    expect(code.requiresInput, isTrue);
    expect(code.isMultiStep, isTrue);
    expect(code.canFill, isFalse);
  });

  test('every template either fills or is an explicit multi-step', () {
    for (final c in seedCodes.where((c) => c.requiresInput)) {
      expect(c.canFill || c.isMultiStep, isTrue, reason: c.id);
    }
  });

  test('field validation', () {
    final fields = byId('vf_credit_transfer').fields;
    expect(fields[0].validate('01012345678'), isNull);
    expect(fields[0].validate('0212345'), isNotNull);
    expect(fields[0].validate('abc'), isNotNull);
    expect(fields[0].validate(''), isNotNull);
    expect(fields[1].validate('25'), isNull);
    expect(fields[1].validate('0'), isNotNull);
  });

  test('JSON round-trip preserves all fields including legacy ids', () {
    const original = MobileCode(
      id: 'sample',
      providerId: 'vodafone',
      providerName: 'Vodafone',
      title: 'معرفة الرصيد',
      code: '*868#',
      category: 'الرصيد',
      description: 'اختبار',
      verified: true,
      sourceUrl: 'https://example.com/code',
      systems: 'مسبق الدفع',
      eligibility: 'كارت',
      legacyIds: ['old_sample'],
    );
    expect(MobileCode.fromJson(original.toJson()).toJson(), original.toJson());
  });

  test('share text uses real line breaks and states review status', () {
    final text = byId('vf_balance').shareText;
    expect(text.contains(r'\n'), isFalse);
    expect(text.split('\n').length, greaterThan(3));
    expect(text, contains(byId('vf_balance').code));
  });

  test('digits and dates', () {
    expect(toLatinDigits('٠١٢٣٤٥٦٧٨٩'), '0123456789');
    expect(parseDecimal('١٫٥'), 1.5);
    expect(parseDecimal('2,5'), 2.5);
    expect(parseDecimal('abc'), isNull);
    expect(formatArabicDate(DateTime(2026, 11, 10)), '10 نوفمبر 2026');
  });
}
