import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smart_mobile_codes/services/catalog_service.dart';
import 'package:smart_mobile_codes/state/app_controller.dart';

class _OfflineCatalog extends CatalogService {
  @override
  Future<CatalogSnapshot> fetchRemote({Duration timeout = const Duration(seconds: 15)}) {
    throw const CatalogFormatException('offline');
  }

  @override
  Future<DateTime?> lastFetchAt() async => null;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('favourites saved under an old id are migrated to the merged record', () async {
    SharedPreferences.setMockInitialValues({
      'favorite_code_ids': ['vf_puk_ar', 'vf_balance'],
      'recent_code_ids_v1': ['vf_puk_ar', 'vf_puk'],
    });
    final controller = AppController(catalog: _OfflineCatalog());
    await controller.init(autoRefresh: false);
    expect(controller.favorites, containsAll(['vf_puk', 'vf_balance']));
    expect(controller.favorites.contains('vf_puk_ar'), isFalse);
    expect(controller.recents, ['vf_puk']);
    controller.dispose();
  });

  test('backup export/import round trip', () async {
    SharedPreferences.setMockInitialValues({});
    final a = AppController(catalog: _OfflineCatalog());
    await a.init(autoRefresh: false);
    await a.toggleFavorite('vf_balance');
    await a.recordRecent('vf_balance');
    final backup = a.exportBackup();

    SharedPreferences.setMockInitialValues({});
    final b = AppController(catalog: _OfflineCatalog());
    await b.init(autoRefresh: false);
    await b.importBackup(backup);
    expect(b.favorites, {'vf_balance'});
    expect(b.recents, ['vf_balance']);
    await expectLater(b.importBackup('{"format":"other"}'), throwsA(isA<FormatException>()));
    a.dispose();
    b.dispose();
  });

  test('refresh failure keeps the existing catalog', () async {
    SharedPreferences.setMockInitialValues({});
    final controller = AppController(catalog: _OfflineCatalog());
    await controller.init(autoRefresh: false);
    final before = controller.codes.length;
    final result = await controller.refreshCatalog(force: true);
    expect(result, RefreshResult.offline);
    expect(controller.codes.length, before);
    expect(controller.catalogBusy, isFalse);
    controller.dispose();
  });
}
