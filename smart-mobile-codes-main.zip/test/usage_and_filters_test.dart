import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/services/catalog_service.dart';
import 'package:smart_mobile_codes/state/app_controller.dart';
import 'package:smart_mobile_codes/state/directory_filters.dart';

class _OfflineCatalog extends CatalogService {
  @override
  Future<CatalogSnapshot> fetchRemote({Duration timeout = const Duration(seconds: 15)}) {
    throw const CatalogFormatException('offline');
  }

  @override
  Future<DateTime?> lastFetchAt() async => null;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('most used codes are ranked by how often they were dialled and persist', () async {
    SharedPreferences.setMockInitialValues({});
    final a = AppController(catalog: _OfflineCatalog());
    await a.init(autoRefresh: false);
    await a.recordRecent('vf_balance');
    await a.recordRecent('vf_credit_transfer');
    await a.recordRecent('vf_credit_transfer');
    await a.recordRecent('not_in_catalog');
    expect(a.mostUsedCodes.map((c) => c.id).toList(), ['vf_credit_transfer', 'vf_balance']);
    expect(a.usage.containsKey('not_in_catalog'), isFalse);

    final b = AppController(catalog: _OfflineCatalog());
    await b.init(autoRefresh: false);
    expect(b.mostUsedCodes.first.id, 'vf_credit_transfer');

    await b.clearHistory();
    expect(b.mostUsedCodes, isEmpty);
    expect(b.recents, isEmpty);
    a.dispose();
    b.dispose();
  });

  test('recent searches are deduplicated, capped and ignore tiny queries', () async {
    SharedPreferences.setMockInitialValues({});
    final c = AppController(catalog: _OfflineCatalog());
    await c.init(autoRefresh: false);
    await c.rememberSearch('a');
    expect(c.recentSearches, isEmpty);
    for (final q in ['رصيد', 'تحويل', 'رصيد', 'باقة', 'سلفني', 'شحن', 'نت', 'خدمة']) {
      await c.rememberSearch(q);
    }
    expect(c.recentSearches.first, 'خدمة');
    expect(c.recentSearches.length, 6);
    expect(c.recentSearches.where((e) => e == 'رصيد').length, lessThanOrEqualTo(1));
    c.dispose();
  });

  test('filters memoize per input and invalidate when inputs change', () {
    final f = DirectoryFilters();
    final first = f.apply(seedCodes);
    expect(identical(first, f.apply(seedCodes)), isTrue);
    f.update(provider: 'orange');
    final orange = f.apply(seedCodes);
    expect(orange.every((c) => c.providerId == 'orange'), isTrue);
    expect(orange.length, lessThan(first.length));
    f.update(query: 'رصيد');
    expect(f.apply(seedCodes).every((c) => c.providerId == 'orange'), isTrue);
    f.reset();
    expect(f.apply(seedCodes).length, seedCodes.length);
  });
}
