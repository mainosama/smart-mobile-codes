import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/utils/code_search.dart';

void main() {
  test('empty query returns everything', () {
    expect(searchCodes(seedCodes, '  ').length, seedCodes.length);
  });

  test('multi-word queries match across fields (carrier + topic)', () {
    final results = searchCodes(seedCodes, 'رصيد فودافون');
    expect(results, isNotEmpty);
    expect(results.first.providerId, 'vodafone');
  });

  test('searching by digits finds the dial string', () {
    final results = searchCodes(seedCodes, '868');
    expect(results.any((c) => c.code.contains('868')), isTrue);
  });

  test('definite article does not hide results', () {
    expect(searchCodes(seedCodes, 'الرصيد'), isNotEmpty);
    expect(searchCodes(seedCodes, 'الباقات'), isNotEmpty);
  });

  test('nonsense matches nothing', () {
    expect(searchCodes(seedCodes, 'zzzzqqqq'), isEmpty);
  });
}
