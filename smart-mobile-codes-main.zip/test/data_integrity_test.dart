import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/app_info.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/services/catalog_service.dart';

void main() {
  final body = File('codes.json').readAsStringSync();

  test('codes.json passes the same validation the app applies to downloads', () {
    final parsed = CatalogService.parseCatalog(body);
    expect(parsed.codes.length, greaterThan(50));
    expect(parsed.updatedAt, isNotNull);
  });

  test('bundled seed is in sync with codes.json (run tool/generate_seed.py)', () {
    final parsed = CatalogService.parseCatalog(body);
    expect(seedCodes.map((c) => c.id).toList(), parsed.codes.map((c) => c.id).toList());
    expect(seedCodes.map((c) => c.code).toList(), parsed.codes.map((c) => c.code).toList());
    expect(seedCatalogUpdatedAt, parsed.updatedAt!.toIso8601String().substring(0, 10));
  });

  test('no provider has the same dial string twice', () {
    final seen = <String>{};
    for (final c in seedCodes) {
      expect(seen.add('${c.providerId}|${c.code}'), isTrue, reason: '${c.providerId} ${c.code} duplicated');
    }
  });

  test('legacy ids never collide with live ids', () {
    final live = seedCodes.map((c) => c.id).toSet();
    for (final c in seedCodes) {
      for (final old in c.legacyIds) {
        expect(live.contains(old), isFalse, reason: '$old is both legacy and live');
      }
    }
  });

  test('verified entries cite an HTTPS source', () {
    final verified = seedCodes.where((c) => c.verified);
    expect(verified, isNotEmpty);
    for (final c in verified) {
      final uri = Uri.parse(c.sourceUrl);
      expect(uri.scheme, 'https');
      expect(uri.host, isNotEmpty);
    }
  });

  test('parser rejects malformed catalogs', () {
    expect(() => CatalogService.parseCatalog('{"schemaVersion":2,"codes":[]}'), throwsA(isA<CatalogFormatException>()));
    expect(() => CatalogService.parseCatalog('{"schemaVersion":1,"codes":[]}'), throwsA(isA<CatalogFormatException>()));
    const verifiedWithoutSource =
        '{"schemaVersion":1,"codes":[{"id":"a","providerId":"we","providerName":"WE","title":"t","code":"*1#","category":"x","verified":true}]}';
    expect(() => CatalogService.parseCatalog(verifiedWithoutSource), throwsA(isA<CatalogFormatException>()));
    const unknownProvider =
        '{"schemaVersion":1,"codes":[{"id":"a","providerId":"zzz","providerName":"Z","title":"t","code":"*1#","category":"x"}]}';
    expect(() => CatalogService.parseCatalog(unknownProvider), throwsA(isA<CatalogFormatException>()));
  });

  test('appVersion matches pubspec.yaml', () {
    final pubspec = File('pubspec.yaml').readAsStringSync();
    final match = RegExp(r'^version:\s*([0-9.]+)\+([0-9]+)', multiLine: true).firstMatch(pubspec)!;
    expect(match.group(1), appVersion);
    expect(int.parse(match.group(2)!), appBuildNumber);
  });
}
