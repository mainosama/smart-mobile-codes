import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/screens/assistant_screen.dart';

void main() {
  testWidgets('assistant shows quick prompts and local search results', (tester) async {
    await tester.binding.setSurfaceSize(const Size(430, 900));
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: AssistantScreen(codes: seedCodes, onShowResults: (_) {}),
      ),
    ));
    expect(find.text('مركز المساعدة الذكي'), findsOneWidget);
    expect(find.text('معرفة الرصيد'), findsOneWidget);
    await tester.tap(find.text('معرفة الرصيد'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.textContaining('لقيت'), findsOneWidget);
    await tester.binding.setSurfaceSize(null);
  });
}
