import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:smart_mobile_codes/data/seed_codes.dart';
import 'package:smart_mobile_codes/screens/assistant_screen.dart';

Widget host(Size _) => MaterialApp(
      locale: const Locale('ar', 'EG'),
      supportedLocales: const [Locale('ar', 'EG')],
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(body: AssistantScreen(codes: seedCodes, onShowResults: (_, __) {})),
      ),
    );

void main() {
  testWidgets('assistant answers a quick prompt without overflow on narrow screens', (tester) async {
    await tester.binding.setSurfaceSize(const Size(398, 760));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(host(const Size(398, 760)));
    expect(find.text('اسأل الدليل'), findsOneWidget);
    expect(find.text('معرفة الرصيد'), findsOneWidget);

    await tester.tap(find.text('معرفة الرصيد'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.textContaining('لقيت'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.binding.setSurfaceSize(const Size(320, 700));
    await tester.pumpWidget(host(const Size(320, 700)));
    await tester.pump();
    expect(find.text('اسأل الدليل'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
